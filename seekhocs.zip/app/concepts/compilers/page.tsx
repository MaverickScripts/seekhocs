"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Token class for lexical analysis
class Token {
  type: string
  value: string
  position: number

  constructor(type: string, value: string, position: number) {
    this.type = type
    this.value = value
    this.position = position
  }
}

// Node class for parse tree
class ParseNode {
  type: string
  value: string
  children: ParseNode[]
  x: number
  y: number
  width: number
  height: number

  constructor(type: string, value: string) {
    this.type = type
    this.value = value
    this.children = []
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
  }

  addChild(node: ParseNode) {
    this.children.push(node)
  }
}

export default function CompilersPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [compilerPhase, setCompilerPhase] = useState("lexical")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [sourceCode, setSourceCode] = useState("int x = 5 + 3;\nif (x > 7) {\n  print(x);\n}")
  const [tokens, setTokens] = useState<Token[]>([])
  const [currentTokenIndex, setCurrentTokenIndex] = useState(-1)
  const [parseTree, setParseTree] = useState<ParseNode | null>(null)
  const [currentParseNode, setCurrentParseNode] = useState<ParseNode | null>(null)
  const [assemblyCode, setAssemblyCode] = useState("")
  const [message, setMessage] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Compiler Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore the phases of compilation through interactive visualizations",
  )
  const [currentTokenTokenIndex, setCurrentTokenTokenIndex] = useState(-1)
  const [currentStep, setCurrentStep] = useState(0)

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Add this useEffect after the existing useEffect for setting canvas size:
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)
      setCurrentStep(0)
      setCurrentParseNode(null)
      setCurrentTokenIndex(-1)
      setTokens([])
      setParseTree(null)
      setAssemblyCode("")

      // Set compiler phase and content based on selected concept
      if (selectedConcept.toLowerCase().includes("lexical")) {
        setCompilerPhase("lexical")
        setConceptTitle("Lexical Analysis")
        setConceptDescription(
          "The process of converting a sequence of characters into a sequence of tokens, which are meaningful units like keywords, identifiers, and operators.",
        )
        setMessage("Lexical Analysis: Converting source code into tokens.")
        setSourceCode("int x = 5 + 3;\nif (x > 7) {\n  print(x);\n}")
        performLexicalAnalysis()
      } else if (
        selectedConcept.toLowerCase().includes("parsing") ||
        selectedConcept.toLowerCase().includes("syntax")
      ) {
        setCompilerPhase("parsing")
        setConceptTitle("Syntax Analysis (Parsing)")
        setConceptDescription(
          "The process of analyzing a string of symbols according to the rules of a formal grammar, creating a parse tree representation.",
        )
        setMessage("Syntax Analysis: Building a parse tree from tokens.")
        setSourceCode("int x = 5 + 3;\nif (x > 7) {\n  print(x);\n}")
        performParsing()
      } else if (selectedConcept.toLowerCase().includes("semantic")) {
        setCompilerPhase("semantic")
        setConceptTitle("Semantic Analysis")
        setConceptDescription(
          "The process of checking the meaning of the program, including type checking and ensuring variables are declared before use.",
        )
        setMessage("Semantic Analysis: Checking the meaning of the program.")
        setSourceCode("int x = 5;\nfloat y = x + 2.5;\nstring z = x + y;  // Type error!")
        performSemanticAnalysis()
      } else if (selectedConcept.toLowerCase().includes("intermediate")) {
        setCompilerPhase("intermediate")
        setConceptTitle("Intermediate Code Generation")
        setConceptDescription(
          "The process of translating the source code into an intermediate representation that is easier to analyze and transform.",
        )
        setMessage("Intermediate Code Generation: Creating three-address code.")
        setSourceCode("int a = 5;\nint b = 10;\nint c = a * b + 2;")
        generateIntermediateCode()
      } else if (selectedConcept.toLowerCase().includes("optimization")) {
        setCompilerPhase("optimization")
        setConceptTitle("Code Optimization")
        setConceptDescription(
          "The process of modifying the intermediate code to produce more efficient target code, improving execution time or memory usage.",
        )
        setMessage("Code Optimization: Improving the efficiency of the generated code.")
        setSourceCode("for (int i = 0; i < 10; i++) {\n  x = y * 2;\n  z = z + x;\n}")
        performOptimization()
      } else if (selectedConcept.toLowerCase().includes("code generation")) {
        setCompilerPhase("code-generation")
        setConceptTitle("Code Generation")
        setConceptDescription(
          "The process of transforming the intermediate representation of the source code into the target language, often assembly or machine code.",
        )
        setMessage("Code Generation: Transforming the program into assembly or machine code.")
        setSourceCode("int factorial(int n) {\n  if (n <= 1) return 1;\n  return n * factorial(n-1);\n}")
        generateAssemblyCode()
      } else if (selectedConcept.toLowerCase().includes("symbol")) {
        setCompilerPhase("symbol-table")
        setConceptTitle("Symbol Table")
        setConceptDescription(
          "A data structure used by a compiler to keep track of the semantics of variables, such as their scope, type, and memory location.",
        )
        setMessage("Symbol Table: Tracking variable information during compilation.")
        setSourceCode("int x = 10;\n\nvoid func() {\n  int x = 20;\n  {\n    float x = 30.5;\n    print(x);\n  }\n}")
        generateSymbolTable()
      } else if (selectedConcept.toLowerCase().includes("runtime")) {
        setCompilerPhase("runtime")
        setConceptTitle("Runtime Environment")
        setConceptDescription(
          "The environment in which a program executes, including memory layout, function call mechanisms, and garbage collection.",
        )
        setMessage("Runtime Environment: Visualizing program execution and memory management.")
        setSourceCode(
          "function main() {\n  let x = 10;\n  function inner() {\n    let y = 20;\n    return x + y;\n  }\n  return inner();\n}",
        )
        visualizeRuntime()
      } else {
        // Default to lexical analysis
        setCompilerPhase("lexical")
        setConceptTitle("Compiler Visualizer")
        setConceptDescription("Explore the phases of compilation through interactive visualizations")
        setMessage("Select a compiler phase to visualize its operation.")
        setSourceCode("int x = 5 + 3;\nif (x > 7) {\n  print(x);\n}")
        performLexicalAnalysis()
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Compiler Visualizer`
    }
  }, [selectedConcept])

  // Perform lexical analysis
  const performLexicalAnalysis = () => {
    const tokenPatterns = [
      { type: "KEYWORD", pattern: /\b(int|if|else|for|while|return|print)\b/ },
      { type: "IDENTIFIER", pattern: /\b[a-zA-Z_][a-zA-Z0-9_]*\b/ },
      { type: "NUMBER", pattern: /\b\d+\b/ },
      { type: "OPERATOR", pattern: /[+\-*/=<>!&|]+/ },
      { type: "PUNCTUATION", pattern: /[;,(){}[\]]/ },
      { type: "WHITESPACE", pattern: /\s+/ },
    ]

    const tokens: Token[] = []
    let position = 0

    while (position < sourceCode.length) {
      let match = false

      for (const { type, pattern } of tokenPatterns) {
        const regex = new RegExp(`^${pattern.source}`, "m")
        const result = regex.exec(sourceCode.slice(position))

        if (result && result.index === 0) {
          const value = result[0]

          // Skip whitespace tokens
          if (type !== "WHITESPACE") {
            tokens.push(new Token(type, value, position))
          }

          position += value.length
          match = true
          break
        }
      }

      if (!match) {
        // Skip unrecognized characters
        position++
      }
    }

    setTokens(tokens)
    setCurrentTokenIndex(-1)
    setMessage("Lexical Analysis: Tokenizing the source code.")
  }

  // Perform parsing
  const performParsing = () => {
    // Simple recursive descent parser for demonstration
    // This is a simplified parser that handles basic expressions and statements

    // First perform lexical analysis to get tokens
    performLexicalAnalysis()

    // Create a simple parse tree
    const rootNode = new ParseNode("PROGRAM", "program")

    // Add some example nodes for visualization
    const declarationNode = new ParseNode("DECLARATION", "declaration")
    declarationNode.addChild(new ParseNode("TYPE", "int"))
    declarationNode.addChild(new ParseNode("IDENTIFIER", "x"))
    declarationNode.addChild(new ParseNode("OPERATOR", "="))

    const expressionNode = new ParseNode("EXPRESSION", "expression")
    expressionNode.addChild(new ParseNode("NUMBER", "5"))
    expressionNode.addChild(new ParseNode("OPERATOR", "+"))
    expressionNode.addChild(new ParseNode("NUMBER", "3"))

    declarationNode.addChild(expressionNode)
    rootNode.addChild(declarationNode)

    const ifStatementNode = new ParseNode("IF_STATEMENT", "if_statement")
    ifStatementNode.addChild(new ParseNode("KEYWORD", "if"))

    const conditionNode = new ParseNode("CONDITION", "condition")
    conditionNode.addChild(new ParseNode("IDENTIFIER", "x"))
    conditionNode.addChild(new ParseNode("OPERATOR", ">"))
    conditionNode.addChild(new ParseNode("NUMBER", "7"))

    ifStatementNode.addChild(conditionNode)

    const blockNode = new ParseNode("BLOCK", "block")
    const printNode = new ParseNode("PRINT_STATEMENT", "print_statement")
    printNode.addChild(new ParseNode("KEYWORD", "print"))
    printNode.addChild(new ParseNode("IDENTIFIER", "x"))

    blockNode.addChild(printNode)
    ifStatementNode.addChild(blockNode)

    rootNode.addChild(ifStatementNode)

    // Calculate positions for the parse tree nodes
    calculateParseTreeLayout(rootNode, canvasSize.width / 2, 50, canvasSize.width - 100)

    setParseTree(rootNode)
    setCurrentParseNode(null)
    setMessage("Syntax Analysis: Building a parse tree from tokens.")
  }

  // Calculate layout for parse tree visualization
  const calculateParseTreeLayout = (node: ParseNode, x: number, y: number, availableWidth: number) => {
    const nodeWidth = 80
    const nodeHeight = 30
    const levelHeight = 60

    node.x = x
    node.y = y
    node.width = nodeWidth
    node.height = nodeHeight

    if (node.children.length > 0) {
      const childWidth = availableWidth / node.children.length

      for (let i = 0; i < node.children.length; i++) {
        const childX = x - availableWidth / 2 + childWidth * i + childWidth / 2
        calculateParseTreeLayout(node.children[i], childX, y + levelHeight, childWidth)
      }
    }
  }

  // Generate assembly code
  const generateAssemblyCode = () => {
    // Simple assembly code generation for demonstration
    const assembly = `; Assembly code for: ${sourceCode.split("\n")[0]}
section .text
global _start

_start:
    ; Initialize x
    mov eax, 5      ; Load 5 into eax
    add eax, 3      ; Add 3 to eax
    mov [x], eax    ; Store result in x

    ; Compare x with 7
    cmp eax, 7      ; Compare x with 7
    jle end         ; Jump if less than or equal to end

    ; Print x
    push dword [x]  ; Push x onto stack
    call print      ; Call print function
    add esp, 4      ; Clean up stack

end:
    ; Exit program
    mov eax, 1      ; sys_exit system call
    xor ebx, ebx    ; Exit code 0
    int 0x80        ; Call kernel

section .data
    x dd 0          ; Variable x

section .bss
    ; Reserved for uninitialized data
`

    setAssemblyCode(assembly)
    setMessage("Code Generation: Generating assembly code from the parse tree.")
  }

  // Perform semantic analysis
  const performSemanticAnalysis = () => {
    // First perform lexical analysis to get tokens
    performLexicalAnalysis()

    // Create a simple type checking visualization
    const semanticErrors = [
      { line: 2, message: "No type error: Implicit conversion from int to float is allowed" },
      { line: 3, message: "Type error: Cannot concatenate string with numeric types" },
    ]

    setTokens(
      tokens.map((token, index) => {
        // Mark tokens in error lines
        const tokenLine = sourceCode.substring(0, token.position).split("\n").length
        const hasError = semanticErrors.some((err) => err.line === tokenLine && err.message.includes("error"))

        return {
          ...token,
          hasError: hasError,
        }
      }),
    )

    setMessage("Semantic Analysis: Checking for type errors and other semantic issues.")
  }

  // Generate intermediate code
  const generateIntermediateCode = () => {
    // Simple three-address code generation
    const threeAddressCode = ["t1 = 5", "a = t1", "t2 = 10", "b = t2", "t3 = a * b", "t4 = t3 + 2", "c = t4"]

    setAssemblyCode(threeAddressCode.join("\n"))
    setMessage("Intermediate Code Generation: Creating three-address code representation.")
  }

  // Perform code optimization
  const performOptimization = () => {
    // Original and optimized code
    const originalCode = [
      "t1 = 0",
      "i = t1",
      "L1: if i >= 10 goto L2",
      "t2 = y * 2",
      "x = t2",
      "t3 = z + x",
      "z = t3",
      "t4 = i + 1",
      "i = t4",
      "goto L1",
      "L2: ...",
    ]

    const optimizedCode = [
      "t1 = 0",
      "i = t1",
      "t2 = y * 2", // Loop invariant code motion
      "L1: if i >= 10 goto L2",
      "t3 = z + t2", // Using t2 instead of recomputing y*2
      "z = t3",
      "i = i + 1", // Strength reduction
      "goto L1",
      "L2: ...",
    ]

    setTokens(originalCode.map((line, index) => new Token("CODE", line, index)))
    setAssemblyCode(optimizedCode.join("\n"))
    setMessage("Code Optimization: Applying optimizations like loop invariant code motion and strength reduction.")
  }

  // Generate symbol table
  const generateSymbolTable = () => {
    const symbolTable = [
      { name: "x", scope: "global", type: "int", line: 1, address: "0x1000" },
      { name: "func", scope: "global", type: "function", line: 3, address: "0x2000" },
      { name: "x", scope: "func", type: "int", line: 4, address: "0x2100" },
      { name: "x", scope: "block in func", type: "float", line: 6, address: "0x2200" },
    ]

    setTokens(symbolTable.map((symbol, index) => new Token("SYMBOL", `${symbol.name} (${symbol.type})`, index)))

    setMessage("Symbol Table: Tracking identifiers and their attributes across different scopes.")
  }

  // Visualize runtime environment
  const visualizeRuntime = () => {
    const runtimeSteps = [
      "Call stack: [main]",
      "Allocate memory for x in main",
      "x = 10",
      "Call inner function",
      "Call stack: [main, inner]",
      "Allocate memory for y in inner",
      "y = 20",
      "Access x from closure (x = 10)",
      "Calculate x + y = 30",
      "Return 30 to main",
      "Call stack: [main]",
      "Return 30 from main",
    ]

    setTokens(runtimeSteps.map((step, index) => new Token("RUNTIME", step, index)))
    setMessage("Runtime Environment: Visualizing function calls, closures, and memory allocation.")
  }

  // Animation loop
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          if (compilerPhase === "lexical") {
            if (currentTokenIndex < tokens.length - 1) {
              setCurrentTokenIndex(currentTokenIndex + 1)
            } else {
              setIsPlaying(false)
              setMessage("Lexical Analysis complete. All tokens identified.")
            }
          } else if (compilerPhase === "parsing") {
            // Traverse the parse tree in pre-order
            if (parseTree) {
              if (!currentParseNode) {
                setCurrentParseNode(parseTree)
              } else {
                // Simple pre-order traversal simulation
                const traverseNext = (node: ParseNode): ParseNode | null => {
                  if (node === currentParseNode) {
                    if (node.children.length > 0) {
                      return node.children[0]
                    } else {
                      // Find the next sibling or uncle
                      return findNextNode(parseTree, node)
                    }
                  }

                  for (const child of node.children) {
                    const result = traverseNext(child)
                    if (result) return result
                  }

                  return null
                }

                const nextNode = traverseNext(parseTree)
                if (nextNode) {
                  setCurrentParseNode(nextNode)
                } else {
                  setIsPlaying(false)
                  setMessage("Syntax Analysis complete. Parse tree constructed.")
                }
              }
            }
          } else if (
            compilerPhase === "semantic" ||
            compilerPhase === "intermediate" ||
            compilerPhase === "optimization" ||
            compilerPhase === "symbol-table" ||
            compilerPhase === "runtime"
          ) {
            // For these phases, we'll just step through the tokens/steps
            if (currentTokenIndex < tokens.length - 1) {
              setCurrentTokenIndex(currentTokenIndex + 1)
            } else {
              setIsPlaying(false)
              setMessage(`${conceptTitle} visualization complete.`)
            }
          } else if (compilerPhase === "code-generation") {
            // For code generation, we'll just display the assembly code gradually
            const lines = assemblyCode.split("\n")
            const visibleLines = assemblyCode.split("\n").slice(0, Math.min(currentTokenIndex + 2, lines.length))
            setAssemblyCode(visibleLines.join("\n"))

            if (currentTokenIndex < lines.length - 2) {
              setCurrentTokenIndex(currentTokenIndex + 1)
            } else {
              setIsPlaying(false)
              setMessage("Code Generation complete. Assembly code generated.")
            }
          }
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [
    isPlaying,
    compilerPhase,
    currentTokenIndex,
    tokens,
    currentParseNode,
    parseTree,
    assemblyCode,
    speed,
    canvasSize.width,
    conceptTitle,
  ])

  // Helper function to find the next node in pre-order traversal
  const findNextNode = (root: ParseNode, current: ParseNode): ParseNode | null => {
    // Find the path from root to current
    const path: ParseNode[] = []
    const findPath = (node: ParseNode, target: ParseNode): boolean => {
      path.push(node)
      if (node === target) return true

      for (const child of node.children) {
        if (findPath(child, target)) return true
      }

      path.pop()
      return false
    }

    findPath(root, current)

    // Find the next sibling or uncle
    for (let i = path.length - 1; i > 0; i--) {
      const parent = path[i - 1]
      const childIndex = parent.children.indexOf(path[i])

      if (childIndex < parent.children.length - 1) {
        return parent.children[childIndex + 1]
      }
    }

    return null
  }

  // Draw lexical analysis visualization
  const drawLexicalAnalysis = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const lineHeight = 20
    const charWidth = 10

    // Draw source code
    const lines = sourceCode.split("\n")
    let y = 50

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    for (let i = 0; i < lines.length; i++) {
      // For semantic analysis, highlight error lines
      if (compilerPhase === "semantic" && i === 2) {
        ctx.fillStyle = "rgba(255, 100, 100, 0.3)"
        ctx.fillRect(50, y - 2, width - 100, lineHeight)
      }

      ctx.fillStyle = "#ffffff"
      ctx.fillText(lines[i], 50, y)
      y += lineHeight
    }

    // Draw tokens
    y = height - 150
    ctx.fillText("Tokens:", 50, y)
    y += lineHeight * 1.5

    for (let i = 0; i <= currentTokenIndex && i < tokens.length; i++) {
      const token = tokens[i]
      const tokenText = `${token.type}: "${token.value}"`

      // Highlight current token
      if (i === currentTokenIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(50, y - 2, ctx.measureText(tokenText).width + 10, lineHeight)

        // Highlight the token in the source code
        const position = token.position
        let lineIndex = 0
        let charPosition = position

        // Find the line and character position
        for (let j = 0; j < lines.length; j++) {
          if (charPosition < lines[j].length + 1) {
            // +1 for newline
            lineIndex = j
            break
          }
          charPosition -= lines[j].length + 1
        }

        const tokenX = 50 + charPosition * charWidth
        const tokenY = 50 + lineIndex * lineHeight
        const tokenWidth = token.value.length * charWidth

        ctx.fillStyle = "rgba(159, 122, 234, 0.3)"
        ctx.fillRect(tokenX, tokenY, tokenWidth, lineHeight)
      }

      // For semantic analysis, highlight error tokens
      if (compilerPhase === "semantic" && token.hasError) {
        ctx.fillStyle = "rgba(255, 100, 100, 0.7)"
        ctx.fillRect(50, y - 2, ctx.measureText(tokenText).width + 10, lineHeight)
      } else {
        ctx.fillStyle = "#ffffff"
      }

      ctx.fillText(tokenText, 50, y)
      y += lineHeight
    }
  }

  // Draw parse tree visualization
  const drawParseTree = (ctx: CanvasRenderingContext2D) => {
    if (!parseTree) return

    // Draw the parse tree recursively
    const drawNode = (node: ParseNode) => {
      // Draw node
      ctx.beginPath()
      ctx.rect(node.x - node.width / 2, node.y, node.width, node.height)

      // Highlight current node
      if (node === currentParseNode) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.type, node.x, node.y + node.height / 2)

      // Draw connections to children
      for (const child of node.children) {
        ctx.beginPath()
        ctx.moveTo(node.x, node.y + node.height)
        ctx.lineTo(child.x, child.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw child node
        drawNode(child)
      }
    }

    drawNode(parseTree)

    // Reset shadow
    ctx.shadowBlur = 0
  }

  // Draw code generation visualization
  const drawCodeGeneration = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const lineHeight = 20

    // Draw assembly code
    const lines = assemblyCode.split("\n")
    let y = 50

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    for (let i = 0; i < lines.length; i++) {
      // Highlight current line
      if (i === currentTokenIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(50, y - 2, width - 100, lineHeight)
        ctx.fillStyle = "#000000"
      } else {
        ctx.fillStyle = "#ffffff"
      }

      ctx.fillText(lines[i], 50, y)
      y += lineHeight
    }

    // Draw a simple CPU and memory visualization
    const cpuX = width - 150
    const cpuY = height - 150
    const cpuWidth = 100
    const cpuHeight = 100

    ctx.beginPath()
    ctx.rect(cpuX, cpuY, cpuWidth, cpuHeight)
    ctx.fillStyle = "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("CPU", cpuX + cpuWidth / 2, cpuY + cpuHeight / 2)

    // Draw registers
    const registerWidth = 60
    const registerHeight = 20
    const registerX = cpuX + (cpuWidth - registerWidth) / 2

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"

    ctx.fillText("Registers:", cpuX, cpuY - 30)

    ctx.beginPath()
    ctx.rect(registerX, cpuY - 20, registerWidth, registerHeight)
    ctx.fillStyle = "#9f7aea"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    ctx.fillStyle = "#000000"
    ctx.textAlign = "center"
    ctx.fillText("EAX: 8", registerX + registerWidth / 2, cpuY - 20 + registerHeight / 2)
  }

  // Draw semantic analysis visualization
  const drawSemanticAnalysis = (ctx: CanvasRenderingContext2D) => {
    // Reuse the lexical analysis visualization with error highlighting
    drawLexicalAnalysis(ctx)

    // Add type checking information
    const width = canvasSize.width
    const height = canvasSize.height

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.fillText("Type Checking Results", width / 2, height - 80)

    ctx.font = "14px monospace"
    ctx.fillStyle = "#4fd1c5"
    ctx.fillText("Line 2: int → float conversion (valid)", width / 2, height - 60)

    ctx.fillStyle = "#ff6b6b"
    ctx.fillText("Line 3: string + numeric types (invalid)", width / 2, height - 40)
  }

  // Draw intermediate code visualization
  const drawIntermediateCode = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const lineHeight = 20

    // Draw source code
    const lines = sourceCode.split("\n")
    let y = 50

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    ctx.fillText("Source Code:", 50, y - 20)
    for (let i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], 50, y)
      y += lineHeight
    }

    // Draw intermediate code
    const irLines = assemblyCode.split("\n")
    y = 50

    ctx.fillText("Three-Address Code:", width / 2, y - 20)
    for (let i = 0; i <= currentTokenIndex && i < irLines.length; i++) {
      // Highlight current line
      if (i === currentTokenIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(width / 2, y - 2, 200, lineHeight)
        ctx.fillStyle = "#ffffff"
      }

      ctx.fillText(irLines[i], width / 2, y)
      y += lineHeight
    }

    // Draw arrows connecting source to IR
    if (currentTokenIndex >= 0 && currentTokenIndex < irLines.length) {
      const sourceY = 50 + Math.floor(currentTokenIndex / 2) * lineHeight
      const irY = 50 + currentTokenIndex * lineHeight

      ctx.beginPath()
      ctx.moveTo(200, sourceY + lineHeight / 2)
      ctx.lineTo(width / 2 - 20, irY + lineHeight / 2)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw arrowhead
      ctx.beginPath()
      ctx.moveTo(width / 2 - 20, irY + lineHeight / 2)
      ctx.lineTo(width / 2 - 30, irY + lineHeight / 2 - 5)
      ctx.lineTo(width / 2 - 30, irY + lineHeight / 2 + 5)
      ctx.closePath()
      ctx.fillStyle = "#4fd1c5"
      ctx.fill()
    }
  }

  // Draw optimization visualization
  const drawOptimization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const lineHeight = 20

    // Draw original code
    let y = 50

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    ctx.fillText("Original Code:", 50, y - 20)
    for (let i = 0; i <= currentTokenIndex && i < tokens.length; i++) {
      const line = tokens[i].value

      // Highlight current line
      if (i === currentTokenIndex) {
        ctx.fillStyle = "#ff6b6b"
        ctx.fillRect(50, y - 2, 200, lineHeight)
        ctx.fillStyle = "#ffffff"
      }

      ctx.fillText(line, 50, y)
      y += lineHeight
    }

    // Draw optimized code
    const optLines = assemblyCode.split("\n")
    y = 50

    ctx.fillText("Optimized Code:", width / 2, y - 20)
    for (let i = 0; i <= currentTokenIndex && i < optLines.length; i++) {
      // Highlight optimized lines
      if (
        (i === 2 && currentTokenIndex >= 3) ||
        (i === 4 && currentTokenIndex >= 5) ||
        (i === 6 && currentTokenIndex >= 7)
      ) {
        ctx.fillStyle = "#4fd1c5"
        ctx.fillRect(width / 2, y - 2, 200, lineHeight)
        ctx.fillStyle = "#ffffff"
      }

      ctx.fillText(optLines[i], width / 2, y)
      y += lineHeight
    }

    // Draw optimization explanations
    y = height - 100
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.fillText("Optimizations Applied:", width / 2, y)

    y += 25
    ctx.font = "14px Arial"
    if (currentTokenIndex >= 3) {
      ctx.fillStyle = "#4fd1c5"
      ctx.fillText("Loop Invariant Code Motion: Moved y*2 calculation outside the loop", width / 2, y)
      y += 20
    }

    if (currentTokenIndex >= 7) {
      ctx.fillStyle = "#4fd1c5"
      ctx.fillText("Strength Reduction: Simplified i = i + 1 assignment", width / 2, y)
    }
  }

  // Draw symbol table visualization
  const drawSymbolTable = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const lineHeight = 20

    // Draw source code
    const lines = sourceCode.split("\n")
    let y = 50

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    for (let i = 0; i < lines.length; i++) {
      // Highlight line based on current token
      if (currentTokenIndex >= 0 && currentTokenIndex < tokens.length) {
        const symbol = tokens[currentTokenIndex].value
        const lineNum = i + 1

        if (
          (symbol.includes("x") && (lineNum === 1 || lineNum === 4 || lineNum === 6)) ||
          (symbol.includes("func") && lineNum === 3)
        ) {
          ctx.fillStyle = "rgba(159, 122, 234, 0.3)"
          ctx.fillRect(50, y - 2, width / 2 - 70, lineHeight)
        }
      }

      ctx.fillStyle = "#ffffff"
      ctx.fillText(`${i + 1}: ${lines[i]}`, 50, y)
      y += lineHeight
    }

    // Draw symbol table
    y = 50
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Symbol Table", width / 2, y - 20)

    // Draw table headers
    y += 10
    ctx.font = "14px Arial"
    ctx.fillText("Name", width / 2, y)
    ctx.fillText("Scope", width / 2 + 80, y)
    ctx.fillText("Type", width / 2 + 160, y)
    ctx.fillText("Line", width / 2 + 220, y)
    ctx.fillText("Address", width / 2 + 260, y)

    // Draw horizontal line
    y += 15
    ctx.beginPath()
    ctx.moveTo(width / 2, y)
    ctx.lineTo(width / 2 + 320, y)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw table rows
    y += 20
    const symbolData = [
      { name: "x", scope: "global", type: "int", line: 1, address: "0x1000" },
      { name: "func", scope: "global", type: "function", line: 3, address: "0x2000" },
      { name: "x", scope: "func", type: "int", line: 4, address: "0x2100" },
      { name: "x", scope: "block in func", type: "float", line: 6, address: "0x2200" },
    ]

    for (let i = 0; i <= Math.min(currentTokenIndex, symbolData.length - 1); i++) {
      const symbol = symbolData[i]

      // Highlight current symbol
      if (i === currentTokenIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(width / 2, y - 15, 320, 20)
      }

      ctx.fillStyle = "#ffffff"
      ctx.fillText(symbol.name, width / 2, y)
      ctx.fillText(symbol.scope, width / 2 + 80, y)
      ctx.fillText(symbol.type, width / 2 + 160, y)
      ctx.fillText(symbol.line.toString(), width / 2 + 220, y)
      ctx.fillText(symbol.address, width / 2 + 260, y)

      // Draw arrow from symbol table to code
      const lineY = 50 + (symbol.line - 1) * lineHeight + lineHeight / 2

      ctx.beginPath()
      ctx.moveTo(width / 2, y)
      ctx.lineTo(width / 2 - 20, y)
      ctx.lineTo(width / 2 - 20, lineY)
      ctx.lineTo(width / 2 - 50, lineY)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw arrowhead
      ctx.beginPath()
      ctx.moveTo(width / 2 - 50, lineY)
      ctx.lineTo(width / 2 - 40, lineY - 5)
      ctx.lineTo(width / 2 - 40, lineY + 5)
      ctx.closePath()
      ctx.fillStyle = "#4fd1c5"
      ctx.fill()

      y += 30
    }
  }

  // Draw runtime environment visualization
  const drawRuntime = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const lineHeight = 20

    // Draw source code
    const lines = sourceCode.split("\n")
    let y = 50

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    for (let i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], 50, y)
      y += lineHeight
    }

    // Draw call stack and memory
    const stackWidth = 120
    const stackX = width - 200
    const stackY = 50
    const stackHeight = 200

    // Draw stack frame
    ctx.fillStyle = "#2d3748"
    ctx.fillRect(stackX, stackY, stackWidth, stackHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.strokeRect(stackX, stackY, stackWidth, stackHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.fillText("Call Stack", stackX + stackWidth / 2, stackY - 20)

    // Draw stack frames based on current step
    if (currentTokenIndex >= 0 && currentTokenIndex < tokens.length) {
      const step = tokens[currentTokenIndex].value

      if (step.includes("Call stack: [main]") && !step.includes("inner")) {
        // Only main frame
        ctx.fillStyle = "#4fd1c5"
        ctx.fillRect(stackX + 10, stackY + stackHeight - 50, stackWidth - 20, 40)
        ctx.fillStyle = "#000000"
        ctx.fillText("main()", stackX + stackWidth / 2, stackY + stackHeight - 30)
      } else if (step.includes("Call stack: [main, inner]")) {
        // Main and inner frames
        ctx.fillStyle = "#4fd1c5"
        ctx.fillRect(stackX + 10, stackY + stackHeight - 50, stackWidth - 20, 40)
        ctx.fillStyle = "#000000"
        ctx.fillText("inner()", stackX + stackWidth / 2, stackY + stackHeight - 30)

        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(stackX + 10, stackY + stackHeight - 100, stackWidth - 20, 40)
        ctx.fillStyle = "#000000"
        ctx.fillText("main()", stackX + stackWidth / 2, stackY + stackHeight - 80)
      }

      // Draw memory allocation
      const memX = width - 350
      const memY = 50
      const memWidth = 120
      const memHeight = 200

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(memX, memY, memWidth, memHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.strokeRect(memX, memY, memWidth, memHeight)

      ctx.fillStyle = "#ffffff"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.fillText("Memory", memX + memWidth / 2, memY - 20)

      // Draw variables in memory
      ctx.font = "14px Arial"
      ctx.textAlign = "left"

      if (step.includes("x = 10") || currentTokenIndex > tokens.findIndex((t) => t.value.includes("x = 10"))) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(memX + 10, memY + 20, memWidth - 20, 30)
        ctx.fillStyle = "#000000"
        ctx.fillText("x: 10", memX + 20, memY + 40)
      }

      if (step.includes("y = 20") || currentTokenIndex > tokens.findIndex((t) => t.value.includes("y = 20"))) {
        ctx.fillStyle = "#4fd1c5"
        ctx.fillRect(memX + 10, memY + 60, memWidth - 20, 30)
        ctx.fillStyle = "#000000"
        ctx.fillText("y: 20", memX + 20, memY + 80)
      }

      // Draw closure relationship
      if (
        step.includes("Access x from closure") ||
        currentTokenIndex > tokens.findIndex((t) => t.value.includes("Access x from closure"))
      ) {
        ctx.beginPath()
        ctx.moveTo(memX + 20, memY + 60)
        ctx.lineTo(memX - 20, memY + 60)
        ctx.lineTo(memX - 20, memY + 40)
        ctx.lineTo(memX + 10, memY + 40)
        ctx.strokeStyle = "#ff6b6b"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(memX + 10, memY + 40)
        ctx.lineTo(memX, memY + 35)
        ctx.lineTo(memX, memY + 45)
        ctx.closePath()
        ctx.fillStyle = "#ff6b6b"
        ctx.fill()

        ctx.fillStyle = "#ff6b6b"
        ctx.fillText("Closure", memX - 70, memY + 50)
      }

      // Draw explanation
      ctx.fillStyle = "#ffffff"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.fillText(step, width / 2, height - 50)
    }
  }

  // Update the useEffect for drawing visualizations to include the new visualization types
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (compilerPhase === "lexical") {
      drawLexicalAnalysis(ctx)
    } else if (compilerPhase === "parsing") {
      drawParseTree(ctx)
    } else if (compilerPhase === "semantic") {
      drawSemanticAnalysis(ctx)
    } else if (compilerPhase === "intermediate") {
      drawIntermediateCode(ctx)
    } else if (compilerPhase === "optimization") {
      drawOptimization(ctx)
    } else if (compilerPhase === "code-generation") {
      drawCodeGeneration(ctx)
    } else if (compilerPhase === "symbol-table") {
      drawSymbolTable(ctx)
    } else if (compilerPhase === "runtime") {
      drawRuntime(ctx)
    }
  }, [
    compilerPhase,
    sourceCode,
    tokens,
    currentTokenIndex,
    parseTree,
    currentParseNode,
    assemblyCode,
    canvasSize,
    currentStep,
  ])

  // Update the animation loop useEffect to handle the new visualization types

  // Update the stepForward function to handle the new visualization types
  const stepForward = () => {
    if (
      compilerPhase === "lexical" ||
      compilerPhase === "semantic" ||
      compilerPhase === "intermediate" ||
      compilerPhase === "optimization" ||
      compilerPhase === "symbol-table" ||
      compilerPhase === "runtime"
    ) {
      if (currentTokenIndex < tokens.length - 1) {
        setCurrentTokenIndex(currentTokenIndex + 1)
      }
    } else if (compilerPhase === "parsing") {
      // Similar to the animation loop logic
      if (parseTree) {
        if (!currentParseNode) {
          setCurrentParseNode(parseTree)
        } else {
          const traverseNext = (node: ParseNode): ParseNode | null => {
            if (node === currentParseNode) {
              if (node.children.length > 0) {
                return node.children[0]
              } else {
                return findNextNode(parseTree, node)
              }
            }

            for (const child of node.children) {
              const result = traverseNext(child)
              if (result) return result
            }

            return null
          }

          const nextNode = traverseNext(parseTree)
          if (nextNode) {
            setCurrentParseNode(nextNode)
          }
        }
      }
    } else if (compilerPhase === "code-generation") {
      const lines = assemblyCode.split("\n")
      if (currentTokenIndex < lines.length - 2) {
        setCurrentTokenIndex(currentTokenIndex + 1)
        const visibleLines = lines.slice(0, currentTokenIndex + 2)
        setAssemblyCode(visibleLines.join("\n"))
      }
    }
  }

  // Update the resetVisualization function to handle the new visualization types
  const resetVisualization = () => {
    setIsPlaying(false)
    setCurrentTokenIndex(-1)
    setCurrentParseNode(null)

    if (compilerPhase === "lexical") {
      performLexicalAnalysis()
    } else if (compilerPhase === "parsing") {
      performParsing()
    } else if (compilerPhase === "semantic") {
      performSemanticAnalysis()
    } else if (compilerPhase === "intermediate") {
      generateIntermediateCode()
    } else if (compilerPhase === "optimization") {
      performOptimization()
    } else if (compilerPhase === "code-generation") {
      generateAssemblyCode()
      setCurrentTokenIndex(-1)
    } else if (compilerPhase === "symbol-table") {
      generateSymbolTable()
    } else if (compilerPhase === "runtime") {
      visualizeRuntime()
    }
  }

  // Start animation
  const startAnimation = () => {
    if (compilerPhase === "lexical" && tokens.length === 0) {
      performLexicalAnalysis()
    } else if (compilerPhase === "parsing" && !parseTree) {
      performParsing()
    } else if (compilerPhase === "code-generation" && !assemblyCode) {
      generateAssemblyCode()
    }

    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Step forward one step

  // Handle source code change
  const handleSourceCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSourceCode(e.target.value)
    resetVisualization()
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetVisualization}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={stepForward}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Compiler Phase</h3>
                    <Tabs
                      defaultValue="lexical"
                      value={compilerPhase}
                      onValueChange={(value) => {
                        setCompilerPhase(value)
                        resetVisualization()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="lexical">Lexical</TabsTrigger>
                        <TabsTrigger value="parsing">Parsing</TabsTrigger>
                        <TabsTrigger value="code-generation">Code Gen</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Source Code</h3>
                    <Textarea
                      value={sourceCode}
                      onChange={handleSourceCodeChange}
                      placeholder="Enter source code"
                      className="bg-gray-800/50 border-gray-700 text-white font-mono h-32"
                    />
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Compiler Phase Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {compilerPhase === "lexical" ? (
                        <>
                          <p>Lexical Analysis (Scanning) is the first phase of a compiler:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Reads the source code character by character</li>
                            <li>Groups characters into meaningful tokens</li>
                            <li>Identifies keywords, identifiers, operators, and literals</li>
                            <li>Removes whitespace and comments</li>
                            <li>Produces a stream of tokens for the parser</li>
                          </ul>
                        </>
                      ) : compilerPhase === "parsing" ? (
                        <>
                          <p>Syntax Analysis (Parsing) is the second phase of a compiler:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Takes the token stream from lexical analysis</li>
                            <li>Checks if the program structure follows the grammar rules</li>
                            <li>Builds a parse tree or abstract syntax tree (AST)</li>
                            <li>Detects syntax errors</li>
                            <li>Provides a structured representation of the program</li>
                          </ul>
                        </>
                      ) : (
                        <>
                          <p>Code Generation is the final phase of a compiler:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Transforms the intermediate representation into target code</li>
                            <li>Generates assembly or machine code</li>
                            <li>Handles memory allocation and register assignment</li>
                            <li>Applies optimizations to improve code efficiency</li>
                            <li>Produces executable code or object files</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="compilers" title="Compilers" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
