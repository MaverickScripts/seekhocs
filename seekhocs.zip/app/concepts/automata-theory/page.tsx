"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, RotateCcw, Play, Pause, ChevronRight, Info } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

// State class for automata
class State {
  id: string
  x: number
  y: number
  isStart: boolean
  isAccept: boolean
  isActive: boolean

  constructor(id: string, x: number, y: number, isStart = false, isAccept = false) {
    this.id = id
    this.x = x
    this.y = y
    this.isStart = isStart
    this.isAccept = isAccept
    this.isActive = false
  }
}

// Transition class for automata
class Transition {
  from: string
  to: string
  symbol: string
  isActive: boolean
  controlPoint: { x: number; y: number }

  constructor(from: string, to: string, symbol: string) {
    this.from = from
    this.to = to
    this.symbol = symbol
    this.isActive = false
    this.controlPoint = { x: 0, y: 0 }
  }
}

// Automaton class - base class for all automata types
class Automaton {
  states: State[]
  transitions: Transition[]
  tape: string[]
  headPosition: number
  currentState: string
  isHalted: boolean
  stack: string[] // For PDA

  constructor() {
    this.states = []
    this.transitions = []
    this.tape = Array(21).fill("_")
    this.headPosition = 10
    this.currentState = "q0"
    this.isHalted = false
    this.stack = ["Z0"] // Initial stack symbol for PDA
  }

  reset() {
    this.headPosition = 10
    this.currentState = this.states.find((s) => s.isStart)?.id || "q0"
    this.isHalted = false
    this.stack = ["Z0"]
    this.states.forEach((s) => (s.isActive = false))
    this.transitions.forEach((t) => (t.isActive = false))
  }

  step(): boolean {
    if (this.isHalted) return false

    // Find the current state
    const currentStateObj = this.states.find((s) => s.id === this.currentState)
    if (!currentStateObj) {
      this.isHalted = true
      return false
    }

    // Mark the current state as active
    this.states.forEach((s) => (s.isActive = s.id === this.currentState))

    // Get the current symbol
    const currentSymbol = this.tape[this.headPosition]

    // Find the transition
    let transition
    if (this.transitions.some((t) => t.symbol.includes(","))) {
      // Turing Machine or PDA transition format
      transition = this.transitions.find(
        (t) =>
          t.from === this.currentState && (t.symbol.split(",")[0] === currentSymbol || t.symbol.split(",")[0] === "ε"), // Support for epsilon transitions
      )
    } else {
      // DFA/NFA transition format: just the symbol
      transition = this.transitions.find(
        (t) => t.from === this.currentState && (t.symbol === currentSymbol || t.symbol === "ε"),
      )
    }

    // Reset all transitions
    this.transitions.forEach((t) => (t.isActive = false))

    if (!transition) {
      this.isHalted = true
      return false
    }

    // Mark the transition as active
    transition.isActive = true

    // For Turing Machine, update the tape and head position
    if (transition.symbol.includes(",")) {
      const parts = transition.symbol.split(",")

      if (parts.length === 3) {
        // Turing Machine format: read,write,move
        const [, writeSymbol, move] = parts
        this.tape[this.headPosition] = writeSymbol

        if (move === "R") {
          this.headPosition++
        } else if (move === "L") {
          this.headPosition--
        }
      } else if (parts.length === 4) {
        // PDA format: read,pop,push,move
        const [, pop, push, move] = parts

        // PDA stack operations
        if (pop !== "ε" && this.stack.length > 0 && this.stack[this.stack.length - 1] === pop) {
          this.stack.pop()
        }

        if (push !== "ε") {
          this.stack.push(push)
        }

        if (move === "R") {
          this.headPosition++
        }
      }
    } else {
      // For DFA/NFA, just move the head
      this.headPosition++
    }

    // Update current state
    this.currentState = transition.to

    return true
  }
}

// Factory to create different automata based on the type
class AutomataFactory {
  static createAutomaton(type: string): Automaton {
    const automaton = new Automaton()

    switch (type.toLowerCase()) {
      case "turing":
        this.initializeTuringMachine(automaton)
        break
      case "dfa":
        this.initializeDFA(automaton)
        break
      case "nfa":
        this.initializeNFA(automaton)
        break
      case "pda":
        this.initializePDA(automaton)
        break
      default:
        this.initializeTuringMachine(automaton)
    }

    return automaton
  }

  private static initializeTuringMachine(automaton: Automaton) {
    // Create states for a Turing Machine that recognizes palindromes
    automaton.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 250, 200, false, false),
      new State("q2", 400, 200, false, false),
      new State("q3", 550, 200, false, true),
      new State("q4", 400, 100, false, false),
    ]

    // Create transitions
    automaton.transitions = [
      new Transition("q0", "q1", "a,a,R"), // If see 'a', stay 'a', move right
      new Transition("q0", "q4", "b,b,R"), // If see 'b', stay 'b', move right
      new Transition("q0", "q3", "_,_,R"), // If see blank, accept

      new Transition("q1", "q1", "a,a,R"), // Keep moving right on 'a'
      new Transition("q1", "q1", "b,b,R"), // Keep moving right on 'b'
      new Transition("q1", "q2", "_,_,L"), // When reach blank, move left

      new Transition("q2", "q3", "a,_,L"), // If see 'a', erase it, move left
      new Transition("q2", "q4", "b,_,L"), // If see 'b', reject

      new Transition("q4", "q4", "a,a,L"), // Keep moving left on 'a'
      new Transition("q4", "q4", "b,b,L"), // Keep moving left on 'b'
      new Transition("q4", "q0", "_,_,R"), // When reach blank, move right
    ]

    // Set initial tape with a palindrome "aabaa"
    automaton.tape = Array(21).fill("_")
    const input = "aabaa".split("")
    for (let i = 0; i < input.length; i++) {
      automaton.tape[10 + i] = input[i]
    }
    automaton.reset()
  }

  private static initializeDFA(automaton: Automaton) {
    // Create states for a DFA that recognizes strings ending with "ab"
    automaton.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 300, 200, false, false),
      new State("q2", 500, 200, false, true),
    ]

    // Create transitions
    automaton.transitions = [
      new Transition("q0", "q0", "b"),
      new Transition("q0", "q1", "a"),
      new Transition("q1", "q0", "a"),
      new Transition("q1", "q2", "b"),
      new Transition("q2", "q0", "a"),
      new Transition("q2", "q0", "b"),
    ]

    // Set initial tape with a string "aab"
    automaton.tape = Array(21).fill("_")
    const input = "aab".split("")
    for (let i = 0; i < input.length; i++) {
      automaton.tape[10 + i] = input[i]
    }
    automaton.reset()
  }

  private static initializeNFA(automaton: Automaton) {
    // Create states for an NFA that recognizes strings with 'a' followed by either 'b' or 'c'
    automaton.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 300, 150, false, false),
      new State("q2", 300, 250, false, false),
      new State("q3", 500, 200, false, true),
    ]

    // Create transitions
    automaton.transitions = [
      new Transition("q0", "q1", "a"),
      new Transition("q0", "q2", "a"),
      new Transition("q1", "q3", "b"),
      new Transition("q2", "q3", "c"),
      new Transition("q3", "q3", "a"),
      new Transition("q3", "q3", "b"),
      new Transition("q3", "q3", "c"),
    ]

    // Set initial tape with a string "ab"
    automaton.tape = Array(21).fill("_")
    const input = "ab".split("")
    for (let i = 0; i < input.length; i++) {
      automaton.tape[10 + i] = input[i]
    }
    automaton.reset()
  }

  private static initializePDA(automaton: Automaton) {
    // Create states for a PDA that recognizes balanced parentheses
    automaton.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 300, 200, false, false),
      new State("q2", 500, 200, false, true),
    ]

    // Transitions for PDA (simplified visualization)
    // Format: read,pop,push,move
    automaton.transitions = [
      new Transition("q0", "q1", "(,Z0,X,R"), // Push X on stack when seeing (
      new Transition("q1", "q1", "(,X,XX,R"), // Push X on stack when seeing (
      new Transition("q1", "q1", "),X,ε,R"), // Pop X from stack when seeing )
      new Transition("q1", "q2", "ε,Z0,Z0,R"), // Epsilon transition to accept state if stack has only Z0
    ]

    // Set initial tape with a string "(())"
    automaton.tape = Array(21).fill("_")
    const input = "(())".split("")
    for (let i = 0; i < input.length; i++) {
      automaton.tape[10 + i] = input[i]
    }
    automaton.reset()
  }
}

export default function AutomataTheoryPage() {
  const [automataType, setAutomataType] = useState("turing")
  const [automaton, setAutomaton] = useState<Automaton>(AutomataFactory.createAutomaton("turing"))
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [inputString, setInputString] = useState("aabaa")
  const [message, setMessage] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const animationRef = useRef<number | null>(null)
  const [activeTab, setActiveTab] = useState("theory")

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Initialize automaton based on selected type
  useEffect(() => {
    // Reset animation state
    setIsPlaying(false)
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }

    // Create a new automaton based on the selected type
    const newAutomaton = AutomataFactory.createAutomaton(automataType)
    setAutomaton(newAutomaton)

    // Set default input string based on automata type
    if (automataType === "turing") {
      setInputString("aabaa")
      setMessage("Turing Machine: A model of computation with a tape and a finite set of states.")
    } else if (automataType === "dfa") {
      setInputString("aab")
      setMessage("DFA: A finite automaton where each state has exactly one transition for each possible input.")
    } else if (automataType === "nfa") {
      setInputString("ab")
      setMessage("NFA: A finite automaton that can transition to multiple states for a given input symbol.")
    } else if (automataType === "pda") {
      setInputString("(())")
      setMessage("PDA: A finite automaton with a stack memory, capable of recognizing context-free languages.")
    }
  }, [automataType])

  // Animation loop
  useEffect(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }

    if (isPlaying) {
      const animate = () => {
        const success = automaton.step()

        if (!success) {
          setIsPlaying(false)
          const acceptState = automaton.states.find((s) => s.id === automaton.currentState && s.isAccept)
          setMessage(
            acceptState
              ? `${automataType.toUpperCase()} halted in an accept state. Input is accepted.`
              : `${automataType.toUpperCase()} halted in a non-accept state. Input is rejected.`,
          )
        } else {
          // Schedule next animation frame based on speed
          const delay = Math.max(10, 1000 - speed * 9)
          setTimeout(() => {
            animationRef.current = requestAnimationFrame(animate)
          }, delay)
        }
      }

      animationRef.current = requestAnimationFrame(animate)
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
        animationRef.current = null
      }
    }
  }, [isPlaying, automaton, automataType, speed])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (automataType === "turing") {
      drawTuringMachine(ctx)
    } else if (automataType === "dfa" || automataType === "nfa") {
      drawFiniteAutomaton(ctx)
    } else if (automataType === "pda") {
      drawPushdownAutomaton(ctx)
    }
  }, [automaton, automataType, canvasSize, inputString])

  // Draw Turing Machine
  const drawTuringMachine = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw tape
    const cellSize = 30
    const tapeY = height * 0.3
    const tapeStartX = width / 2 - (automaton.tape.length * cellSize) / 2

    // Draw tape cells
    for (let i = 0; i < automaton.tape.length; i++) {
      const x = tapeStartX + i * cellSize

      // Highlight the current head position
      if (i === automaton.headPosition) {
        ctx.fillStyle = "#3b82f6"
        ctx.fillRect(x, tapeY, cellSize, cellSize)
      } else {
        ctx.fillStyle = "#1e293b"
        ctx.fillRect(x, tapeY, cellSize, cellSize)
      }

      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 1
      ctx.strokeRect(x, tapeY, cellSize, cellSize)

      // Draw symbol
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(automaton.tape[i], x + cellSize / 2, tapeY + cellSize / 2)
    }

    // Draw head
    const headX = tapeStartX + automaton.headPosition * cellSize + cellSize / 2
    ctx.beginPath()
    ctx.moveTo(headX, tapeY + cellSize + 5)
    ctx.lineTo(headX - 10, tapeY + cellSize + 20)
    ctx.lineTo(headX + 10, tapeY + cellSize + 20)
    ctx.closePath()
    ctx.fillStyle = "#3b82f6"
    ctx.fill()

    // Draw states
    drawStates(ctx)

    // Draw transitions
    drawTransitions(ctx)

    // Draw input string
    drawInputString(ctx, height)

    // Reset shadow
    ctx.shadowBlur = 0
  }

  // Draw Finite Automaton (DFA/NFA)
  const drawFiniteAutomaton = (ctx: CanvasRenderingContext2D) => {
    const height = canvasSize.height

    // Draw states
    drawStates(ctx)

    // Draw transitions
    drawTransitions(ctx)

    // Draw input string
    drawInputString(ctx, height)

    // Reset shadow
    ctx.shadowBlur = 0
  }

  // Draw Pushdown Automaton
  const drawPushdownAutomaton = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw states
    drawStates(ctx)

    // Draw transitions
    drawTransitions(ctx)

    // Draw input string
    drawInputString(ctx, height)

    // Draw stack
    drawStack(ctx, width, height)

    // Reset shadow
    ctx.shadowBlur = 0
  }

  // Draw states
  const drawStates = (ctx: CanvasRenderingContext2D) => {
    automaton.states.forEach((state) => {
      // Draw state circle
      ctx.beginPath()
      ctx.arc(state.x, state.y, 25, 0, Math.PI * 2)

      // Fill based on state properties
      if (state.isActive) {
        ctx.fillStyle = "#3b82f6"
        ctx.shadowColor = "#3b82f6"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#1e293b"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw double circle for accept states
      if (state.isAccept) {
        ctx.beginPath()
        ctx.arc(state.x, state.y, 20, 0, Math.PI * 2)
        ctx.strokeStyle = "#3b82f6"
        ctx.stroke()
      }

      // Draw arrow for start state
      if (state.isStart) {
        ctx.beginPath()
        ctx.moveTo(state.x - 40, state.y)
        ctx.lineTo(state.x - 25, state.y)
        ctx.strokeStyle = "#3b82f6"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(state.x - 25, state.y)
        ctx.lineTo(state.x - 35, state.y - 5)
        ctx.lineTo(state.x - 35, state.y + 5)
        ctx.closePath()
        ctx.fillStyle = "#3b82f6"
        ctx.fill()
      }

      // Draw state label
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(state.id, state.x, state.y)
    })
  }

  // Draw transitions
  const drawTransitions = (ctx: CanvasRenderingContext2D) => {
    automaton.transitions.forEach((transition) => {
      const fromState = automaton.states.find((s) => s.id === transition.from)
      const toState = automaton.states.find((s) => s.id === transition.to)

      if (fromState && toState) {
        // Self-loop
        if (fromState === toState) {
          ctx.beginPath()
          ctx.arc(fromState.x, fromState.y - 35, 15, 0.3 * Math.PI, 0.7 * Math.PI)

          if (transition.isActive) {
            ctx.strokeStyle = "#3b82f6"
            ctx.lineWidth = 3
            ctx.shadowColor = "#3b82f6"
            ctx.shadowBlur = 10
          } else {
            ctx.strokeStyle = "#3b82f6"
            ctx.lineWidth = 2
            ctx.shadowBlur = 0
          }

          ctx.stroke()

          // Draw arrowhead
          const angle = 0.7 * Math.PI
          const arrowX = fromState.x + 15 * Math.cos(angle)
          const arrowY = fromState.y - 35 + 15 * Math.sin(angle)

          ctx.beginPath()
          ctx.moveTo(arrowX, arrowY)
          ctx.lineTo(arrowX + 8 * Math.cos(angle - Math.PI / 6), arrowY + 8 * Math.sin(angle - Math.PI / 6))
          ctx.lineTo(arrowX + 8 * Math.cos(angle + Math.PI / 6), arrowY + 8 * Math.sin(angle + Math.PI / 6))
          ctx.closePath()
          ctx.fillStyle = transition.isActive ? "#3b82f6" : "#3b82f6"
          ctx.fill()

          // Draw transition label
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(transition.symbol, fromState.x, fromState.y - 55)
        } else {
          // Regular transition
          const angle = Math.atan2(toState.y - fromState.y, toState.x - fromState.x)
          const fromX = fromState.x + 25 * Math.cos(angle)
          const fromY = fromState.y + 25 * Math.sin(angle)
          const toX = toState.x - 25 * Math.cos(angle)
          const toY = toState.y - 25 * Math.sin(angle)

          ctx.beginPath()
          ctx.moveTo(fromX, fromY)
          ctx.lineTo(toX, toY)

          if (transition.isActive) {
            ctx.strokeStyle = "#3b82f6"
            ctx.lineWidth = 3
            ctx.shadowColor = "#3b82f6"
            ctx.shadowBlur = 10
          } else {
            ctx.strokeStyle = "#3b82f6"
            ctx.lineWidth = 2
            ctx.shadowBlur = 0
          }

          ctx.stroke()

          // Draw arrowhead
          ctx.beginPath()
          ctx.moveTo(toX, toY)
          ctx.lineTo(toX - 10 * Math.cos(angle - Math.PI / 6), toY - 10 * Math.sin(angle - Math.PI / 6))
          ctx.lineTo(toX - 10 * Math.cos(angle + Math.PI / 6), toY - 10 * Math.sin(angle + Math.PI / 6))
          ctx.closePath()
          ctx.fillStyle = transition.isActive ? "#3b82f6" : "#3b82f6"
          ctx.fill()

          // Draw transition label
          const midX = (fromX + toX) / 2
          const midY = (fromY + toY) / 2 - 10
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"

          // For PDA transitions, format the label nicely
          if (automataType === "pda" && transition.symbol.includes(",")) {
            const [input, pop, push] = transition.symbol.split(",")
            ctx.fillText(`${input}, ${pop} → ${push}`, midX, midY)
          } else {
            ctx.fillText(transition.symbol, midX, midY)
          }
        }
      }
    })
  }

  // Draw input string
  const drawInputString = (ctx: CanvasRenderingContext2D, height: number) => {
    const width = canvasSize.width
    const inputY = height * 0.8
    const inputStartX = width / 2 - (inputString.length * 30) / 2

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Input String:", inputStartX - 80, inputY)

    for (let i = 0; i < inputString.length; i++) {
      const x = inputStartX + i * 30

      // Highlight the current position
      if (i === automaton.headPosition - 10) {
        ctx.fillStyle = "#3b82f6"
        ctx.fillRect(x - 15, inputY - 15, 30, 30)
      }

      ctx.fillStyle = "#ffffff"
      ctx.font = "16px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(inputString[i], x, inputY)
    }
  }

  // Draw stack for PDA
  const drawStack = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const stackX = width * 0.8
    const stackY = height * 0.5
    const stackWidth = 40
    const stackItemHeight = 30

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Stack:", stackX, stackY - 50)

    // Draw stack items
    for (let i = 0; i < automaton.stack.length; i++) {
      const y = stackY + i * stackItemHeight

      ctx.fillStyle = "#1e293b"
      ctx.fillRect(stackX - stackWidth / 2, y, stackWidth, stackItemHeight)

      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 1
      ctx.strokeRect(stackX - stackWidth / 2, y, stackWidth, stackItemHeight)

      ctx.fillStyle = "#ffffff"
      ctx.font = "14px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(automaton.stack[automaton.stack.length - 1 - i], stackX, y + stackItemHeight / 2)
    }
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }
  }

  // Reset animation
  const resetAnimation = () => {
    setIsPlaying(false)
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
      animationRef.current = null
    }

    automaton.reset()

    if (automataType === "turing") {
      setMessage("Turing Machine: A model of computation with a tape and a finite set of states.")
    } else if (automataType === "dfa") {
      setMessage("DFA: A finite automaton where each state has exactly one transition for each possible input.")
    } else if (automataType === "nfa") {
      setMessage("NFA: A finite automaton that can transition to multiple states for a given input symbol.")
    } else if (automataType === "pda") {
      setMessage("PDA: A finite automaton with a stack memory, capable of recognizing context-free languages.")
    }
  }

  // Handle input string change
  const handleInputStringChange = (value: string) => {
    setInputString(value)

    // Update the tape for the machine
    if (automataType === "dfa" || automataType === "nfa" || automataType === "pda" || automataType === "turing") {
      automaton.tape = Array(21).fill("_")
      const input = value.split("")
      for (let i = 0; i < input.length; i++) {
        automaton.tape[10 + i] = input[i]
      }
      automaton.reset()
    }
  }

  // Step forward one step
  const stepForward = () => {
    automaton.step()
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
        animationRef.current = null
      }
    }
  }, [])

  // Theory content for each automata type
  const getTheoryContent = () => {
    switch (automataType) {
      case "turing":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Turing Machines</h3>
            <p>
              A Turing machine is a mathematical model of computation that defines an abstract machine, which
              manipulates symbols on a strip of tape according to a table of rules. Despite the model's simplicity,
              given any computer algorithm, a Turing machine capable of simulating that algorithm's logic can be
              constructed.
            </p>
            <h4 className="text-lg font-medium mt-4">Components:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <strong>Tape:</strong> An infinite strip divided into cells, each containing a symbol from a finite
                alphabet
              </li>
              <li>
                <strong>Head:</strong> A device that can read and write symbols on the tape and move left or right
              </li>
              <li>
                <strong>State register:</strong> Stores the state of the Turing machine, one of finitely many states
              </li>
              <li>
                <strong>Transition function:</strong> A table of instructions that, given the current state and the
                symbol under the head, tells the machine what to write, how to move the head, and what the new state
                should be
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Formal Definition:</h4>
            <p>A Turing machine can be formally defined as a 7-tuple:</p>
            <p className="font-mono bg-gray-800/50 p-2 rounded">M = (Q, Γ, b, Σ, δ, q₀, F)</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>
                <strong>Q:</strong> A finite set of states
              </li>
              <li>
                <strong>Γ:</strong> A finite set of tape alphabet symbols
              </li>
              <li>
                <strong>b ∈ Γ:</strong> The blank symbol
              </li>
              <li>
                <strong>Σ ⊆ Γ \ {"{b}"}:</strong> The set of input symbols
              </li>
              <li>
                <strong>δ: Q × Γ → Q × Γ × {"{L,R}"}:</strong> The transition function
              </li>
              <li>
                <strong>q₀ ∈ Q:</strong> The initial state
              </li>
              <li>
                <strong>F ⊆ Q:</strong> The set of final or accepting states
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Significance:</h4>
            <p>
              Turing machines are central to the theory of computation. They are equivalent to many other models of
              computation, such as lambda calculus and recursive functions. The Church-Turing thesis states that any
              function that can be computed by an algorithm can be computed by a Turing machine.
            </p>
            <p>
              The concept of Turing machines has led to important theoretical results, such as the halting problem,
              which proves that there are problems that cannot be solved algorithmically.
            </p>
          </div>
        )
      case "dfa":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Deterministic Finite Automata (DFA)</h3>
            <p>
              A Deterministic Finite Automaton (DFA) is a finite-state machine that accepts or rejects strings of
              symbols. "Deterministic" means that for each state and input symbol, there is exactly one transition to a
              next state.
            </p>
            <h4 className="text-lg font-medium mt-4">Components:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <strong>States:</strong> A finite set of states
              </li>
              <li>
                <strong>Alphabet:</strong> A finite set of input symbols
              </li>
              <li>
                <strong>Transition function:</strong> Maps state-symbol pairs to states
              </li>
              <li>
                <strong>Start state:</strong> The initial state of the automaton
              </li>
              <li>
                <strong>Accept states:</strong> A set of states that indicate acceptance of the input
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Formal Definition:</h4>
            <p>A DFA can be formally defined as a 5-tuple:</p>
            <p className="font-mono bg-gray-800/50 p-2 rounded">A = (Q, Σ, δ, q₀, F)</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>
                <strong>Q:</strong> A finite set of states
              </li>
              <li>
                <strong>Σ:</strong> A finite set of input symbols (alphabet)
              </li>
              <li>
                <strong>δ: Q × Σ → Q:</strong> The transition function
              </li>
              <li>
                <strong>q₀ ∈ Q:</strong> The initial state
              </li>
              <li>
                <strong>F ⊆ Q:</strong> The set of accept states
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Properties:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>DFAs recognize exactly the set of regular languages</li>
              <li>For every DFA, there exists an equivalent regular expression, and vice versa (Kleene's theorem)</li>
              <li>DFAs are closed under union, intersection, concatenation, and complement operations</li>
              <li>
                Minimizing a DFA produces a unique minimal DFA with the fewest possible states that recognizes the same
                language
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Applications:</h4>
            <p>
              DFAs are used in lexical analysis in compilers, text processing, pattern matching, and protocol
              verification. They provide a simple and efficient way to recognize patterns in strings.
            </p>
          </div>
        )
      case "nfa":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Non-deterministic Finite Automata (NFA)</h3>
            <p>
              A Non-deterministic Finite Automaton (NFA) is a finite-state machine where for some state and input
              symbol, the next state may be ambiguous. Unlike a DFA, an NFA can transition to multiple states for the
              same input symbol, or even transition without consuming an input symbol (ε-transitions).
            </p>
            <h4 className="text-lg font-medium mt-4">Components:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <strong>States:</strong> A finite set of states
              </li>
              <li>
                <strong>Alphabet:</strong> A finite set of input symbols
              </li>
              <li>
                <strong>Transition function:</strong> Maps state-symbol pairs to sets of states
              </li>
              <li>
                <strong>Start state:</strong> The initial state of the automaton
              </li>
              <li>
                <strong>Accept states:</strong> A set of states that indicate acceptance of the input
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Formal Definition:</h4>
            <p>An NFA can be formally defined as a 5-tuple:</p>
            <p className="font-mono bg-gray-800/50 p-2 rounded">N = (Q, Σ, δ, q₀, F)</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>
                <strong>Q:</strong> A finite set of states
              </li>
              <li>
                <strong>Σ:</strong> A finite set of input symbols (alphabet)
              </li>
              <li>
                <strong>δ: Q × (Σ ∪ {"{ε}"}) → P(Q):</strong> The transition function (P(Q) is the power set of Q)
              </li>
              <li>
                <strong>q₀ ∈ Q:</strong> The initial state
              </li>
              <li>
                <strong>F ⊆ Q:</strong> The set of accept states
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Properties:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                NFAs and DFAs are equivalent in power; any language recognized by an NFA can also be recognized by a DFA
              </li>
              <li>
                Converting an NFA to a DFA may result in an exponential increase in the number of states (subset
                construction)
              </li>
              <li>NFAs are often more compact and easier to design than equivalent DFAs</li>
              <li>
                ε-transitions allow an NFA to change state without consuming an input symbol, which can simplify the
                design
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Applications:</h4>
            <p>
              NFAs are particularly useful in pattern matching, regular expression processing, and lexical analysis.
              They provide a more intuitive way to design automata for certain problems, even though they are eventually
              converted to DFAs for implementation.
            </p>
          </div>
        )
      case "pda":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Pushdown Automata (PDA)</h3>
            <p>
              A Pushdown Automaton (PDA) is a finite-state machine with an additional stack memory. This stack allows
              PDAs to recognize context-free languages, which are more complex than the regular languages recognized by
              finite automata.
            </p>
            <h4 className="text-lg font-medium mt-4">Components:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>
                <strong>States:</strong> A finite set of states
              </li>
              <li>
                <strong>Input alphabet:</strong> A finite set of input symbols
              </li>
              <li>
                <strong>Stack alphabet:</strong> A finite set of stack symbols
              </li>
              <li>
                <strong>Transition function:</strong> Based on the current state, input symbol, and top stack symbol
              </li>
              <li>
                <strong>Start state:</strong> The initial state of the automaton
              </li>
              <li>
                <strong>Initial stack symbol:</strong> The symbol initially on the stack
              </li>
              <li>
                <strong>Accept states:</strong> A set of states that indicate acceptance of the input
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Formal Definition:</h4>
            <p>A PDA can be formally defined as a 7-tuple:</p>
            <p className="font-mono bg-gray-800/50 p-2 rounded">P = (Q, Σ, Γ, δ, q₀, Z₀, F)</p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>
                <strong>Q:</strong> A finite set of states
              </li>
              <li>
                <strong>Σ:</strong> A finite set of input symbols (input alphabet)
              </li>
              <li>
                <strong>Γ:</strong> A finite set of stack symbols (stack alphabet)
              </li>
              <li>
                <strong>δ: Q × (Σ ∪ {"{ε}"}) × Γ → P(Q × Γ*):</strong> The transition function
              </li>
              <li>
                <strong>q₀ ∈ Q:</strong> The initial state
              </li>
              <li>
                <strong>Z₀ ∈ Γ:</strong> The initial stack symbol
              </li>
              <li>
                <strong>F ⊆ Q:</strong> The set of accept states
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Properties:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>PDAs recognize exactly the set of context-free languages</li>
              <li>
                For every context-free grammar, there exists an equivalent PDA, and vice versa (this is a fundamental
                result in the theory of computation)
              </li>
              <li>
                PDAs are more powerful than finite automata but less powerful than Turing machines in the Chomsky
                hierarchy
              </li>
              <li>
                Deterministic PDAs (DPDAs) are less powerful than non-deterministic PDAs; they recognize only the
                deterministic context-free languages
              </li>
            </ul>
            <h4 className="text-lg font-medium mt-4">Applications:</h4>
            <p>
              PDAs are primarily used in parsing context-free languages, such as programming languages. They form the
              theoretical basis for many parsing algorithms, including recursive-descent parsing and LR parsing, which
              are used in compiler design.
            </p>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 text-white"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Automata Theory
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Explore the theoretical foundations of computation through interactive visualizations
          </motion.p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="theory">Theory</TabsTrigger>
            <TabsTrigger value="visualization">Interactive Visualization</TabsTrigger>
          </TabsList>

          <TabsContent value="theory" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="lg:col-span-2 border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="prose prose-invert max-w-none">{getTheoryContent()}</div>
                </CardContent>
              </Card>

              <div className="space-y-8">
                <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-white mb-6">Automata Types</h2>
                    <div className="space-y-4">
                      <Button
                        variant={automataType === "turing" ? "default" : "outline"}
                        className={`w-full justify-start ${
                          automataType === "turing" ? "bg-blue-600 hover:bg-blue-700" : ""
                        }`}
                        onClick={() => setAutomataType("turing")}
                      >
                        Turing Machines
                      </Button>
                      <Button
                        variant={automataType === "dfa" ? "default" : "outline"}
                        className={`w-full justify-start ${
                          automataType === "dfa" ? "bg-blue-600 hover:bg-blue-700" : ""
                        }`}
                        onClick={() => setAutomataType("dfa")}
                      >
                        Deterministic Finite Automata
                      </Button>
                      <Button
                        variant={automataType === "nfa" ? "default" : "outline"}
                        className={`w-full justify-start ${
                          automataType === "nfa" ? "bg-blue-600 hover:bg-blue-700" : ""
                        }`}
                        onClick={() => setAutomataType("nfa")}
                      >
                        Non-deterministic Finite Automata
                      </Button>
                      <Button
                        variant={automataType === "pda" ? "default" : "outline"}
                        className={`w-full justify-start ${
                          automataType === "pda" ? "bg-blue-600 hover:bg-blue-700" : ""
                        }`}
                        onClick={() => setAutomataType("pda")}
                      >
                        Pushdown Automata
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-white mb-4">Key Concepts</h2>
                    <ul className="space-y-2">
                      <li>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center text-blue-400 hover:text-blue-300 cursor-help">
                                <Info className="h-4 w-4 mr-2" />
                                <span>Chomsky Hierarchy</span>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p>
                                A containment hierarchy of classes of formal grammars that generate formal languages,
                                from Type-0 (unrestricted) to Type-3 (regular).
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </li>
                      <li>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center text-blue-400 hover:text-blue-300 cursor-help">
                                <Info className="h-4 w-4 mr-2" />
                                <span>Regular Languages</span>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p>
                                Languages that can be recognized by finite automata, represented by regular expressions,
                                and generated by regular grammars.
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </li>
                      <li>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center text-blue-400 hover:text-blue-300 cursor-help">
                                <Info className="h-4 w-4 mr-2" />
                                <span>Context-Free Languages</span>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p>
                                Languages that can be recognized by pushdown automata and generated by context-free
                                grammars.
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </li>
                      <li>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center text-blue-400 hover:text-blue-300 cursor-help">
                                <Info className="h-4 w-4 mr-2" />
                                <span>Decidability</span>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p>
                                The property of a decision problem having an algorithm that can determine whether the
                                answer is yes or no in a finite amount of time.
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </li>
                      <li>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center text-blue-400 hover:text-blue-300 cursor-help">
                                <Info className="h-4 w-4 mr-2" />
                                <span>Halting Problem</span>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p>
                                The problem of determining, from a description of an arbitrary computer program and an
                                input, whether the program will finish running or continue to run forever.
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="visualization" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <motion.div
                className="lg:col-span-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h2 className="text-xl font-semibold text-white">
                        {automataType === "turing"
                          ? "Turing Machine"
                          : automataType === "dfa"
                            ? "Deterministic Finite Automaton"
                            : automataType === "nfa"
                              ? "Non-deterministic Finite Automaton"
                              : "Pushdown Automaton"}
                      </h2>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={resetAnimation}
                          className="border-gray-700 text-gray-300 hover:text-white"
                        >
                          <RotateCcw className="h-4 w-4 mr-2" />
                          Reset
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={stepForward}
                          className="border-gray-700 text-gray-300 hover:text-white"
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                        {isPlaying ? (
                          <Button
                            size="sm"
                            onClick={pauseAnimation}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            <Pause className="h-4 w-4 mr-2" />
                            Pause
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            onClick={startAnimation}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Start
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                      <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                    </div>

                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-blue-400"
                    >
                      {message}
                    </motion.div>

                    <div className="mt-6 flex items-center space-x-4">
                      <span className="text-sm text-gray-400">Speed:</span>
                      <Slider
                        value={[speed]}
                        min={1}
                        max={100}
                        step={1}
                        onValueChange={(value) => setSpeed(value[0])}
                        className="flex-1"
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm mt-6">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-white mb-4">How It Works</h2>
                    {automataType === "turing" && (
                      <div className="space-y-2 text-sm text-gray-300">
                        <p>This Turing Machine visualization demonstrates a palindrome recognizer:</p>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>The machine reads the input string from left to right</li>
                          <li>It marks each character as it processes it</li>
                          <li>When it reaches the end, it moves back to check if the string is a palindrome</li>
                          <li>If the string reads the same forward and backward, it accepts</li>
                          <li>Otherwise, it rejects</li>
                        </ul>
                        <p className="mt-2">
                          Try different inputs like "abba", "racecar", or "hello" to see how the machine behaves!
                        </p>
                      </div>
                    )}
                    {automataType === "dfa" && (
                      <div className="space-y-2 text-sm text-gray-300">
                        <p>This DFA visualization demonstrates a machine that recognizes strings ending with "ab":</p>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>The machine starts in state q0</li>
                          <li>When it sees an 'a', it transitions to state q1</li>
                          <li>When it sees a 'b' in state q1, it transitions to the accepting state q2</li>
                          <li>Any other transitions return to non-accepting states</li>
                        </ul>
                        <p className="mt-2">
                          Try inputs like "ab", "aab", "ababab" to see acceptance, and "a", "b", "aba" to see rejection!
                        </p>
                      </div>
                    )}
                    {automataType === "nfa" && (
                      <div className="space-y-2 text-sm text-gray-300">
                        <p>
                          This NFA visualization demonstrates a machine that recognizes strings with 'a' followed by
                          either 'b' or 'c':
                        </p>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>The machine starts in state q0</li>
                          <li>From q0, on input 'a', it can non-deterministically go to either q1 or q2</li>
                          <li>From q1, on input 'b', it goes to the accepting state q3</li>
                          <li>From q2, on input 'c', it goes to the accepting state q3</li>
                        </ul>
                        <p className="mt-2">
                          Try inputs like "ab", "ac", "abc" to see how the machine handles different paths!
                        </p>
                      </div>
                    )}
                    {automataType === "pda" && (
                      <div className="space-y-2 text-sm text-gray-300">
                        <p>
                          This PDA visualization demonstrates a machine that recognizes balanced parentheses (a classic
                          context-free language):
                        </p>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>The machine uses a stack to keep track of opening parentheses</li>
                          <li>When it sees an opening parenthesis '(', it pushes a symbol onto the stack</li>
                          <li>When it sees a closing parenthesis ')', it pops a symbol from the stack</li>
                          <li>The input is accepted if the stack is empty at the end (all parentheses matched)</li>
                        </ul>
                        <p className="mt-2">
                          Try inputs like "()", "(())", "()()" to see acceptance, and ")(", "(()" to see rejection!
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
                className="space-y-8"
              >
                <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                    <div className="space-y-6">
                      <div>
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Automata Type</h3>
                        <div className="grid grid-cols-2 gap-2">
                          <Button
                            variant={automataType === "turing" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setAutomataType("turing")}
                            className={automataType === "turing" ? "bg-blue-600 hover:bg-blue-700" : ""}
                          >
                            Turing Machine
                          </Button>
                          <Button
                            variant={automataType === "dfa" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setAutomataType("dfa")}
                            className={automataType === "dfa" ? "bg-blue-600 hover:bg-blue-700" : ""}
                          >
                            DFA
                          </Button>
                          <Button
                            variant={automataType === "nfa" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setAutomataType("nfa")}
                            className={automataType === "nfa" ? "bg-blue-600 hover:bg-blue-700" : ""}
                          >
                            NFA
                          </Button>
                          <Button
                            variant={automataType === "pda" ? "default" : "outline"}
                            size="sm"
                            onClick={() => setAutomataType("pda")}
                            className={automataType === "pda" ? "bg-blue-600 hover:bg-blue-700" : ""}
                          >
                            PDA
                          </Button>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Input String</h3>
                        <Input
                          type="text"
                          value={inputString}
                          onChange={(e) => handleInputStringChange(e.target.value)}
                          className="w-full p-2 bg-gray-800/50 border border-gray-700 rounded-md text-white"
                          placeholder="Enter input string"
                        />
                        <p className="text-xs text-gray-500 mt-1">Enter a string to test with the current automaton</p>
                      </div>

                      <div className="pt-4 border-t border-gray-800">
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Legend</h3>
                        <div className="space-y-2 text-sm text-gray-300">
                          <div className="flex items-center">
                            <div className="w-4 h-4 rounded-full bg-blue-500 mr-2"></div>
                            <span>Active state</span>
                          </div>
                          <div className="flex items-center">
                            <div className="w-4 h-4 rounded-full border-2 border-blue-500 mr-2"></div>
                            <span>Accept state (double circle)</span>
                          </div>
                          <div className="flex items-center">
                            <div className="w-4 h-4 flex items-center justify-center mr-2">
                              <ArrowLeft className="h-3 w-3 text-blue-500" />
                            </div>
                            <span>Start state (incoming arrow)</span>
                          </div>
                          <div className="flex items-center">
                            <div className="w-4 h-4 bg-blue-500/20 mr-2"></div>
                            <span>Current tape position</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-white mb-4">Applications</h2>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li>
                        <strong className="text-blue-400">Compiler Design:</strong> Automata theory forms the basis of
                        lexical analysis and parsing in compilers
                      </li>
                      <li>
                        <strong className="text-blue-400">Text Processing:</strong> Regular expressions (equivalent to
                        finite automata) are used for pattern matching and text manipulation
                      </li>
                      <li>
                        <strong className="text-blue-400">Protocol Verification:</strong> Automata can model and verify
                        communication protocols
                      </li>
                      <li>
                        <strong className="text-blue-400">Natural Language Processing:</strong> Context-free grammars
                        and PDAs are used in parsing natural language
                      </li>
                      <li>
                        <strong className="text-blue-400">Computational Complexity:</strong> Automata theory helps
                        classify problems based on their computational difficulty
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
