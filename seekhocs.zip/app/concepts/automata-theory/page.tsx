"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// State class for automata
class State {
  id: string
  x: number
  y: number
  isStart: boolean
  isAccept: boolean
  isActive: boolean

  constructor(id: string, x: number, y: number, isStart = false, isAccept = false) {
    this.id = id
    this.x = x
    this.y = y
    this.isStart = isStart
    this.isAccept = isAccept
    this.isActive = false
  }
}

// Transition class for automata
class Transition {
  from: string
  to: string
  symbol: string
  isActive: boolean
  controlPoint: { x: number; y: number }

  constructor(from: string, to: string, symbol: string) {
    this.from = from
    this.to = to
    this.symbol = symbol
    this.isActive = false
    this.controlPoint = { x: 0, y: 0 }
  }
}

// Turing Machine class
class TuringMachine {
  states: State[]
  transitions: Transition[]
  tape: string[]
  headPosition: number
  currentState: string
  isHalted: boolean

  constructor() {
    this.states = []
    this.transitions = []
    this.tape = Array(21).fill("_")
    this.headPosition = 10
    this.currentState = "q0"
    this.isHalted = false
  }

  // Initialize a simple Turing machine that recognizes palindromes
  initializePalindromeTM() {
    // Create states
    this.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 250, 200, false, false),
      new State("q2", 400, 200, false, false),
      new State("q3", 550, 200, false, true),
      new State("q4", 400, 100, false, false),
    ]

    // Create transitions
    this.transitions = [
      new Transition("q0", "q1", "a,a,R"), // If see 'a', stay 'a', move right
      new Transition("q0", "q4", "b,b,R"), // If see 'b', stay 'b', move right
      new Transition("q0", "q3", "_,_,R"), // If see blank, accept

      new Transition("q1", "q1", "a,a,R"), // Keep moving right on 'a'
      new Transition("q1", "q1", "b,b,R"), // Keep moving right on 'b'
      new Transition("q1", "q2", "_,_,L"), // When reach blank, move left

      new Transition("q2", "q3", "a,_,L"), // If see 'a', erase it, move left
      new Transition("q2", "q4", "b,_,L"), // If see 'b', reject

      new Transition("q4", "q4", "a,a,L"), // Keep moving left on 'a'
      new Transition("q4", "q4", "b,b,L"), // Keep moving left on 'b'
      new Transition("q4", "q0", "_,_,R"), // When reach blank, move right
    ]

    // Set initial tape with a palindrome "aabaa"
    this.tape = Array(21).fill("_")
    const input = "aabaa".split("")
    for (let i = 0; i < input.length; i++) {
      this.tape[10 + i] = input[i]
    }
    this.headPosition = 10
    this.currentState = "q0"
    this.isHalted = false
  }

  // Initialize a simple DFA that recognizes strings ending with "ab"
  initializeDFA() {
    // Create states
    this.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 300, 200, false, false),
      new State("q2", 500, 200, false, true),
    ]

    // Create transitions
    this.transitions = [
      new Transition("q0", "q0", "b"),
      new Transition("q0", "q1", "a"),
      new Transition("q1", "q0", "a"),
      new Transition("q1", "q2", "b"),
      new Transition("q2", "q0", "a"),
      new Transition("q2", "q0", "b"),
    ]

    // Set initial tape with a string "aab"
    this.tape = Array(21).fill("_")
    const input = "aab".split("")
    for (let i = 0; i < input.length; i++) {
      this.tape[10 + i] = input[i]
    }
    this.headPosition = 10
    this.currentState = "q0"
    this.isHalted = false
  }

  // Initialize a simple NFA
  initializeNFA() {
    // Create states
    this.states = [
      new State("q0", 100, 200, true, false),
      new State("q1", 300, 150, false, false),
      new State("q2", 300, 250, false, false),
      new State("q3", 500, 200, false, true),
    ]

    // Create transitions
    this.transitions = [
      new Transition("q0", "q1", "a"),
      new Transition("q0", "q2", "a"),
      new Transition("q1", "q3", "b"),
      new Transition("q2", "q3", "c"),
      new Transition("q3", "q3", "a"),
      new Transition("q3", "q3", "b"),
      new Transition("q3", "q3", "c"),
    ]

    // Set initial tape with a string "ab"
    this.tape = Array(21).fill("_")
    const input = "ab".split("")
    for (let i = 0; i < input.length; i++) {
      this.tape[10 + i] = input[i]
    }
    this.headPosition = 10
    this.currentState = "q0"
    this.isHalted = false
  }

  // Step function for Turing Machine
  step(): boolean {
    if (this.isHalted) return false

    // Find the current state
    const currentStateObj = this.states.find((s) => s.id === this.currentState)
    if (!currentStateObj) {
      this.isHalted = true
      return false
    }

    // Mark the current state as active
    this.states.forEach((s) => (s.isActive = s.id === this.currentState))

    // Get the current symbol
    const currentSymbol = this.tape[this.headPosition]

    // Find the transition
    let transition
    if (this.transitions.some((t) => t.symbol.includes(","))) {
      // Turing Machine transition format: "read,write,move"
      transition = this.transitions.find(
        (t) => t.from === this.currentState && t.symbol.split(",")[0] === currentSymbol,
      )
    } else {
      // DFA/NFA transition format: just the symbol
      transition = this.transitions.find((t) => t.from === this.currentState && t.symbol === currentSymbol)
    }

    // Reset all transitions
    this.transitions.forEach((t) => (t.isActive = false))

    if (!transition) {
      this.isHalted = true
      return false
    }

    // Mark the transition as active
    transition.isActive = true

    // For Turing Machine, update the tape and head position
    if (transition.symbol.includes(",")) {
      const [, writeSymbol, move] = transition.symbol.split(",")
      this.tape[this.headPosition] = writeSymbol

      if (move === "R") {
        this.headPosition++
      } else if (move === "L") {
        this.headPosition--
      }
    }

    // Update current state
    this.currentState = transition.to

    return true
  }

  // Reset the machine
  reset(machineType: string) {
    if (machineType === "turing") {
      this.initializePalindromeTM()
    } else if (machineType === "dfa") {
      this.initializeDFA()
    } else if (machineType === "nfa") {
      this.initializeNFA()
    } else if (machineType === "regex") {
      // For regex, we'll just use a simple DFA
      this.initializeDFA()
    }
  }
}

export default function AutomataTheoryPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [machineType, setMachineType] = useState("turing")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [machine] = useState(new TuringMachine())
  const [inputString, setInputString] = useState("aabaa")
  const [regexPattern, setRegexPattern] = useState("a.*b")
  const [regexTestString, setRegexTestString] = useState("aab")
  const [regexResult, setRegexResult] = useState("")
  const [message, setMessage] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Automata Theory Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore Turing machines, finite automata, and regular expressions through interactive visualizations",
  )

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Initialize machine based on selected concept
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)

      // Set machine type based on selected concept
      if (selectedConcept.toLowerCase().includes("turing")) {
        setMachineType("turing")
        setConceptTitle("Turing Machine")
        setConceptDescription(
          "A mathematical model of computation that defines an abstract machine that manipulates symbols on a strip of tape according to a table of rules.",
        )
        setMessage("Turing Machine: A model of computation with a tape and a finite set of states.")
        machine.reset("turing")
      } else if (
        selectedConcept.toLowerCase().includes("deterministic") ||
        selectedConcept.toLowerCase().includes("dfa")
      ) {
        setMachineType("dfa")
        setConceptTitle("Deterministic Finite Automaton")
        setConceptDescription(
          "A finite-state machine that accepts or rejects strings of symbols and only produces a unique computation for each input string.",
        )
        setMessage("DFA: A finite automaton where each state has exactly one transition for each possible input.")
        machine.reset("dfa")
      } else if (
        selectedConcept.toLowerCase().includes("non-deterministic") ||
        selectedConcept.toLowerCase().includes("nfa")
      ) {
        setMachineType("nfa")
        setConceptTitle("Non-deterministic Finite Automaton")
        setConceptDescription(
          "A finite-state machine where from each state and a given input symbol, the automaton may transition to several possible next states.",
        )
        setMessage("NFA: A finite automaton that can transition to multiple states for a given input symbol.")
        machine.reset("nfa")
      } else if (selectedConcept.toLowerCase().includes("regular expression")) {
        setMachineType("regex")
        setConceptTitle("Regular Expression")
        setConceptDescription(
          "A sequence of characters that define a search pattern, mainly for use in pattern matching with strings.",
        )
        setMessage("Regular Expression: A pattern that describes a set of strings.")
      } else {
        // Default to Turing Machine
        setMachineType("turing")
        setConceptTitle("Automata Theory Visualizer")
        setConceptDescription(
          "Explore Turing machines, finite automata, and regular expressions through interactive visualizations",
        )
        setMessage("Select a concept to visualize its operation.")
        machine.reset("turing")
      }
    }
  }, [selectedConcept, machine])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Automata Theory Visualizer`
    }
  }, [selectedConcept])

  // Animation loop
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying && (machineType === "turing" || machineType === "dfa" || machineType === "nfa")) {
      timer = setTimeout(
        () => {
          const success = machine.step()
          if (!success) {
            setIsPlaying(false)
            if (machineType === "turing") {
              const acceptState = machine.states.find((s) => s.id === machine.currentState && s.isAccept)
              setMessage(
                acceptState
                  ? "Turing Machine halted in an accept state. Input is accepted."
                  : "Turing Machine halted in a non-accept state. Input is rejected.",
              )
            } else {
              const acceptState = machine.states.find((s) => s.id === machine.currentState && s.isAccept)
              setMessage(
                acceptState
                  ? `${machineType.toUpperCase()} halted in an accept state. Input is accepted.`
                  : `${machineType.toUpperCase()} halted in a non-accept state. Input is rejected.`,
              )
            }
          }
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, machine, machineType, speed])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (machineType === "turing") {
      drawTuringMachine(ctx)
    } else if (machineType === "dfa" || machineType === "nfa") {
      drawFiniteAutomaton(ctx)
    } else if (machineType === "regex") {
      drawRegexVisualizer(ctx)
    }
  }, [machineType, machine, canvasSize, regexPattern, regexTestString, regexResult])

  // Draw Turing Machine
  const drawTuringMachine = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw tape
    const cellSize = 30
    const tapeY = height * 0.3
    const tapeStartX = width / 2 - (machine.tape.length * cellSize) / 2

    // Draw tape cells
    for (let i = 0; i < machine.tape.length; i++) {
      const x = tapeStartX + i * cellSize

      // Highlight the current head position
      if (i === machine.headPosition) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(x, tapeY, cellSize, cellSize)
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.fillRect(x, tapeY, cellSize, cellSize)
      }

      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(x, tapeY, cellSize, cellSize)

      // Draw symbol
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(machine.tape[i], x + cellSize / 2, tapeY + cellSize / 2)
    }

    // Draw head
    const headX = tapeStartX + machine.headPosition * cellSize + cellSize / 2
    ctx.beginPath()
    ctx.moveTo(headX, tapeY + cellSize + 5)
    ctx.lineTo(headX - 10, tapeY + cellSize + 20)
    ctx.lineTo(headX + 10, tapeY + cellSize + 20)
    ctx.closePath()
    ctx.fillStyle = "#9f7aea"
    ctx.fill()

    // Draw states
    machine.states.forEach((state) => {
      // Draw state circle
      ctx.beginPath()
      ctx.arc(state.x, state.y, 25, 0, Math.PI * 2)

      // Fill based on state properties
      if (state.isActive) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw double circle for accept states
      if (state.isAccept) {
        ctx.beginPath()
        ctx.arc(state.x, state.y, 20, 0, Math.PI * 2)
        ctx.strokeStyle = "#4fd1c5"
        ctx.stroke()
      }

      // Draw arrow for start state
      if (state.isStart) {
        ctx.beginPath()
        ctx.moveTo(state.x - 40, state.y)
        ctx.lineTo(state.x - 25, state.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(state.x - 25, state.y)
        ctx.lineTo(state.x - 35, state.y - 5)
        ctx.lineTo(state.x - 35, state.y + 5)
        ctx.closePath()
        ctx.fillStyle = "#4fd1c5"
        ctx.fill()
      }

      // Draw state label
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(state.id, state.x, state.y)
    })

    // Draw transitions
    machine.transitions.forEach((transition) => {
      const fromState = machine.states.find((s) => s.id === transition.from)
      const toState = machine.states.find((s) => s.id === transition.to)

      if (fromState && toState) {
        // Self-loop
        if (fromState === toState) {
          ctx.beginPath()
          ctx.arc(fromState.x, fromState.y - 35, 15, 0.3 * Math.PI, 0.7 * Math.PI)

          if (transition.isActive) {
            ctx.strokeStyle = "#9f7aea"
            ctx.lineWidth = 3
            ctx.shadowColor = "#9f7aea"
            ctx.shadowBlur = 10
          } else {
            ctx.strokeStyle = "#4fd1c5"
            ctx.lineWidth = 2
            ctx.shadowBlur = 0
          }

          ctx.stroke()

          // Draw arrowhead
          const angle = 0.7 * Math.PI
          const arrowX = fromState.x + 15 * Math.cos(angle)
          const arrowY = fromState.y - 35 + 15 * Math.sin(angle)

          ctx.beginPath()
          ctx.moveTo(arrowX, arrowY)
          ctx.lineTo(arrowX + 8 * Math.cos(angle - Math.PI / 6), arrowY + 8 * Math.sin(angle - Math.PI / 6))
          ctx.lineTo(arrowX + 8 * Math.cos(angle + Math.PI / 6), arrowY + 8 * Math.sin(angle + Math.PI / 6))
          ctx.closePath()
          ctx.fillStyle = transition.isActive ? "#9f7aea" : "#4fd1c5"
          ctx.fill()

          // Draw transition label
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(transition.symbol, fromState.x, fromState.y - 55)
        } else {
          // Regular transition
          const angle = Math.atan2(toState.y - fromState.y, toState.x - fromState.x)
          const fromX = fromState.x + 25 * Math.cos(angle)
          const fromY = fromState.y + 25 * Math.sin(angle)
          const toX = toState.x - 25 * Math.cos(angle)
          const toY = toState.y - 25 * Math.sin(angle)

          ctx.beginPath()
          ctx.moveTo(fromX, fromY)
          ctx.lineTo(toX, toY)

          if (transition.isActive) {
            ctx.strokeStyle = "#9f7aea"
            ctx.lineWidth = 3
            ctx.shadowColor = "#9f7aea"
            ctx.shadowBlur = 10
          } else {
            ctx.strokeStyle = "#4fd1c5"
            ctx.lineWidth = 2
            ctx.shadowBlur = 0
          }

          ctx.stroke()

          // Draw arrowhead
          ctx.beginPath()
          ctx.moveTo(toX, toY)
          ctx.lineTo(toX - 10 * Math.cos(angle - Math.PI / 6), toY - 10 * Math.sin(angle - Math.PI / 6))
          ctx.lineTo(toX - 10 * Math.cos(angle + Math.PI / 6), toY - 10 * Math.sin(angle + Math.PI / 6))
          ctx.closePath()
          ctx.fillStyle = transition.isActive ? "#9f7aea" : "#4fd1c5"
          ctx.fill()

          // Draw transition label
          const midX = (fromX + toX) / 2
          const midY = (fromY + toY) / 2 - 10
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(transition.symbol, midX, midY)
        }
      }
    })

    // Reset shadow
    ctx.shadowBlur = 0
  }

  // Draw Finite Automaton (DFA/NFA)
  const drawFiniteAutomaton = (ctx: CanvasRenderingContext2D) => {
    // Similar to Turing Machine but without the tape
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw states
    machine.states.forEach((state) => {
      // Draw state circle
      ctx.beginPath()
      ctx.arc(state.x, state.y, 25, 0, Math.PI * 2)

      // Fill based on state properties
      if (state.isActive) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw double circle for accept states
      if (state.isAccept) {
        ctx.beginPath()
        ctx.arc(state.x, state.y, 20, 0, Math.PI * 2)
        ctx.strokeStyle = "#4fd1c5"
        ctx.stroke()
      }

      // Draw arrow for start state
      if (state.isStart) {
        ctx.beginPath()
        ctx.moveTo(state.x - 40, state.y)
        ctx.lineTo(state.x - 25, state.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(state.x - 25, state.y)
        ctx.lineTo(state.x - 35, state.y - 5)
        ctx.lineTo(state.x - 35, state.y + 5)
        ctx.closePath()
        ctx.fillStyle = "#4fd1c5"
        ctx.fill()
      }

      // Draw state label
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(state.id, state.x, state.y)
    })

    // Draw transitions
    machine.transitions.forEach((transition) => {
      const fromState = machine.states.find((s) => s.id === transition.from)
      const toState = machine.states.find((s) => s.id === transition.to)

      if (fromState && toState) {
        // Self-loop
        if (fromState === toState) {
          ctx.beginPath()
          ctx.arc(fromState.x, fromState.y - 35, 15, 0.3 * Math.PI, 0.7 * Math.PI)

          if (transition.isActive) {
            ctx.strokeStyle = "#9f7aea"
            ctx.lineWidth = 3
            ctx.shadowColor = "#9f7aea"
            ctx.shadowBlur = 10
          } else {
            ctx.strokeStyle = "#4fd1c5"
            ctx.lineWidth = 2
            ctx.shadowBlur = 0
          }

          ctx.stroke()

          // Draw arrowhead
          const angle = 0.7 * Math.PI
          const arrowX = fromState.x + 15 * Math.cos(angle)
          const arrowY = fromState.y - 35 + 15 * Math.sin(angle)

          ctx.beginPath()
          ctx.moveTo(arrowX, arrowY)
          ctx.lineTo(arrowX + 8 * Math.cos(angle - Math.PI / 6), arrowY + 8 * Math.sin(angle - Math.PI / 6))
          ctx.lineTo(arrowX + 8 * Math.cos(angle + Math.PI / 6), arrowY + 8 * Math.sin(angle + Math.PI / 6))
          ctx.closePath()
          ctx.fillStyle = transition.isActive ? "#9f7aea" : "#4fd1c5"
          ctx.fill()

          // Draw transition label
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(transition.symbol, fromState.x, fromState.y - 55)
        } else {
          // Regular transition
          const angle = Math.atan2(toState.y - fromState.y, toState.x - fromState.x)
          const fromX = fromState.x + 25 * Math.cos(angle)
          const fromY = fromState.y + 25 * Math.sin(angle)
          const toX = toState.x - 25 * Math.cos(angle)
          const toY = toState.y - 25 * Math.sin(angle)

          ctx.beginPath()
          ctx.moveTo(fromX, fromY)
          ctx.lineTo(toX, toY)

          if (transition.isActive) {
            ctx.strokeStyle = "#9f7aea"
            ctx.lineWidth = 3
            ctx.shadowColor = "#9f7aea"
            ctx.shadowBlur = 10
          } else {
            ctx.strokeStyle = "#4fd1c5"
            ctx.lineWidth = 2
            ctx.shadowBlur = 0
          }

          ctx.stroke()

          // Draw arrowhead
          ctx.beginPath()
          ctx.moveTo(toX, toY)
          ctx.lineTo(toX - 10 * Math.cos(angle - Math.PI / 6), toY - 10 * Math.sin(angle - Math.PI / 6))
          ctx.lineTo(toX - 10 * Math.cos(angle + Math.PI / 6), toY - 10 * Math.sin(angle + Math.PI / 6))
          ctx.closePath()
          ctx.fillStyle = transition.isActive ? "#9f7aea" : "#4fd1c5"
          ctx.fill()

          // Draw transition label
          const midX = (fromX + toX) / 2
          const midY = (fromY + toY) / 2 - 10
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(transition.symbol, midX, midY)
        }
      }
    })

    // Draw input string
    const inputY = height * 0.8
    const inputStartX = width / 2 - (inputString.length * 30) / 2

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Input String:", inputStartX - 80, inputY)

    for (let i = 0; i < inputString.length; i++) {
      const x = inputStartX + i * 30

      // Highlight the current position
      if (i === machine.headPosition - 10) {
        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(x - 15, inputY - 15, 30, 30)
      }

      ctx.fillStyle = "#ffffff"
      ctx.font = "16px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(inputString[i], x, inputY)
    }

    // Reset shadow
    ctx.shadowBlur = 0
  }

  // Draw Regular Expression Visualizer
  const drawRegexVisualizer = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw regex pattern
    ctx.fillStyle = "#ffffff"
    ctx.font = "18px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(`Regular Expression: ${regexPattern}`, width / 2, height * 0.3)

    // Draw test string
    ctx.fillText(`Test String: ${regexTestString}`, width / 2, height * 0.4)

    // Draw result
    if (regexResult) {
      ctx.fillStyle = regexResult.includes("matches") ? "#4ade80" : "#f87171"
      ctx.fillText(regexResult, width / 2, height * 0.5)
    }

    // Draw a simple visualization of the matching process
    if (regexTestString && regexPattern) {
      try {
        const regex = new RegExp(regexPattern)
        const matches = regex.test(regexTestString)

        // Draw the test string with highlighting for matches
        const stringStartX = width / 2 - (regexTestString.length * 20) / 2
        const stringY = height * 0.6

        for (let i = 0; i < regexTestString.length; i++) {
          const x = stringStartX + i * 20

          // Try to match each position
          const partialMatch = new RegExp(regexPattern).test(regexTestString.substring(0, i + 1))

          if (partialMatch) {
            ctx.fillStyle = "#4ade80"
            ctx.fillRect(x - 10, stringY - 15, 20, 30)
          }

          ctx.fillStyle = "#ffffff"
          ctx.font = "16px monospace"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(regexTestString[i], x, stringY)
        }

        // Update the result message
        setRegexResult(matches ? "String matches the pattern!" : "String does not match the pattern.")
      } catch (error) {
        setRegexResult("Invalid regular expression pattern.")
      }
    }
  }

  // Start animation
  const startAnimation = () => {
    if (machineType === "regex") {
      // For regex, just test the pattern
      try {
        const regex = new RegExp(regexPattern)
        const matches = regex.test(regexTestString)
        setRegexResult(matches ? "String matches the pattern!" : "String does not match the pattern.")
      } catch (error) {
        setRegexResult("Invalid regular expression pattern.")
      }
    } else {
      setIsPlaying(true)
    }
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setIsPlaying(false)
    machine.reset(machineType)
    setRegexResult("")

    if (machineType === "turing") {
      setMessage("Turing Machine: A model of computation with a tape and a finite set of states.")
    } else if (machineType === "dfa") {
      setMessage("DFA: A finite automaton where each state has exactly one transition for each possible input.")
    } else if (machineType === "nfa") {
      setMessage("NFA: A finite automaton that can transition to multiple states for a given input symbol.")
    } else if (machineType === "regex") {
      setMessage("Regular Expression: A pattern that describes a set of strings.")
    }
  }

  // Handle input string change
  const handleInputStringChange = (value: string) => {
    setInputString(value)

    // Update the tape for the machine
    if (machineType === "dfa" || machineType === "nfa") {
      machine.tape = Array(21).fill("_")
      const input = value.split("")
      for (let i = 0; i < input.length; i++) {
        machine.tape[10 + i] = input[i]
      }
      machine.headPosition = 10
      machine.currentState = machine.states.find((s) => s.isStart)?.id || "q0"
      machine.isHalted = false
    }
  }

  // Step forward one step
  const stepForward = () => {
    if (machineType !== "regex") {
      machine.step()
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {machineType !== "regex" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={stepForward}
                        className="border-gray-700 text-gray-300 hover:text-white"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    )}
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        {machineType === "regex" ? "Test" : "Start"}
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Automaton Type</h3>
                    <Tabs
                      defaultValue="turing"
                      value={machineType}
                      onValueChange={(value) => {
                        setMachineType(value)
                        resetAnimation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
                        <TabsTrigger value="turing">Turing</TabsTrigger>
                        <TabsTrigger value="dfa">DFA</TabsTrigger>
                        <TabsTrigger value="nfa">NFA</TabsTrigger>
                        <TabsTrigger value="regex">Regex</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {(machineType === "dfa" || machineType === "nfa") && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Input String</h3>
                      <Input
                        value={inputString}
                        onChange={(e) => handleInputStringChange(e.target.value)}
                        placeholder="Enter input string"
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                  )}

                  {machineType === "regex" && (
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Regular Expression</h3>
                        <Input
                          value={regexPattern}
                          onChange={(e) => setRegexPattern(e.target.value)}
                          placeholder="Enter regex pattern"
                          className="bg-gray-800/50 border-gray-700 text-white"
                        />
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Test String</h3>
                        <Input
                          value={regexTestString}
                          onChange={(e) => setRegexTestString(e.target.value)}
                          placeholder="Enter test string"
                          className="bg-gray-800/50 border-gray-700 text-white"
                        />
                      </div>
                    </div>
                  )}

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Concept Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {machineType === "turing" ? (
                        <>
                          <p>A Turing Machine consists of:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>A tape divided into cells, each containing a symbol</li>
                            <li>A head that can read and write symbols on the tape and move left or right</li>
                            <li>A state register that stores the state of the machine</li>
                            <li>
                              A finite table of instructions that tell the machine what to do based on the current state
                              and the symbol it's reading
                            </li>
                          </ul>
                        </>
                      ) : machineType === "dfa" ? (
                        <>
                          <p>A Deterministic Finite Automaton (DFA) consists of:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>A finite set of states</li>
                            <li>A finite set of input symbols (alphabet)</li>
                            <li>A transition function that maps state-symbol pairs to states</li>
                            <li>A start state</li>
                            <li>A set of accept states</li>
                          </ul>
                          <p className="mt-2">For each state and input symbol, there is exactly one transition.</p>
                        </>
                      ) : machineType === "nfa" ? (
                        <>
                          <p>A Non-deterministic Finite Automaton (NFA) consists of:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>A finite set of states</li>
                            <li>A finite set of input symbols (alphabet)</li>
                            <li>A transition function that maps state-symbol pairs to sets of states</li>
                            <li>A start state</li>
                            <li>A set of accept states</li>
                          </ul>
                          <p className="mt-2">
                            For each state and input symbol, there can be multiple possible transitions.
                          </p>
                        </>
                      ) : (
                        <>
                          <p>Regular Expressions are patterns used to match character combinations in strings.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Basic patterns: a, b, c, etc. match themselves</li>
                            <li>
                              Special characters: . (any character), * (zero or more), + (one or more), ? (zero or one)
                            </li>
                            <li>Character classes: [abc] (any of a, b, or c), [^abc] (any except a, b, or c)</li>
                            <li>Alternation: a|b (a or b)</li>
                            <li>Grouping: (ab)+ (one or more occurrences of "ab")</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="automata-theory" title="Automata Theory" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

