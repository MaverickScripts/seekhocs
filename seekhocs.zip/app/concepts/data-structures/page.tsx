"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Plus, Minus, RotateCcw, Play, Pause } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Node classes for different data structures
class TreeNode {
  value: number
  left: TreeNode | null
  right: TreeNode | null
  x: number
  y: number
  color: string
  height: number // For AVL trees
  isRed: boolean // For Red-Black trees

  constructor(value: number) {
    this.value = value
    this.left = null
    this.right = null
    this.x = 0
    this.y = 0
    this.color = "#4fd1c5"
    this.height = 1
    this.isRed = true
  }
}

class ListNode {
  value: number
  next: ListNode | null
  prev: ListNode | null // For doubly linked lists
  x: number
  y: number

  constructor(value: number) {
    this.value = value
    this.next = null
    this.prev = null
    this.x = 0
    this.y = 0
  }
}

class GraphNode {
  id: number
  x: number
  y: number
  connections: number[]

  constructor(id: number) {
    this.id = id
    this.x = 0
    this.y = 0
    this.connections = []
  }
}

class HashEntry {
  key: string
  value: string
  x: number
  y: number

  constructor(key: string, value: string) {
    this.key = key
    this.value = value
    this.x = 0
    this.y = 0
  }
}

export default function DataStructuresPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [dataStructure, setDataStructure] = useState("array")
  const [inputValue, setInputValue] = useState("")
  const [searchValue, setSearchValue] = useState("")
  const [highlightedIndex, setHighlightedIndex] = useState<number | null>(null)
  const [message, setMessage] = useState("")
  const [isAnimating, setIsAnimating] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [animationStep, setAnimationStep] = useState(0)
  const [animationSpeed, setAnimationSpeed] = useState(50)

  // Data structure states
  const [array, setArray] = useState<number[]>([])
  const [linkedList, setLinkedList] = useState<ListNode | null>(null)
  const [stack, setStack] = useState<number[]>([])
  const [queue, setQueue] = useState<number[]>([])
  const [binaryTree, setBinaryTree] = useState<TreeNode | null>(null)
  const [hashTable, setHashTable] = useState<HashEntry[][]>([])
  const [graph, setGraph] = useState<GraphNode[]>([])

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })

  const [conceptTitle, setConceptTitle] = useState<string>("Data Structures Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore and interact with common data structures through visual representations",
  )

  const [codeSnippet, setCodeSnippet] = useState<string>("")
  const [operationComplexity, setOperationComplexity] = useState<{ [key: string]: string }>({})
  const [currentOperation, setCurrentOperation] = useState<string>("")

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Handle concept selection
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)
      setAnimationStep(0)
      setHighlightedIndex(null)

      // Determine which data structure to show based on the selected concept
      const concept = selectedConcept.toLowerCase()

      if (concept.includes("array")) {
        initializeArray()
      } else if (concept.includes("linked list")) {
        initializeLinkedList()
      } else if (concept.includes("stack")) {
        initializeStack()
      } else if (concept.includes("queue")) {
        initializeQueue()
      } else if (concept.includes("hash")) {
        initializeHashTable()
      } else if (concept.includes("binary search tree") || concept.includes("bst")) {
        initializeBST()
      } else if (concept.includes("avl")) {
        initializeAVLTree()
      } else if (concept.includes("red-black")) {
        initializeRedBlackTree()
      } else if (concept.includes("binary tree")) {
        initializeBinaryTree()
      } else if (concept.includes("heap")) {
        initializeHeap()
      } else if (concept.includes("graph")) {
        initializeGraph()
      } else if (concept.includes("trie")) {
        initializeTrie()
      } else if (concept.includes("b-tree")) {
        initializeBTree()
      } else if (concept.includes("segment")) {
        initializeSegmentTree()
      } else if (concept.includes("disjoint")) {
        initializeDisjointSet()
      } else {
        // Default to array if concept not recognized
        initializeArray()
      }
    } else {
      // Default initialization if no concept selected
      initializeArray()
    }
  }, [selectedConcept])

  // Animation loop
  useEffect(() => {
    let animationTimer: NodeJS.Timeout

    if (isPlaying) {
      animationTimer = setTimeout(
        () => {
          // Increment animation step
          setAnimationStep((prev) => {
            const nextStep = prev + 1

            // Handle animation logic based on data structure
            if (dataStructure === "array") {
              // For array, highlight different indices
              setHighlightedIndex(nextStep % array.length)

              if (nextStep >= array.length * 2) {
                setIsPlaying(false)
                setHighlightedIndex(null)
                return 0
              }
            } else if (dataStructure === "linkedlist") {
              // For linked list, traverse the list
              let currentNode = linkedList
              let count = 0

              while (currentNode && count < nextStep % 10) {
                currentNode = currentNode.next
                count++
              }

              if (currentNode) {
                setHighlightedIndex(count)
              } else {
                setIsPlaying(false)
                setHighlightedIndex(null)
                return 0
              }
            } else if (dataStructure === "stack") {
              // For stack, simulate push/pop operations
              if (nextStep % 2 === 0 && stack.length < 8) {
                // Push operation
                const newValue = Math.floor(Math.random() * 90) + 10
                setStack((prev) => [...prev, newValue])
                setMessage(`Pushed ${newValue} onto the stack`)
              } else if (stack.length > 0) {
                // Pop operation
                const poppedValue = stack[stack.length - 1]
                setStack((prev) => prev.slice(0, -1))
                setMessage(`Popped ${poppedValue} from the stack`)
              }

              if (nextStep >= 10) {
                setIsPlaying(false)
                return 0
              }
            } else if (dataStructure === "queue") {
              // For queue, simulate enqueue/dequeue operations
              if (nextStep % 2 === 0 && queue.length < 8) {
                // Enqueue operation
                const newValue = Math.floor(Math.random() * 90) + 10
                setQueue((prev) => [...prev, newValue])
                setMessage(`Enqueued ${newValue}`)
              } else if (queue.length > 0) {
                // Dequeue operation
                const dequeuedValue = queue[0]
                setQueue((prev) => prev.slice(1))
                setMessage(`Dequeued ${dequeuedValue}`)
              }

              if (nextStep >= 10) {
                setIsPlaying(false)
                return 0
              }
            } else if (
              dataStructure === "binarytree" ||
              dataStructure === "bst" ||
              dataStructure === "avl" ||
              dataStructure === "redblack"
            ) {
              // For tree structures, traverse in different orders
              const traversalOrders = ["pre-order", "in-order", "post-order", "level-order"]
              const currentOrder = traversalOrders[Math.floor(nextStep / 5) % traversalOrders.length]

              // Get nodes in the current traversal order
              const nodes = getTreeTraversalOrder(binaryTree, currentOrder)

              if (nodes.length > 0) {
                const nodeIndex = nextStep % nodes.length
                setHighlightedIndex(nodes[nodeIndex])
                setMessage(
                  `${currentOrder.charAt(0).toUpperCase() + currentOrder.slice(1)} traversal: visiting node ${nodes[nodeIndex]}`,
                )
              }

              if (nextStep >= 20) {
                setIsPlaying(false)
                setHighlightedIndex(null)
                return 0
              }
            } else if (dataStructure === "hashtable") {
              // For hash table, simulate lookups
              if (hashTable.length > 0) {
                const bucketIndex = nextStep % hashTable.length
                setHighlightedIndex(bucketIndex)

                if (hashTable[bucketIndex] && hashTable[bucketIndex].length > 0) {
                  setMessage(`Checking bucket ${bucketIndex}: found ${hashTable[bucketIndex].length} entries`)
                } else {
                  setMessage(`Checking bucket ${bucketIndex}: empty`)
                }
              }

              if (nextStep >= hashTable.length * 2) {
                setIsPlaying(false)
                setHighlightedIndex(null)
                return 0
              }
            } else if (dataStructure === "graph") {
              // For graph, simulate traversal
              if (graph.length > 0) {
                const nodeIndex = nextStep % graph.length
                setHighlightedIndex(nodeIndex)

                const connections = graph[nodeIndex].connections
                if (connections.length > 0) {
                  setMessage(`Visiting node ${nodeIndex}: connected to nodes [${connections.join(", ")}]`)
                } else {
                  setMessage(`Visiting node ${nodeIndex}: no connections`)
                }
              }

              if (nextStep >= graph.length * 2) {
                setIsPlaying(false)
                setHighlightedIndex(null)
                return 0
              }
            }

            return nextStep
          })
        },
        1000 - animationSpeed * 9,
      )
    }

    return () => clearTimeout(animationTimer)
  }, [
    isPlaying,
    animationStep,
    dataStructure,
    array,
    linkedList,
    stack,
    queue,
    binaryTree,
    hashTable,
    graph,
    animationSpeed,
  ])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw based on the current data structure
    switch (dataStructure) {
      case "array":
        drawArray(ctx)
        break
      case "linkedlist":
        drawLinkedList(ctx)
        break
      case "stack":
        drawStack(ctx)
        break
      case "queue":
        drawQueue(ctx)
        break
      case "binarytree":
      case "bst":
      case "avl":
      case "redblack":
        drawBinaryTree(ctx)
        break
      case "heap":
        drawHeap(ctx)
        break
      case "hashtable":
        drawHashTable(ctx)
        break
      case "graph":
        drawGraph(ctx)
        break
      case "trie":
        drawTrie(ctx)
        break
      case "btree":
        drawBTree(ctx)
        break
      case "segmenttree":
        drawSegmentTree(ctx)
        break
      case "disjointset":
        drawDisjointSet(ctx)
        break
    }
  }, [
    dataStructure,
    array,
    linkedList,
    stack,
    queue,
    binaryTree,
    hashTable,
    graph,
    highlightedIndex,
    canvasSize,
    animationStep,
  ])

  // Initialize Array
  const initializeArray = () => {
    setDataStructure("array")
    setConceptTitle("Array")
    setConceptDescription(
      "A collection of elements stored at contiguous memory locations, allowing direct access to any element using its index.",
    )
    setMessage("Arrays provide constant-time access to elements using indices.")

    // Generate random array
    const newArray = Array.from({ length: 10 }, () => Math.floor(Math.random() * 90) + 10)
    setArray(newArray)

    // Set code snippet
    setCodeSnippet(`// JavaScript Array implementation
const array = [10, 20, 30, 40, 50];

// Access element (O(1))
const element = array[2]; // Returns 30

// Add element to end (amortized O(1))
array.push(60);

// Remove element from end (O(1))
const lastElement = array.pop();

// Add element to beginning (O(n))
array.unshift(5);

// Remove element from beginning (O(n))
const firstElement = array.shift();

// Find index of element (O(n))
const index = array.indexOf(30);`)

    // Set operation complexity
    setOperationComplexity({
      Access: "O(1)",
      Search: "O(n)",
      Insertion: "O(n) or O(1) at end",
      Deletion: "O(n) or O(1) at end",
      Space: "O(n)",
    })

    setCurrentOperation("Arrays provide fast access but slow insertions/deletions in the middle.")
  }

  // Initialize Linked List
  const initializeLinkedList = () => {
    setDataStructure("linkedlist")
    setConceptTitle("Linked List")
    setConceptDescription(
      "A linear data structure where each element (node) contains data and a reference to the next node in the sequence.",
    )
    setMessage("Linked Lists excel at insertions and deletions but have slower access times.")

    // Create a linked list
    const head = new ListNode(10)
    let current = head

    for (const value of [20, 30, 40, 50]) {
      current.next = new ListNode(value)
      current = current.next
    }

    // Position nodes
    positionLinkedListNodes(head)
    setLinkedList(head)

    // Set code snippet
    setCodeSnippet(`// JavaScript Linked List implementation
class Node {
  constructor(value) {
    this.value = value;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
  }
  
  // Add to end (O(n) or O(1) with tail pointer)
  append(value) {
    const newNode = new Node(value);
    if (!this.head) {
      this.head = newNode;
      return;
    }
    
    let current = this.head;
    while (current.next) {
      current = current.next;
    }
    current.next = newNode;
  }
  
  // Add to beginning (O(1))
  prepend(value) {
    const newNode = new Node(value);
    newNode.next = this.head;
    this.head = newNode;
  }
  
  // Delete node with value (O(n))
  delete(value) {
    if (!this.head) return;
    
    if (this.head.value === value) {
      this.head = this.head.next;
      return;
    }
    
    let current = this.head;
    while (current.next && current.next.value !== value) {
      current = current.next;
    }
    
    if (current.next) {
      current.next = current.next.next;
    }
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Access: "O(n)",
      Search: "O(n)",
      Insertion: "O(1) at beginning, O(n) at end",
      Deletion: "O(1) if node reference known, O(n) to find",
      Space: "O(n)",
    })

    setCurrentOperation("Linked Lists are ideal when frequent insertions and deletions are needed.")
  }

  // Initialize Stack
  const initializeStack = () => {
    setDataStructure("stack")
    setConceptTitle("Stack")
    setConceptDescription(
      "A linear data structure that follows the Last In First Out (LIFO) principle, where elements are added and removed from the same end.",
    )
    setMessage("Stacks follow the Last In First Out (LIFO) principle.")

    // Create a stack
    setStack([10, 20, 30, 40, 50])

    // Set code snippet
    setCodeSnippet(`// JavaScript Stack implementation
class Stack {
  constructor() {
    this.items = [];
  }
  
  // Add element to top (O(1))
  push(element) {
    this.items.push(element);
  }
  
  // Remove element from top (O(1))
  pop() {
    if (this.isEmpty()) return "Stack is empty";
    return this.items.pop();
  }
  
  // View top element without removing (O(1))
  peek() {
    if (this.isEmpty()) return "Stack is empty";
    return this.items[this.items.length - 1];
  }
  
  // Check if stack is empty (O(1))
  isEmpty() {
    return this.items.length === 0;
  }
  
  // Get stack size (O(1))
  size() {
    return this.items.length;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Push: "O(1)",
      Pop: "O(1)",
      Peek: "O(1)",
      Search: "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("Stacks are used for function calls, expression evaluation, and backtracking algorithms.")
  }

  // Initialize Queue
  const initializeQueue = () => {
    setDataStructure("queue")
    setConceptTitle("Queue")
    setConceptDescription(
      "A linear data structure that follows the First In First Out (FIFO) principle, where elements are added at the rear and removed from the front.",
    )
    setMessage("Queues follow the First In First Out (FIFO) principle.")

    // Create a queue
    setQueue([10, 20, 30, 40, 50])

    // Set code snippet
    setCodeSnippet(`// JavaScript Queue implementation
class Queue {
  constructor() {
    this.items = [];
  }
  
  // Add element to rear (O(1))
  enqueue(element) {
    this.items.push(element);
  }
  
  // Remove element from front (O(n))
  dequeue() {
    if (this.isEmpty()) return "Queue is empty";
    return this.items.shift();
  }
  
  // View front element without removing (O(1))
  front() {
    if (this.isEmpty()) return "Queue is empty";
    return this.items[0];
  }
  
  // Check if queue is empty (O(1))
  isEmpty() {
    return this.items.length === 0;
  }
  
  // Get queue size (O(1))
  size() {
    return this.items.length;
  }
}

// More efficient implementation using object
class EfficientQueue {
  constructor() {
    this.items = {};
    this.frontIndex = 0;
    this.rearIndex = 0;
  }
  
  enqueue(element) {
    this.items[this.rearIndex] = element;
    this.rearIndex++;
  }
  
  dequeue() {
    if (this.isEmpty()) return "Queue is empty";
    
    const item = this.items[this.frontIndex];
    delete this.items[this.frontIndex];
    this.frontIndex++;
    return item;
  }
  
  // Other methods similar to above
}`)

    // Set operation complexity
    setOperationComplexity({
      Enqueue: "O(1)",
      Dequeue: "O(1) with efficient implementation",
      Front: "O(1)",
      Search: "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("Queues are used for BFS, task scheduling, and request handling.")
  }

  // Initialize Binary Tree
  const initializeBinaryTree = () => {
    setDataStructure("binarytree")
    setConceptTitle("Binary Tree")
    setConceptDescription(
      "A hierarchical data structure where each node has at most two children, referred to as the left child and the right child.",
    )
    setMessage("Binary Trees are the foundation for many tree-based data structures.")

    // Create a binary tree
    const root = new TreeNode(50)
    root.left = new TreeNode(30)
    root.right = new TreeNode(70)
    root.left.left = new TreeNode(20)
    root.left.right = new TreeNode(40)
    root.right.left = new TreeNode(60)
    root.right.right = new TreeNode(80)

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Binary Tree implementation
class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

class BinaryTree {
  constructor() {
    this.root = null;
  }
  
  // Depth-First Traversals
  
  // Pre-order: Root -> Left -> Right
  preOrderTraversal(node = this.root, result = []) {
    if (node) {
      result.push(node.value);
      this.preOrderTraversal(node.left, result);
      this.preOrderTraversal(node.right, result);
    }
    return result;
  }
  
  // In-order: Left -> Root -> Right
  inOrderTraversal(node = this.root, result = []) {
    if (node) {
      this.inOrderTraversal(node.left, result);
      result.push(node.value);
      this.inOrderTraversal(node.right, result);
    }
    return result;
  }
  
  // Post-order: Left -> Right -> Root
  postOrderTraversal(node = this.root, result = []) {
    if (node) {
      this.postOrderTraversal(node.left, result);
      this.postOrderTraversal(node.right, result);
      result.push(node.value);
    }
    return result;
  }
  
  // Breadth-First (Level Order) Traversal
  levelOrderTraversal() {
    if (!this.root) return [];
    
    const result = [];
    const queue = [this.root];
    
    while (queue.length > 0) {
      const node = queue.shift();
      result.push(node.value);
      
      if (node.left) queue.push(node.left);
      if (node.right) queue.push(node.right);
    }
    
    return result;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Search: "O(n) worst case",
      Insertion: "O(n) worst case",
      Deletion: "O(n) worst case",
      Traversal: "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("Binary Trees provide a foundation for more specialized tree structures.")
  }

  // Initialize Binary Search Tree
  const initializeBST = () => {
    setDataStructure("bst")
    setConceptTitle("Binary Search Tree")
    setConceptDescription(
      "A binary tree where the left subtree of a node contains only nodes with keys less than the node's key, and the right subtree only nodes with keys greater than the node's key.",
    )
    setMessage("Binary Search Trees enable efficient searching, insertion, and deletion operations.")

    // Create a BST
    const root = new TreeNode(50)
    root.left = new TreeNode(30)
    root.right = new TreeNode(70)
    root.left.left = new TreeNode(20)
    root.left.right = new TreeNode(40)
    root.right.left = new TreeNode(60)
    root.right.right = new TreeNode(80)

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Binary Search Tree implementation
class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

class BinarySearchTree {
  constructor() {
    this.root = null;
  }
  
  // Insert a value (O(log n) average, O(n) worst case)
  insert(value) {
    const newNode = new TreeNode(value);
    
    if (!this.root) {
      this.root = newNode;
      return;
    }
    
    const insertNode = (node, newNode) => {
      // Go left if new value is less than node's value
      if (newNode.value < node.value) {
        if (node.left === null) {
          node.left = newNode;
        } else {
          insertNode(node.left, newNode);
        }
      } 
      // Go right if new value is greater than node's value
      else {
        if (node.right === null) {
          node.right = newNode;
        } else {
          insertNode(node.right, newNode);
        }
      }
    };
    
    insertNode(this.root, newNode);
  }
  
  // Search for a value (O(log n) average, O(n) worst case)
  search(value) {
    const searchNode = (node, value) => {
      if (!node) return null;
      
      if (value === node.value) return node;
      
      if (value < node.value) {
        return searchNode(node.left, value);
      } else {
        return searchNode(node.right, value);
      }
    };
    
    return searchNode(this.root, value);
  }
  
  // Delete a value (O(log n) average, O(n) worst case)
  delete(value) {
    const removeNode = (node, value) => {
      if (!node) return null;
      
      if (value < node.value) {
        node.left = removeNode(node.left, value);
        return node;
      } else if (value > node.value) {
        node.right = removeNode(node.right, value);
        return node;
      } else {
        // Case 1: Leaf node (no children)
        if (!node.left && !node.right) {
          return null;
        }
        
        // Case 2: Node with one child
        if (!node.left) return node.right;
        if (!node.right) return node.left;
        
        // Case 3: Node with two children
        // Find the minimum value in the right subtree
        let successor = node.right;
        while (successor.left) {
          successor = successor.left;
        }
        
        // Replace node's value with successor's value
        node.value = successor.value;
        
        // Delete the successor
        node.right = removeNode(node.right, successor.value);
        return node;
      }
    };
    
    this.root = removeNode(this.root, value);
  }
  
  // In-order traversal gives sorted order
  inOrderTraversal(node = this.root, result = []) {
    if (node) {
      this.inOrderTraversal(node.left, result);
      result.push(node.value);
      this.inOrderTraversal(node.right, result);
    }
    return result;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Search: "O(log n) average, O(n) worst case",
      Insertion: "O(log n) average, O(n) worst case",
      Deletion: "O(log n) average, O(n) worst case",
      Traversal: "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("Binary Search Trees provide efficient searching with O(log n) time complexity on average.")
  }

  // Initialize AVL Tree
  const initializeAVLTree = () => {
    setDataStructure("avl")
    setConceptTitle("AVL Tree")
    setConceptDescription(
      "A self-balancing binary search tree where the difference between heights of left and right subtrees cannot be more than one for all nodes.",
    )
    setMessage("AVL Trees maintain balance to ensure O(log n) operations in worst case.")

    // Create an AVL tree
    const root = new TreeNode(50)
    root.left = new TreeNode(30)
    root.right = new TreeNode(70)
    root.left.left = new TreeNode(20)
    root.left.right = new TreeNode(40)
    root.right.left = new TreeNode(60)
    root.right.right = new TreeNode(80)

    // Set heights for visualization
    root.height = 3
    root.left.height = 2
    root.right.height = 2
    root.left.left.height = 1
    root.left.right.height = 1
    root.right.left.height = 1
    root.right.right.height = 1

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript AVL Tree implementation
class AVLNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
    this.height = 1; // Height of node in tree
  }
}

class AVLTree {
  constructor() {
    this.root = null;
  }
  
  // Get height of a node
  height(node) {
    return node ? node.height : 0;
  }
  
  // Get balance factor of a node
  getBalanceFactor(node) {
    return node ? this.height(node.left) - this.height(node.right) : 0;
  }
  
  // Update height of a node
  updateHeight(node) {
    node.height = Math.max(this.height(node.left), this.height(node.right)) + 1;
  }
  
  // Right rotation
  rightRotate(y) {
    const x = y.left;
    const T2 = x.right;
    
    // Perform rotation
    x.right = y;
    y.left = T2;
    
    // Update heights
    this.updateHeight(y);
    this.updateHeight(x);
    
    return x;
  }
  
  // Left rotation
  leftRotate(x) {
    const y = x.right;
    const T2 = y.left;
    
    // Perform rotation
    y.left = x;
    x.right = T2;
    
    // Update heights
    this.updateHeight(x);
    this.updateHeight(y);
    
    return y;
  }
  
  // Insert a value
  insert(value) {
    this.root = this._insert(this.root, value);
  }
  
  _insert(node, value) {
    // Standard BST insert
    if (!node) return new AVLNode(value);
    
    if (value < node.value) {
      node.left = this._insert(node.left, value);
    } else if (value > node.value) {
      node.right = this._insert(node.right, value);
    } else {
      // Duplicate values not allowed
      return node;
    }
    
    // Update height of current node
    this.updateHeight(node);
    
    // Get balance factor to check if node became unbalanced
    const balance = this.getBalanceFactor(node);
    
    // Left Left Case
    if (balance > 1 && value < node.left.value) {
      return this.rightRotate(node);
    }
    
    // Right Right Case
    if (balance < -1 && value > node.right.value) {
      return this.leftRotate(node);
    }
    
    // Left Right Case
    if (balance > 1 && value > node.left.value) {
      node.left = this.leftRotate(node.left);
      return this.rightRotate(node);
    }
    
    // Right Left Case
    if (balance < -1 && value < node.right.value) {
      node.right = this.rightRotate(node.right);
      return this.leftRotate(node);
    }
    
    return node;
  }
  
  // Other methods like delete, search similar to BST
  // but with balance checks and rotations
}`)

    // Set operation complexity
    setOperationComplexity({
      Search: "O(log n) worst case",
      Insertion: "O(log n) worst case",
      Deletion: "O(log n) worst case",
      Traversal: "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("AVL Trees guarantee O(log n) operations through self-balancing.")
  }

  // Initialize Red-Black Tree
  const initializeRedBlackTree = () => {
    setDataStructure("redblack")
    setConceptTitle("Red-Black Tree")
    setConceptDescription(
      "A self-balancing binary search tree where each node has an extra bit for denoting the color of the node, either red or black.",
    )
    setMessage("Red-Black Trees maintain balance with color properties and rotations.")

    // Create a Red-Black tree
    const root = new TreeNode(50)
    root.isRed = false // Root is black
    root.left = new TreeNode(30)
    root.left.isRed = true // Red node
    root.right = new TreeNode(70)
    root.right.isRed = true // Red node
    root.left.left = new TreeNode(20)
    root.left.left.isRed = false // Black node
    root.left.right = new TreeNode(40)
    root.left.right.isRed = false // Black node
    root.right.left = new TreeNode(60)
    root.right.left.isRed = false // Black node
    root.right.right = new TreeNode(80)
    root.right.right.isRed = false // Black node

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Red-Black Tree implementation
class RBNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
    this.color = "RED"; // New nodes are always red
    this.parent = null;
  }
}

class RedBlackTree {
  constructor() {
    this.root = null;
    this.NIL = new RBNode(null); // Sentinel node
    this.NIL.color = "BLACK";
    this.NIL.left = null;
    this.NIL.right = null;
  }
  
  // Left rotation
  leftRotate(x) {
    const y = x.right;
    x.right = y.left;
    
    if (y.left !== this.NIL) {
      y.left.parent = x;
    }
    
    y.parent = x.parent;
    
    if (x.parent === null) {
      this.root = y;
    } else if (x === x.parent.left) {
      x.parent.left = y;
    } else {
      x.parent.right = y;
    }
    
    y.left = x;
    x.parent = y;
  }
  
  // Right rotation
  rightRotate(y) {
    const x = y.left;
    y.left = x.right;
    
    if (x.right !== this.NIL) {
      x.right.parent = y;
    }
    
    x.parent = y.parent;
    
    if (y.parent === null) {
      this.root = x;
    } else if (y === y.parent.left) {
      y.parent.left = x;
    } else {
      y.parent.right = x;
    }
    
    x.right = y;
    y.parent = x;
  }
  
  // Insert a value
  insert(value) {
    const node = new RBNode(value);
    node.left = this.NIL;
    node.right = this.NIL;
    
    let y = null;
    let x = this.root;
    
    // Find position to insert
    while (x !== null && x !== this.NIL) {
      y = x;
      if (node.value < x.value) {
        x = x.left;
      } else {
        x = x.right;
      }
    }
    
    node.parent = y;
    
    if (y === null) {
      this.root = node; // Tree was empty
    } else if (node.value < y.value) {
      y.left = node;
    } else {
      y.right = node;
    }
    
    // If new node is root, color it black and return
    if (node.parent === null) {
      node.color = "BLACK";
      return;
    }
    
    // If grandparent is null, return
    if (node.parent.parent === null) {
      return;
    }
    
    // Fix Red-Black properties
    this.fixInsert(node);
  }
  
  // Fix Red-Black Tree properties after insertion
  fixInsert(k) {
    while (k.parent && k.parent.color === "RED") {
      if (k.parent === k.parent.parent.right) {
        // Parent is right child of grandparent
        const u = k.parent.parent.left; // Uncle
        
        if (u.color === "RED") {
          // Case 1: Uncle is red
          u.color = "BLACK";
          k.parent.color = "BLACK";
          k.parent.parent.color = "RED";
          k = k.parent.parent;
        } else {
          if (k === k.parent.left) {
            // Case 2: Uncle is black, k is left child
            k = k.parent;
            this.rightRotate(k);
          }
          // Case 3: Uncle is black, k is right child
          k.parent.color = "BLACK";
          k.parent.parent.color = "RED";
          this.leftRotate(k.parent.parent);
        }
      } else {
        // Parent is left child of grandparent (mirror cases)
        const u = k.parent.parent.right; // Uncle
        
        if (u.color === "RED") {
          // Case 1: Uncle is red
          u.color = "BLACK";
          k.parent.color = "BLACK";
          k.parent.parent.color = "RED";
          k = k.parent.parent;
        } else {
          if (k === k.parent.right) {
            // Case 2: Uncle is black, k is right child
            k = k.parent;
            this.leftRotate(k);
          }
          // Case 3: Uncle is black, k is left child
          k.parent.color = "BLACK";
          k.parent.parent.color = "RED";
          this.rightRotate(k.parent.parent);
        }
      }
      
      if (k === this.root) {
        break;
      }
    }
    
    // Root must be black
    this.root.color = "BLACK";
  }
  
  // Other methods like delete, search similar to BST
  // but with color fixes and rotations
}`)

    // Set operation complexity
    setOperationComplexity({
      Search: "O(log n) worst case",
      Insertion: "O(log n) worst case",
      Deletion: "O(log n) worst case",
      Traversal: "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("Red-Black Trees guarantee O(log n) operations with simpler balancing than AVL trees.")
  }

  // Initialize Heap
  const initializeHeap = () => {
    setDataStructure("heap")
    setConceptTitle("Heap")
    setConceptDescription(
      "A specialized tree-based data structure that satisfies the heap property: in a max heap, for any given node C, if P is a parent node of C, then the key of P is greater than or equal to the key of C.",
    )
    setMessage("Heaps provide efficient access to the maximum or minimum element.")

    // Create a max heap (represented as a binary tree for visualization)
    const root = new TreeNode(100)
    root.left = new TreeNode(80)
    root.right = new TreeNode(90)
    root.left.left = new TreeNode(40)
    root.left.right = new TreeNode(50)
    root.right.left = new TreeNode(70)
    root.right.right = new TreeNode(60)

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Max Heap implementation
class MaxHeap {
  constructor() {
    this.heap = [];
  }
  
  // Helper methods
  getParentIndex(index) {
    return Math.floor((index - 1) / 2);
  }
  
  getLeftChildIndex(index) {
    return 2 * index + 1;
  }
  
  getRightChildIndex(index) {
    return 2 * index + 2;
  }
  
  swap(i, j) {
    [this.heap[i], this.heap[j]] = [this.heap[j], this.heap[i]];
  }
  
  // Insert a value (O(log n))
  insert(value) {
    this.heap.push(value);
    this.heapifyUp(this.heap.length - 1);
  }
  
  // Remove and return the maximum value (O(log n))
  extractMax() {
    if (this.heap.length === 0) return null;
    
    const max = this.heap[0];
    const last = this.heap.pop();
    
    if (this.heap.length > 0) {
      this.heap[0] = last;
      this.heapifyDown(0);
    }
    
    return max;
  }
  
  // Get maximum value without removing (O(1))
  findMax() {
    return this.heap.length > 0 ? this.heap[0] : null;
  }
  
  // Restore heap property upward
  heapifyUp(index) {
    let currentIndex = index;
    let parentIndex = this.getParentIndex(currentIndex);
    
    // While not at root and parent is less than current
    while (currentIndex > 0 && this.heap[parentIndex] < this.heap[currentIndex]) {
      this.swap(currentIndex, parentIndex);
      currentIndex = parentIndex;
      parentIndex = this.getParentIndex(currentIndex);
    }
  }
  
  // Restore heap property downward
  heapifyDown(index) {
    let currentIndex = index;
    let largest = currentIndex;
    const leftIndex = this.getLeftChildIndex(currentIndex);
    const rightIndex = this.getRightChildIndex(currentIndex);
    const size = this.heap.length;
    
    // Check if left child exists and is greater than current
    if (leftIndex < size && this.heap[leftIndex] > this.heap[largest]) {
      largest = leftIndex;
    }
    
    // Check if right child exists and is greater than current largest
    if (rightIndex < size && this.heap[rightIndex] > this.heap[largest]) {
      largest = rightIndex;
    }
    
    // If largest is not current, swap and continue heapifying
    if (largest !== currentIndex) {
      this.swap(currentIndex, largest);
      this.heapifyDown(largest);
    }
  }
  
  // Build heap from array (O(n))
  buildHeap(array) {
    this.heap = array;
    // Start from last non-leaf node and heapify down
    for (let i = Math.floor(this.heap.length / 2) - 1; i >= 0; i--) {
      this.heapifyDown(i);
    }
  }
}

// Min Heap is similar but with reversed comparisons`)

    // Set operation complexity
    setOperationComplexity({
      Insert: "O(log n)",
      "Extract Min/Max": "O(log n)",
      "Find Min/Max": "O(1)",
      "Build Heap": "O(n)",
      Space: "O(n)",
    })

    setCurrentOperation("Heaps are used for priority queues, scheduling, and heap sort algorithm.")
  }

  // Initialize Hash Table
  const initializeHashTable = () => {
    setDataStructure("hashtable")
    setConceptTitle("Hash Table")
    setConceptDescription(
      "A data structure that implements an associative array abstract data type, a structure that can map keys to values using a hash function.",
    )
    setMessage("Hash Tables provide fast insertion, deletion, and lookup operations.")

    // Create a hash table with some entries
    const table: HashEntry[][] = Array(8)
      .fill(null)
      .map(() => [])

    // Add some entries
    table[0].push(new HashEntry("name", "John"))
    table[2].push(new HashEntry("age", "30"))
    table[2].push(new HashEntry("city", "New York")) // Collision example
    table[5].push(new HashEntry("job", "Developer"))
    table[7].push(new HashEntry("email", "john@example.com"))

    // Position entries
    for (let i = 0; i < table.length; i++) {
      for (let j = 0; j < table[i].length; j++) {
        table[i][j].x = 150 + j * 120
        table[i][j].y = 80 + i * 40
      }
    }

    setHashTable(table)

    // Set code snippet
    setCodeSnippet(`// JavaScript Hash Table implementation
class HashTable {
  constructor(size = 53) {
    this.table = new Array(size);
    this.size = size;
  }
  
  // Hash function to convert key to index
  hash(key) {
    let total = 0;
    const PRIME = 31;
    
    // Loop through first 100 chars of key or entire key, whichever is shorter
    for (let i = 0; i < Math.min(key.length, 100); i++) {
      const char = key[i];
      const value = char.charCodeAt(0) - 96; // Get char code
      total = (total * PRIME + value) % this.size;
    }
    
    return total;
  }
  
  // Set key-value pair (O(1) average case)
  set(key, value) {
    const index = this.hash(key);
    
    // If no bucket at index, create one
    if (!this.table[index]) {
      this.table[index] = [];
    }
    
    // Check if key already exists to update
    for (let i = 0; i < this.table[index].length; i++) {
      if (this.table[index][i][0] === key) {
        this.table[index][i][1] = value;
        return;
      }
    }
    
    // Key doesn't exist, add new key-value pair
    this.table[index].push([key, value]);
  }
  
  // Get value by key (O(1) average case)
  get(key) {
    const index = this.hash(key);
    
    if (!this.table[index]) return undefined;
    
    // Search through bucket for key
    for (const keyValue of this.table[index]) {
      if (keyValue[0] === key) {
        return keyValue[1];
      }
    }
    
    return undefined;
  }
  
  // Delete key-value pair (O(1) average case)
  delete(key) {
    const index = this.hash(key);
    
    if (!this.table[index]) return false;
    
    // Find and remove key-value pair
    for (let i = 0; i < this.table[index].length; i++) {
      if (this.table[index][i][0] === key) {
        this.table[index].splice(i, 1);
        return true;
      }
    }
    
    return false;
  }
  
  // Get all keys
  keys() {
    const keysArr = [];
    
    for (let i = 0; i < this.table.length; i++) {
      if (this.table[i]) {
        for (const keyValue of this.table[i]) {
          keysArr.push(keyValue[0]);
        }
      }
    }
    
    return keysArr;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Insert: "O(1) average, O(n) worst case",
      Search: "O(1) average, O(n) worst case",
      Delete: "O(1) average, O(n) worst case",
      Space: "O(n)",
    })

    setCurrentOperation("Hash Tables provide constant-time operations on average through hashing.")
  }

  // Initialize Graph
  const initializeGraph = () => {
    setDataStructure("graph")
    setConceptTitle("Graph")
    setConceptDescription(
      "A non-linear data structure consisting of nodes (vertices) and edges that connect these nodes, representing relationships between pairs of objects.",
    )
    setMessage("Graphs represent connections between objects and are used in many applications.")

    // Create a graph with some nodes and edges
    const nodes: GraphNode[] = []

    // Create nodes
    for (let i = 0; i < 6; i++) {
      const node = new GraphNode(i)

      // Position in a circle
      const angle = (i / 6) * Math.PI * 2
      node.x = canvasSize.width / 2 + Math.cos(angle) * 150
      node.y = canvasSize.height / 2 + Math.sin(angle) * 150

      nodes.push(node)
    }

    // Add connections
    nodes[0].connections = [1, 2, 5]
    nodes[1].connections = [0, 2, 3]
    nodes[2].connections = [0, 1, 3, 4]
    nodes[3].connections = [1, 2, 4]
    nodes[4].connections = [2, 3, 5]
    nodes[5].connections = [0, 4]

    setGraph(nodes)

    // Set code snippet
    setCodeSnippet(`// JavaScript Graph implementation (Adjacency List)
class Graph {
  constructor() {
    this.adjacencyList = {};
  }
  
  // Add a vertex
  addVertex(vertex) {
    if (!this.adjacencyList[vertex]) {
      this.adjacencyList[vertex] = [];
    }
  }
  
  // Add an edge (undirected)
  addEdge(vertex1, vertex2) {
    if (this.adjacencyList[vertex1] && this.adjacencyList[vertex2]) {
      this.adjacencyList[vertex1].push(vertex2);
      this.adjacencyList[vertex2].push(vertex1);
    }
  }
  
  // Remove an edge
  removeEdge(vertex1, vertex2) {
    if (this.adjacencyList[vertex1] && this.adjacencyList[vertex2]) {
      this.adjacencyList[vertex1] = this.adjacencyList[vertex1].filter(v => v !== vertex2);
      this.adjacencyList[vertex2] = this.adjacencyList[vertex2].filter(v => v !== vertex1);
    }
  }
  
  // Remove a vertex
  removeVertex(vertex) {
    if (!this.adjacencyList[vertex]) return;
    
    // Remove all edges connected to this vertex
    while (this.adjacencyList[vertex].length) {
      const adjacentVertex = this.adjacencyList[vertex].pop();
      this.removeEdge(vertex, adjacentVertex);
    }
    
    delete this.adjacencyList[vertex];
  }
  
  // Depth-First Search (recursive)
  dfsRecursive(start) {
    const result = [];
    const visited = {};
    const adjacencyList = this.adjacencyList;
    
    (function dfs(vertex) {
      if (!vertex) return null;
      
      visited[vertex] = true;
      result.push(vertex);
      
      adjacencyList[vertex].forEach(neighbor => {
        if (!visited[neighbor]) {
          return dfs(neighbor);
        }
      });
    })(start);
    
    return result;
  }
  
  // Depth-First Search (iterative)
  dfsIterative(start) {
    const stack = [start];
    const result = [];
    const visited = {};
    visited[start] = true;
    
    while (stack.length) {
      const currentVertex = stack.pop();
      result.push(currentVertex);
      
      this.adjacencyList[currentVertex].forEach(neighbor => {
        if (!visited[neighbor]) {
          visited[neighbor] = true;
          stack.push(neighbor);
        }
      });
    }
    
    return result;
  }
  
  // Breadth-First Search
  bfs(start) {
    const queue = [start];
    const result = [];
    const visited = {};
    visited[start] = true;
    
    while (queue.length) {
      const currentVertex = queue.shift();
      result.push(currentVertex);
      
      this.adjacencyList[currentVertex].forEach(neighbor => {
        if (!visited[neighbor]) {
          visited[neighbor] = true;
          queue.push(neighbor);
        }
      });
    }
}`)

    // Set operation complexity
    setOperationComplexity({
      "Add Vertex": "O(1)",
      "Add Edge": "O(1)",
      "Remove Vertex": "O(|V| + |E|)",
      "Remove Edge": "O(|E|)",
      "DFS/BFS": "O(|V| + |E|)",
      Space: "O(|V| + |E|)",
    })

    setCurrentOperation("Graphs are used for social networks, maps, routing algorithms, and more.")
  }

  // Initialize Trie
  const initializeTrie = () => {
    setDataStructure("trie")
    setConceptTitle("Trie")
    setConceptDescription(
      "A tree-like data structure used to store a dynamic set of strings, where the keys are usually strings and common prefixes are shared.",
    )
    setMessage("Tries efficiently store and search strings with common prefixes.")

    // Create a trie (represented as a tree for visualization)
    const root = new TreeNode(0) // Root node (empty)
    root.color = "#4fd1c5"

    // Add some children to represent a trie with words "cat", "car", "dog"
    root.left = new TreeNode("c".charCodeAt(0))
    root.left.left = new TreeNode("a".charCodeAt(0))
    root.left.left.left = new TreeNode("t".charCodeAt(0))
    root.left.left.right = new TreeNode("r".charCodeAt(0))

    root.right = new TreeNode("d".charCodeAt(0))
    root.right.left = new TreeNode("o".charCodeAt(0))
    root.right.left.left = new TreeNode("g".charCodeAt(0))

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Trie implementation
class TrieNode {
  constructor() {
    this.children = {};
    this.isEndOfWord = false;
  }
}

class Trie {
  constructor() {
    this.root = new TrieNode();
  }
  
  // Insert a word (O(m) where m is word length)
  insert(word) {
    let current = this.root;
    
    for (const char of word) {
      if (!current.children[char]) {
        current.children[char] = new TrieNode();
      }
      current = current.children[char];
    }
    
    current.isEndOfWord = true;
  }
  
  // Search for a word (O(m) where m is word length)
  search(word) {
    let current = this.root;
    
    for (const char of word) {
      if (!current.children[char]) {
        return false;
      }
      current = current.children[char];
    }
    
    return current.isEndOfWord;
  }
  
  // Check if there is any word that starts with the given prefix
  startsWith(prefix) {
    let current = this.root;
    
    for (const char of prefix) {
      if (!current.children[char]) {
        return false;
      }
      current = current.children[char];
    }
    
    return true;
  }
  
  // Delete a word
  delete(word) {
    this._delete(this.root, word, 0);
  }
  
  _delete(current, word, index) {
    // Base case: end of word
    if (index === word.length) {
      // Word doesn't exist
      if (!current.isEndOfWord) return false;
      
      current.isEndOfWord = false;
      
      // Return true if node has no children, can be deleted
      return Object.keys(current.children).length === 0;
    }
    
    const char = word[index];
    
    // Word doesn't exist
    if (!current.children[char]) return false;
    
    // Recursively delete
    const shouldDeleteCurrentNode = this._delete(current.children[char], word, index + 1);
    
    // If child can be deleted, remove it
    if (shouldDeleteCurrentNode) {
      delete current.children[char];
      
      // Return true if node has no children and is not end of another word
      return Object.keys(current.children).length === 0 && !current.isEndOfWord;
    }
    
    return false;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Insert: "O(m) where m is key length",
      Search: "O(m) where m is key length",
      Delete: "O(m) where m is key length",
      Space: "O(ALPHABET_SIZE * m * n) where n is number of keys",
    })

    setCurrentOperation("Tries are used for autocomplete, spell checking, and IP routing.")
  }

  // Initialize B-Tree
  const initializeBTree = () => {
    setDataStructure("btree")
    setConceptTitle("B-Tree")
    setConceptDescription(
      "A self-balancing tree data structure that maintains sorted data and allows searches, sequential access, insertions, and deletions in logarithmic time.",
    )
    setMessage("B-Trees are optimized for systems that read and write large blocks of data.")

    // Create a simple B-tree (represented as a tree for visualization)
    const root = new TreeNode(50)
    root.color = "#4fd1c5"

    // B-tree nodes typically have multiple keys
    root.left = new TreeNode(20)
    root.left.color = "#4fd1c5"
    root.right = new TreeNode(80)
    root.right.color = "#4fd1c5"

    // Add children
    root.left.left = new TreeNode(10)
    root.left.right = new TreeNode(30)
    root.right.left = new TreeNode(60)
    root.right.right = new TreeNode(90)

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript B-Tree implementation (simplified)
class BTreeNode {
  constructor(leaf = true) {
    this.keys = [];      // Array of keys
    this.children = [];  // Array of child pointers
    this.leaf = leaf;    // Is this a leaf node?
    this.n = 0;          // Current number of keys
  }
}

class BTree {
  constructor(t) {
    this.root = null;
    this.t = t; // Minimum degree (defines the range for number of keys)
  }
  
  // Search key in the B-Tree
  search(k, node = this.root) {
    if (!node) return null;
    
    // Find the first key greater than or equal to k
    let i = 0;
    while (i < node.n && k > node.keys[i]) {
      i++;
    }
    
    // If the found key is equal to k, return this node
    if (i < node.n && k === node.keys[i]) {
      return node;
    }
    
    // If key is not found and this is a leaf node
    if (node.leaf) {
      return null;
    }
    
    // Go to the appropriate child
    return this.search(k, node.children[i]);
  }
  
  // Insert a key in the B-Tree
  insert(k) {
    // If tree is empty
    if (!this.root) {
      this.root = new BTreeNode(true);
      this.root.keys[0] = k;
      this.root.n = 1;
      return;
    }
    
    // If root is full, tree grows in height
    if (this.root.n === 2 * this.t - 1) {
      const s = new BTreeNode(false);
      s.children[0] = this.root;
      
      // Split the old root and move a key to the new root
      this._splitChild(s, 0);
      
      // New root has two children. Decide which child gets the new key
      let i = 0;
      if (s.keys[0] < k) {
        i++;
      }
      this._insertNonFull(s.children[i], k);
      
      this.root = s;
    } else {
      // Root is not full, insert key
      this._insertNonFull(this.root, k);
    }
  }
  
  // Insert non-full helper method
  _insertNonFull(node, k) {
    let i = node.n - 1;
    
    if (node.leaf) {
      // Find position for new key and move all greater keys one space ahead
      while (i >= 0 && node.keys[i] > k) {
        node.keys[i + 1] = node.keys[i];
        i--;
      }
      
      // Insert the new key
      node.keys[i + 1] = k;
      node.n++;
    } else {
      // Find the child which is going to have the new key
      while (i >= 0 && node.keys[i] > k) {
        i--;
      }
      i++;
      
      // If the child is full, split it
      if (node.children[i].n === 2 * this.t - 1) {
        this._splitChild(node, i);
        
        // After split, the middle key goes up and node's children split
        if (node.keys[i] < k) {
          i++;
        }
      }
      
      this._insertNonFull(node.children[i], k);
    }
  }
  
  // Split child helper method
  _splitChild(parent, index) {
    const t = this.t;
    const child = parent.children[index];
    const newChild = new BTreeNode(child.leaf);
    newChild.n = t - 1;
    
    // Copy the last (t-1) keys of child to newChild
    for (let j = 0; j < t - 1; j++) {
      newChild.keys[j] = child.keys[j + t];
    }
    
    // Copy the last t children of child to newChild
    if (!child.leaf) {
      for (let j = 0; j < t; j++) {
        newChild.children[j] = child.children[j + t];
      }
    }
    
    // Reduce the number of keys in child
    child.n = t - 1;
    
    // Create space for new child in parent
    for (let j = parent.n; j > index; j--) {
      parent.children[j + 1] = parent.children[j];
    }
    
    // Link the new child to parent
    parent.children[index + 1] = newChild;
    
    // Move a key from child to parent
    for (let j = parent.n - 1; j >= index; j--) {
      parent.keys[j + 1] = parent.keys[j];
    }
    
    parent.keys[index] = child.keys[t - 1];
    parent.n++;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Search: "O(log n)",
      Insert: "O(log n)",
      Delete: "O(log n)",
      Space: "O(n)",
    })

    setCurrentOperation("B-Trees are commonly used in databases and file systems.")
  }

  // Initialize Segment Tree
  const initializeSegmentTree = () => {
    setDataStructure("segmenttree")
    setConceptTitle("Segment Tree")
    setConceptDescription(
      "A tree data structure used for storing information about intervals, or segments, allowing for efficient query operations over these intervals.",
    )
    setMessage("Segment Trees efficiently answer range queries like sum, minimum, maximum, etc.")

    // Create a segment tree (represented as a binary tree for visualization)
    const root = new TreeNode(28) // Sum of all elements

    // First level
    root.left = new TreeNode(9) // Sum of first half
    root.right = new TreeNode(19) // Sum of second half

    // Second level
    root.left.left = new TreeNode(4)
    root.left.right = new TreeNode(5)
    root.right.left = new TreeNode(8)
    root.right.right = new TreeNode(11)

    // Third level (leaf nodes representing original array)
    root.left.left.left = new TreeNode(1)
    root.left.left.right = new TreeNode(3)
    root.left.right.left = new TreeNode(2)
    root.left.right.right = new TreeNode(3)
    root.right.left.left = new TreeNode(4)
    root.right.left.right = new TreeNode(4)
    root.right.right.left = new TreeNode(5)
    root.right.right.right = new TreeNode(6)

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Segment Tree implementation
class SegmentTree {
  constructor(array) {
    this.array = array;
    this.tree = new Array(4 * array.length).fill(0);
    this.build(0, 0, array.length - 1);
  }
  
  // Build the segment tree
  build(node, start, end) {
    if (start === end) {
      // Leaf node will have a single element
      this.tree[node] = this.array[start];
      return;
    }
    
    const mid = Math.floor((start + end) / 2);
    
    // Recursively build left and right subtrees
    this.build(2 * node + 1, start, mid);
    this.build(2 * node + 2, mid + 1, end);
    
    // Internal node will have the sum of both of its children
    this.tree[node] = this.tree[2 * node + 1] + this.tree[2 * node + 2];
  }
  
  // Query the sum in range [l, r]
  query(node, start, end, l, r) {
    // If segment is outside the query range
    if (start > r || end < l) {
      return 0;
    }
    
    // If segment is completely inside the query range
    if (l <= start && end <= r) {
      return this.tree[node];
    }
    
    // Partial overlap, query both children
    const mid = Math.floor((start + end) / 2);
    const leftSum = this.query(2 * node + 1, start, mid, l, r);
    const rightSum = this.query(2 * node + 2, mid + 1, end, l, r);
    
    return leftSum + rightSum;
  }
  
  // Update the value at index 'idx' to 'val'
  update(node, start, end, idx, val) {
    // If the index is outside the current segment
    if (idx < start || idx > end) {
      return;
    }
    
    // If leaf node (the index we want to update)
    if (start === end) {
      this.array[idx] = val;
      this.tree[node] = val;
      return;
    }
    
    const mid = Math.floor((start + end) / 2);
    
    // Update the appropriate child
    this.update(2 * node + 1, start, mid, idx, val);
    this.update(2 * node + 2, mid + 1, end, idx, val);
    
    // Update current node based on children
    this.tree[node] = this.tree[2 * node + 1] + this.tree[2 * node + 2];
  }
  
  // Wrapper methods for easier use
  queryRange(l, r) {
    return this.query(0, 0, this.array.length - 1, l, r);
  }
  
  updateValue(idx, val) {
    this.update(0, 0, this.array.length - 1, idx, val);
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Build: "O(n)",
      Query: "O(log n)",
      Update: "O(log n)",
      Space: "O(n)",
    })

    setCurrentOperation("Segment Trees are used for range queries in competitive programming and databases.")
  }

  // Initialize Disjoint Set
  const initializeDisjointSet = () => {
    setDataStructure("disjointset")
    setConceptTitle("Disjoint Set")
    setConceptDescription(
      "A data structure that keeps track of a set of elements partitioned into a number of disjoint (non-overlapping) subsets.",
    )
    setMessage("Disjoint Sets (Union-Find) efficiently track connected components.")

    // Create a visualization of disjoint sets (using a tree representation)
    const root = new TreeNode(0) // Root of first set
    root.color = "#4fd1c5"

    // First set: 0 -> 1 -> 2
    root.left = new TreeNode(1)
    root.left.color = "#4fd1c5"
    root.left.left = new TreeNode(2)
    root.left.left.color = "#4fd1c5"

    // Second set: 3 -> 4 -> 5
    root.right = new TreeNode(3) // Root of second set
    root.right.color = "#9f7aea"
    root.right.right = new TreeNode(4)
    root.right.right.color = "#9f7aea"
    root.right.right.right = new TreeNode(5)
    root.right.right.right.color = "#9f7aea"

    // Position nodes
    positionBinaryTreeNodes(root, canvasSize.width / 2, 50, canvasSize.width / 2)
    setBinaryTree(root)

    // Set code snippet
    setCodeSnippet(`// JavaScript Disjoint Set (Union-Find) implementation
class DisjointSet {
  constructor(size) {
    // Initialize with each element as its own parent
    this.parent = Array.from({ length: size }, (_, i) => i);
    // Initialize rank (or size) of each set to 1
    this.rank = Array(size).fill(1);
  }
  
  // Find the representative (root) of the set containing element x
  // With path compression for efficiency
  find(x) {
    if (this.parent[x] !== x) {
      // Path compression: make the parent of x the root
      this.parent[x] = this.find(this.parent[x]);
    }
    return this.parent[x];
  }
  
  // Union by rank: attach smaller rank tree under root of higher rank tree
  union(x, y) {
    const rootX = this.find(x);
    const rootY = this.find(y);
    
    // If already in the same set
    if (rootX === rootY) return;
    
    // Union by rank
    if (this.rank[rootX] < this.rank[rootY]) {
      // Attach rootX under rootY
      this.parent[rootX] = rootY;
      this.rank[rootY] += this.rank[rootX];
    } else {
      // Attach rootY under rootX
      this.parent[rootY] = rootX;
      this.rank[rootX] += this.rank[rootY];
    }
  }
  
  // Check if two elements are in the same set
  connected(x, y) {
    return this.find(x) === this.find(y);
  }
  
  // Get the size of the set containing element x
  getSize(x) {
    return this.rank[this.find(x)];
  }
  
  // Get the number of disjoint sets
  getCount() {
    const roots = new Set();
    for (let i = 0; i < this.parent.length; i++) {
      roots.add(this.find(i));
    }
    return roots.size;
  }
}`)

    // Set operation complexity
    setOperationComplexity({
      Find: "O(α(n)) ≈ O(1)",
      Union: "O(α(n)) ≈ O(1)",
      Connected: "O(α(n)) ≈ O(1)",
      Space: "O(n)",
    })

    setCurrentOperation("Disjoint Sets are used for Kruskal's algorithm, network connectivity, and image processing.")
  }

  // Helper function to position linked list nodes
  const positionLinkedListNodes = (head: ListNode | null) => {
    if (!head) return

    let current = head
    let index = 0

    while (current) {
      current.x = 100 + index * 120
      current.y = canvasSize.height / 2
      current = current.next
      index++
    }
  }

  // Helper function to position binary tree nodes
  const positionBinaryTreeNodes = (node: TreeNode | null, x: number, y: number, width: number) => {
    if (!node) return

    node.x = x
    node.y = y

    if (node.left) {
      positionBinaryTreeNodes(node.left, x - width / 4, y + 60, width / 2)
    }

    if (node.right) {
      positionBinaryTreeNodes(node.right, x + width / 4, y + 60, width / 2)
    }
  }

  // Helper function to get tree traversal order
  const getTreeTraversalOrder = (root: TreeNode | null, order: string): number[] => {
    const values: number[] = []

    if (!root) return values

    if (order === "pre-order") {
      const preOrder = (node: TreeNode | null) => {
        if (!node) return
        values.push(node.value)
        preOrder(node.left)
        preOrder(node.right)
      }
      preOrder(root)
    } else if (order === "in-order") {
      const inOrder = (node: TreeNode | null) => {
        if (!node) return
        inOrder(node.left)
        values.push(node.value)
        inOrder(node.right)
      }
      inOrder(root)
    } else if (order === "post-order") {
      const postOrder = (node: TreeNode | null) => {
        if (!node) return
        postOrder(node.left)
        postOrder(node.right)
        values.push(node.value)
      }
      postOrder(root)
    } else if (order === "level-order") {
      const queue: TreeNode[] = [root]
      while (queue.length > 0) {
        const node = queue.shift()!
        values.push(node.value)
        if (node.left) queue.push(node.left)
        if (node.right) queue.push(node.right)
      }
    }

    return values
  }

  // Drawing functions for each data structure
  const drawArray = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const cellWidth = 60
    const cellHeight = 60
    const startX = (width - array.length * cellWidth) / 2
    const startY = height / 2 - cellHeight / 2

    // Draw array cells
    for (let i = 0; i < array.length; i++) {
      const x = startX + i * cellWidth
      const y = startY

      // Draw cell
      ctx.beginPath()
      ctx.rect(x, y, cellWidth, cellHeight)

      // Highlight cell if it's the current index
      if (i === highlightedIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw value
      ctx.fillStyle = "#ffffff"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(array[i].toString(), x + cellWidth / 2, y + cellHeight / 2)

      // Draw index
      ctx.fillStyle = "#a0aec0"
      ctx.font = "12px Arial"
      ctx.fillText(i.toString(), x + cellWidth / 2, y + cellHeight + 20)
    }

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawLinkedList = (ctx: CanvasRenderingContext2D) => {
    if (!linkedList) return

    let current = linkedList
    let index = 0
    let prevX = 0
    let prevY = 0

    while (current) {
      const x = current.x
      const y = current.y

      // Draw arrow from previous node
      if (prevX !== 0) {
        ctx.beginPath()
        ctx.moveTo(prevX + 30, prevY)
        ctx.lineTo(x - 30, y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw arrowhead
        const angle = Math.atan2(y - prevY, x - prevX)
        ctx.beginPath()
        ctx.moveTo(x - 30, y)
        ctx.lineTo(x - 30 - 10 * Math.cos(angle - Math.PI / 6), y - 10 * Math.sin(angle - Math.PI / 6))
        ctx.lineTo(x - 30 - 10 * Math.cos(angle + Math.PI / 6), y - 10 * Math.sin(angle + Math.PI / 6))
        ctx.closePath()
        ctx.fillStyle = "#4fd1c5"
        ctx.fill()
      }

      // Draw node
      ctx.beginPath()
      ctx.rect(x - 30, y - 25, 60, 50)

      // Highlight node if it's the current index
      if (index === highlightedIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw value
      ctx.fillStyle = "#ffffff"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(current.value.toString(), x, y - 10)

      // Draw next pointer
      ctx.fillStyle = "#a0aec0"
      ctx.font = "12px Arial"
      ctx.fillText(current.next ? "next" : "null", x, y + 10)

      // Save position for next arrow
      prevX = x
      prevY = y

      // Move to next node
      current = current.next
      index++
    }

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawStack = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const cellWidth = 100
    const cellHeight = 40
    const startX = width / 2 - cellWidth / 2

    // Draw stack container
    ctx.beginPath()
    ctx.rect(startX - 10, height / 2 - 150, cellWidth + 20, 300)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw stack elements from bottom to top
    for (let i = 0; i < stack.length; i++) {
      const y = height / 2 + 110 - i * (cellHeight + 10)

      // Draw element
      ctx.beginPath()
      ctx.rect(startX, y, cellWidth, cellHeight)

      // Highlight element if it's the top of the stack
      if (i === stack.length - 1) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw value
      ctx.fillStyle = "#ffffff"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(stack[i].toString(), startX + cellWidth / 2, y + cellHeight / 2)
    }

    // Draw top and bottom labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("Top", startX - 50, height / 2 - 140 + (stack.length > 0 ? 300 - stack.length * (cellHeight + 10) : 0))
    ctx.fillText("Bottom", startX - 50, height / 2 + 140)

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawQueue = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const cellWidth = 60
    const cellHeight = 60
    const startX = (width - queue.length * cellWidth) / 2
    const startY = height / 2 - cellHeight / 2

    // Draw queue elements
    for (let i = 0; i < queue.length; i++) {
      const x = startX + i * cellWidth

      // Draw element
      ctx.beginPath()
      ctx.rect(x, startY, cellWidth, cellHeight)

      // Highlight element if it's the front or rear of the queue
      if (i === 0 || i === queue.length - 1) {
        ctx.fillStyle = i === 0 ? "#9f7aea" : "#4fd1c5"
        ctx.shadowColor = i === 0 ? "#9f7aea" : "#4fd1c5"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw value
      ctx.fillStyle = "#ffffff"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(queue[i].toString(), x + cellWidth / 2, startY + cellHeight / 2)
    }

    // Draw front and rear labels
    if (queue.length > 0) {
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("Front", startX + cellWidth / 2, startY - 20)
      ctx.fillText("Rear", startX + (queue.length - 1) * cellWidth + cellWidth / 2, startY - 20)
    }

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawBinaryTree = (ctx: CanvasRenderingContext2D) => {
    if (!binaryTree) return

    // Helper function to draw a node and its children recursively
    const drawNode = (node: TreeNode | null) => {
      if (!node) return

      // Draw connections to children
      if (node.left) {
        ctx.beginPath()
        ctx.moveTo(node.x, node.y + 20)
        ctx.lineTo(node.left.x, node.left.y - 20)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      if (node.right) {
        ctx.beginPath()
        ctx.moveTo(node.x, node.y + 20)
        ctx.lineTo(node.right.x, node.right.y - 20)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw node
      ctx.beginPath()
      ctx.arc(node.x, node.y, 20, 0, Math.PI * 2)

      // Highlight node if it's the current value
      if (node.value === highlightedIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else if (dataStructure === "redblack" && node.isRed) {
        // Red node for Red-Black tree
        ctx.fillStyle = "#f56565"
        ctx.shadowColor = "#f56565"
        ctx.shadowBlur = 10
      } else {
        ctx.fillStyle = node.color || "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // For AVL tree, show height
      if (dataStructure === "avl" && node.height > 1) {
        ctx.fillStyle = "#a0aec0"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(`h:${node.height}`, node.x, node.y + 30)
      }

      // Draw node value
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      // For trie, convert ASCII to character if it's a letter
      let displayValue = node.value.toString()
      if (dataStructure === "trie" && node.value >= 97 && node.value <= 122) {
        displayValue = String.fromCharCode(node.value)
      }

      ctx.fillText(displayValue, node.x, node.y)

      // Draw children
      drawNode(node.left)
      drawNode(node.right)
    }

    // Start drawing from the root
    drawNode(binaryTree)

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawHeap = (ctx: CanvasRenderingContext2D) => {
    // Heap is visualized as a binary tree
    drawBinaryTree(ctx)

    // Add heap-specific labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Max Heap", canvasSize.width / 2, 20)
  }

  const drawHashTable = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const bucketHeight = 40
    const bucketWidth = 80
    const startX = width / 2 - 150
    const startY = 80

    // Draw hash table buckets
    for (let i = 0; i < hashTable.length; i++) {
      const y = startY + i * bucketHeight

      // Draw bucket
      ctx.beginPath()
      ctx.rect(startX, y, bucketWidth, bucketHeight)

      // Highlight bucket if it's the current index
      if (i === highlightedIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw bucket index
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(i.toString(), startX + bucketWidth / 2, y + bucketHeight / 2)

      // Draw entries in this bucket
      if (hashTable[i] && hashTable[i].length > 0) {
        for (let j = 0; j < hashTable[i].length; j++) {
          const entry = hashTable[i][j]
          const entryX = startX + bucketWidth + 20 + j * 120

          // Draw entry box
          ctx.beginPath()
          ctx.rect(entryX, y, 100, bucketHeight)
          ctx.fillStyle = "#4a5568"
          ctx.fill()
          ctx.strokeStyle = "#4fd1c5"
          ctx.lineWidth = 1
          ctx.stroke()

          // Draw key-value pair
          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(`${entry.key}: ${entry.value}`, entryX + 50, y + bucketHeight / 2)
        }
      }
    }

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawGraph = (ctx: CanvasRenderingContext2D) => {
    // Draw edges first
    for (let i = 0; i < graph.length; i++) {
      const node = graph[i]

      for (const connectedId of node.connections) {
        const connectedNode = graph[connectedId]

        ctx.beginPath()
        ctx.moveTo(node.x, node.y)
        ctx.lineTo(connectedNode.x, connectedNode.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()
      }
    }

    // Draw nodes
    for (let i = 0; i < graph.length; i++) {
      const node = graph[i]

      // Draw node
      ctx.beginPath()
      ctx.arc(node.x, node.y, 20, 0, Math.PI * 2)

      // Highlight node if it's the current index
      if (i === highlightedIndex) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node ID
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id.toString(), node.x, node.y)
    }

    // Reset shadow
    ctx.shadowBlur = 0
  }

  const drawTrie = (ctx: CanvasRenderingContext2D) => {
    // Trie is visualized as a tree
    drawBinaryTree(ctx)

    // Add trie-specific labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Trie (Prefix Tree)", canvasSize.width / 2, 20)
    ctx.font = "14px Arial"
    ctx.fillText("Words: 'cat', 'car', 'dog'", canvasSize.width / 2, 40)
  }

  const drawBTree = (ctx: CanvasRenderingContext2D) => {
    // B-Tree is visualized as a tree
    drawBinaryTree(ctx)

    // Add B-Tree-specific labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("B-Tree", canvasSize.width / 2, 20)
  }

  const drawSegmentTree = (ctx: CanvasRenderingContext2D) => {
    // Segment Tree is visualized as a binary tree
    drawBinaryTree(ctx)

    // Add Segment Tree-specific labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Segment Tree (Sum Query)", canvasSize.width / 2, 20)
    ctx.font = "14px Arial"
    ctx.fillText("Array: [1, 3, 2, 3, 4, 4, 5, 6]", canvasSize.width / 2, 40)
  }

  const drawDisjointSet = (ctx: CanvasRenderingContext2D) => {
    // Disjoint Set is visualized as a tree
    drawBinaryTree(ctx)

    // Add Disjoint Set-specific labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Disjoint Set (Union-Find)", canvasSize.width / 2, 20)
    ctx.font = "14px Arial"
    ctx.fillText("Two sets: {0,1,2} and {3,4,5}", canvasSize.width / 2, 40)
  }

  // Handle adding a value
  const handleAddValue = () => {
    const value = Number.parseInt(inputValue)

    if (isNaN(value)) {
      setMessage("Please enter a valid number")
      return
    }

    if (dataStructure === "array") {
      setArray([...array, value])
      setMessage(`Added ${value} to the array`)
    } else if (dataStructure === "linkedlist") {
      const newNode = new ListNode(value)

      if (!linkedList) {
        setLinkedList(newNode)
      } else {
        let current = linkedList
        while (current.next) {
          current = current.next
        }
        current.next = newNode
      }

      positionLinkedListNodes(linkedList)
      setMessage(`Added ${value} to the linked list`)
    } else if (dataStructure === "stack") {
      setStack([...stack, value])
      setMessage(`Pushed ${value} onto the stack`)
    } else if (dataStructure === "queue") {
      setQueue([...queue, value])
      setMessage(`Enqueued ${value} to the queue`)
    } else if (dataStructure === "bst" || dataStructure === "binarytree") {
      // Insert into BST
      const insertNode = (node: TreeNode | null, value: number): TreeNode => {
        if (!node) return new TreeNode(value)

        if (value < node.value) {
          node.left = insertNode(node.left, value)
        } else {
          node.right = insertNode(node.right, value)
        }

        return node
      }

      if (!binaryTree) {
        setBinaryTree(new TreeNode(value))
      } else {
        insertNode(binaryTree, value)
      }

      positionBinaryTreeNodes(binaryTree, canvasSize.width / 2, 50, canvasSize.width / 2)
      setMessage(`Added ${value} to the binary tree`)
    }

    setInputValue("")
  }

  // Handle searching for a value
  const handleSearchValue = () => {
    const value = Number.parseInt(searchValue)

    if (isNaN(value)) {
      setMessage("Please enter a valid number")
      return
    }

    if (dataStructure === "array") {
      const index = array.indexOf(value)
      if (index !== -1) {
        setHighlightedIndex(index)
        setMessage(`Found ${value} at index ${index}`)
      } else {
        setHighlightedIndex(null)
        setMessage(`${value} not found in the array`)
      }
    } else if (dataStructure === "linkedlist") {
      let current = linkedList
      let index = 0
      let found = false

      while (current) {
        if (current.value === value) {
          setHighlightedIndex(index)
          setMessage(`Found ${value} at position ${index}`)
          found = true
          break
        }
        current = current.next
        index++
      }

      if (!found) {
        setHighlightedIndex(null)
        setMessage(`${value} not found in the linked list`)
      }
    } else if (dataStructure === "bst" || dataStructure === "binarytree") {
      // Search in BST
      const searchNode = (node: TreeNode | null, value: number): boolean => {
        if (!node) return false

        if (node.value === value) {
          setHighlightedIndex(value)
          return true
        }

        if (value < node.value) {
          return searchNode(node.left, value)
        } else {
          return searchNode(node.right, value)
        }
      }

      const found = searchNode(binaryTree, value)

      if (found) {
        setMessage(`Found ${value} in the binary tree`)
      } else {
        setHighlightedIndex(null)
        setMessage(`${value} not found in the binary tree`)
      }
    }

    setSearchValue("")

    // Clear highlight after a delay
    setTimeout(() => {
      setHighlightedIndex(null)
    }, 2000)
  }

  // Handle removing a value
  const handleRemoveValue = () => {
    const value = Number.parseInt(inputValue)

    if (isNaN(value)) {
      setMessage("Please enter a valid number")
      return
    }

    if (dataStructure === "array") {
      const index = array.indexOf(value)
      if (index !== -1) {
        const newArray = [...array]
        newArray.splice(index, 1)
        setArray(newArray)
        setMessage(`Removed ${value} from the array`)
      } else {
        setMessage(`${value} not found in the array`)
      }
    } else if (dataStructure === "linkedlist") {
      if (!linkedList) {
        setMessage("Linked list is empty")
        return
      }

      if (linkedList.value === value) {
        setLinkedList(linkedList.next)
        positionLinkedListNodes(linkedList)
        setMessage(`Removed ${value} from the linked list`)
        return
      }

      let current = linkedList
      while (current.next && current.next.value !== value) {
        current = current.next
      }

      if (current.next) {
        current.next = current.next.next
        positionLinkedListNodes(linkedList)
        setMessage(`Removed ${value} from the linked list`)
      } else {
        setMessage(`${value} not found in the linked list`)
      }
    } else if (dataStructure === "stack") {
      if (stack.length > 0 && stack[stack.length - 1] === value) {
        setStack(stack.slice(0, -1))
        setMessage(`Popped ${value} from the stack`)
      } else {
        setMessage(`Can only pop the top element (${stack.length > 0 ? stack[stack.length - 1] : "none"})`)
      }
    } else if (dataStructure === "queue") {
      if (queue.length > 0 && queue[0] === value) {
        setQueue(queue.slice(1))
        setMessage(`Dequeued ${value} from the queue`)
      } else {
        setMessage(`Can only dequeue the front element (${queue.length > 0 ? queue[0] : "none"})`)
      }
    } else if (dataStructure === "bst") {
      // Remove from BST
      const removeNode = (node: TreeNode | null, value: number): TreeNode | null => {
        if (!node) return null

        if (value < node.value) {
          node.left = removeNode(node.left, value)
          return node
        } else if (value > node.value) {
          node.right = removeNode(node.right, value)
          return node
        } else {
          // Case 1: Leaf node
          if (!node.left && !node.right) {
            return null
          }

          // Case 2: One child
          if (!node.left) return node.right
          if (!node.right) return node.left

          // Case 3: Two children
          let successor = node.right
          while (successor.left) {
            successor = successor.left
          }

          node.value = successor.value
          node.right = removeNode(node.right, successor.value)
          return node
        }
      }

      const newRoot = removeNode(binaryTree, value)
      setBinaryTree(newRoot)

      if (newRoot) {
        positionBinaryTreeNodes(newRoot, canvasSize.width / 2, 50, canvasSize.width / 2)
      }

      setMessage(`Removed ${value} from the binary tree`)
    }

    setInputValue("")
  }

  // Start animation
  const handleStartAnimation = () => {
    setIsPlaying(true)
    setAnimationStep(0)
    setMessage(`Starting ${dataStructure} animation...`)
  }

  // Pause animation
  const handlePauseAnimation = () => {
    setIsPlaying(false)
    setMessage(`Paused ${dataStructure} animation`)
  }

  // Reset data structure
  const handleReset = () => {
    if (dataStructure === "array") {
      initializeArray()
    } else if (dataStructure === "linkedlist") {
      initializeLinkedList()
    } else if (dataStructure === "stack") {
      initializeStack()
    } else if (dataStructure === "queue") {
      initializeQueue()
    } else if (dataStructure === "binarytree") {
      initializeBinaryTree()
    } else if (dataStructure === "bst") {
      initializeBST()
    } else if (dataStructure === "avl") {
      initializeAVLTree()
    } else if (dataStructure === "redblack") {
      initializeRedBlackTree()
    } else if (dataStructure === "heap") {
      initializeHeap()
    } else if (dataStructure === "hashtable") {
      initializeHashTable()
    } else if (dataStructure === "graph") {
      initializeGraph()
    } else if (dataStructure === "trie") {
      initializeTrie()
    } else if (dataStructure === "btree") {
      initializeBTree()
    } else if (dataStructure === "segmenttree") {
      initializeSegmentTree()
    } else if (dataStructure === "disjointset") {
      initializeDisjointSet()
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleReset}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={handlePauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        onClick={handleStartAnimation}
                        className="bg-cyan-600 hover:bg-cyan-700 text-white"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Animate
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>
              </CardContent>
            </Card>

            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm mt-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Implementation</h3>
                <div className="bg-gray-800/50 p-4 rounded-md overflow-auto max-h-80">
                  <pre className="text-cyan-300 text-sm font-mono whitespace-pre-wrap">{codeSnippet}</pre>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-6"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Operations</h3>
                    <div className="space-y-4">
                      <div className="flex space-x-2">
                        <Input
                          type="number"
                          placeholder="Enter a value"
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          className="bg-gray-800/50 border-gray-700 text-white"
                        />
                      </div>

                      <div className="flex space-x-2">
                        <Button onClick={handleAddValue} className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-white">
                          <Plus className="h-4 w-4 mr-2" />
                          Add
                        </Button>
                        <Button
                          onClick={handleRemoveValue}
                          className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                        >
                          <Minus className="h-4 w-4 mr-2" />
                          Remove
                        </Button>
                      </div>

                      <div className="pt-2 border-t border-gray-800">
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Search</h3>
                        <div className="flex space-x-2">
                          <Input
                            type="number"
                            placeholder="Search value"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                            className="bg-gray-800/50 border-gray-700 text-white"
                          />
                          <Button onClick={handleSearchValue} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                            Search
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Time Complexity</h3>
                    <div className="space-y-2 text-sm">
                      {Object.entries(operationComplexity).map(([operation, complexity]) => (
                        <div key={operation} className="flex justify-between">
                          <span className="text-gray-300">{operation}:</span>
                          <span className="text-cyan-400 font-mono">{complexity}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Current Operation</h3>
                    <p className="text-sm text-gray-300">{currentOperation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="data-structures" title="Data Structure" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
