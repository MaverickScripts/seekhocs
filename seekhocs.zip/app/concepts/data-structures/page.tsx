"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Plus, Minus, RotateCcw } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Binary Tree Node class
class TreeNode {
  value: number
  left: TreeNode | null
  right: TreeNode | null
  x: number
  y: number

  constructor(value: number) {
    this.value = value
    this.left = null
    this.right = null
    this.x = 0
    this.y = 0
  }
}

// Binary Search Tree implementation
class BinarySearchTree {
  root: TreeNode | null

  constructor() {
    this.root = null
  }

  insert(value: number) {
    const newNode = new TreeNode(value)

    if (this.root === null) {
      this.root = newNode
      return
    }

    const insertNode = (node: TreeNode, newNode: TreeNode) => {
      if (newNode.value < node.value) {
        if (node.left === null) {
          node.left = newNode
        } else {
          insertNode(node.left, newNode)
        }
      } else {
        if (node.right === null) {
          node.right = newNode
        } else {
          insertNode(node.right, newNode)
        }
      }
    }

    insertNode(this.root, newNode)
  }

  search(value: number): TreeNode | null {
    const searchNode = (node: TreeNode | null, value: number): TreeNode | null => {
      if (node === null) return null
      if (node.value === value) return node

      if (value < node.value) {
        return searchNode(node.left, value)
      } else {
        return searchNode(node.right, value)
      }
    }

    return searchNode(this.root, value)
  }

  delete(value: number) {
    const removeNode = (node: TreeNode | null, value: number): TreeNode | null => {
      if (node === null) return null

      if (value < node.value) {
        node.left = removeNode(node.left, value)
        return node
      } else if (value > node.value) {
        node.right = removeNode(node.right, value)
        return node
      } else {
        // Case 1: Leaf node (no children)
        if (node.left === null && node.right === null) {
          return null
        }

        // Case 2: Node with one child
        if (node.left === null) {
          return node.right
        }

        if (node.right === null) {
          return node.left
        }

        // Case 3: Node with two children
        // Find the minimum value in the right subtree
        let successor = node.right
        while (successor.left !== null) {
          successor = successor.left
        }

        // Replace the node's value with the successor's value
        node.value = successor.value

        // Delete the successor
        node.right = removeNode(node.right, successor.value)
        return node
      }
    }

    this.root = removeNode(this.root, value)
  }

  // Calculate positions for visualization
  calculatePositions() {
    const calculateNodePositions = (node: TreeNode | null, depth: number, position: number, width: number) => {
      if (node === null) return

      const horizontalSpacing = width / Math.pow(2, depth)
      node.x = position
      node.y = depth * 80

      calculateNodePositions(node.left, depth + 1, position - horizontalSpacing / 2, width)
      calculateNodePositions(node.right, depth + 1, position + horizontalSpacing / 2, width)
    }

    if (this.root) {
      calculateNodePositions(this.root, 0, 400, 800)
    }
  }
}

// Linked List Node class
class ListNode {
  value: number
  next: ListNode | null
  x: number
  y: number

  constructor(value: number) {
    this.value = value
    this.next = null
    this.x = 0
    this.y = 0
  }
}

// Linked List implementation
class LinkedList {
  head: ListNode | null

  constructor() {
    this.head = null
  }

  append(value: number) {
    const newNode = new ListNode(value)

    if (this.head === null) {
      this.head = newNode
      return
    }

    let current = this.head
    while (current.next !== null) {
      current = current.next
    }

    current.next = newNode
  }

  prepend(value: number) {
    const newNode = new ListNode(value)
    newNode.next = this.head
    this.head = newNode
  }

  delete(value: number) {
    if (this.head === null) return

    if (this.head.value === value) {
      this.head = this.head.next
      return
    }

    let current = this.head
    while (current.next !== null && current.next.value !== value) {
      current = current.next
    }

    if (current.next !== null) {
      current.next = current.next.next
    }
  }

  // Calculate positions for visualization
  calculatePositions() {
    let current = this.head
    let index = 0

    while (current !== null) {
      current.x = 100 + index * 120
      current.y = 100
      current = current.next
      index++
    }
  }
}

// Stack implementation
class Stack {
  items: number[]

  constructor() {
    this.items = []
  }

  push(value: number) {
    this.items.push(value)
  }

  pop(): number | undefined {
    return this.items.pop()
  }

  peek(): number | undefined {
    return this.items[this.items.length - 1]
  }

  isEmpty(): boolean {
    return this.items.length === 0
  }

  size(): number {
    return this.items.length
  }
}

// Queue implementation
class Queue {
  items: number[]

  constructor() {
    this.items = []
  }

  enqueue(value: number) {
    this.items.push(value)
  }

  dequeue(): number | undefined {
    return this.items.shift()
  }

  front(): number | undefined {
    return this.items[0]
  }

  isEmpty(): boolean {
    return this.items.length === 0
  }

  size(): number {
    return this.items.length
  }
}

export default function DataStructuresPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [dataStructure, setDataStructure] = useState("bst")
  const [inputValue, setInputValue] = useState("")
  const [searchValue, setSearchValue] = useState("")
  const [bst] = useState(new BinarySearchTree())
  const [linkedList] = useState(new LinkedList())
  const [stack] = useState(new Stack())
  const [queue] = useState(new Queue())
  const [highlightedNode, setHighlightedNode] = useState<number | null>(null)
  const [message, setMessage] = useState("")
  const [isAnimating, setIsAnimating] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Data Structures Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore and interact with common data structures through visual representations",
  )
  const [conceptProperties, setConceptProperties] = useState<{
    operations: string[]
    complexity: { time: string; space: string }
  }>({
    operations: [],
    complexity: { time: "", space: "" },
  })

  // Set data structure based on selected concept
  useEffect(() => {
    if (selectedConcept) {
      // Set data structure based on selected concept
      if (
        selectedConcept.toLowerCase().includes("binary search tree") ||
        selectedConcept.toLowerCase().includes("bst")
      ) {
        setDataStructure("bst")
        setConceptTitle("Binary Search Tree")
        setConceptDescription(
          "A tree data structure where each node has at most two children, with all left descendants less than the node and all right descendants greater.",
        )
        setMessage(
          "Binary Search Tree: A tree data structure where each node has at most two children, with all left descendants less than the node and all right descendants greater.",
        )
        setConceptProperties({
          operations: [
            "Insert: O(log n) average, O(n) worst case",
            "Search: O(log n) average, O(n) worst case",
            "Delete: O(log n) average, O(n) worst case",
          ],
          complexity: {
            time: "O(log n) average operations",
            space: "O(n)",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("linked list")) {
        setDataStructure("linkedlist")
        setConceptTitle("Linked List")
        setConceptDescription(
          "A linear data structure where each element points to the next element, allowing for efficient insertions and deletions.",
        )
        setMessage(
          "Linked List: A linear data structure where each element points to the next element, allowing for efficient insertions and deletions.",
        )
        setConceptProperties({
          operations: [
            "Insert at beginning: O(1)",
            "Insert at end: O(n) for singly linked, O(1) for doubly linked with tail pointer",
            "Delete: O(n) to find, O(1) to remove",
            "Search: O(n)",
          ],
          complexity: {
            time: "O(n) for most operations",
            space: "O(n)",
          },
        })
      } else if (
        selectedConcept.toLowerCase().includes("tree") ||
        selectedConcept.toLowerCase().includes("avl") ||
        selectedConcept.toLowerCase().includes("red-black")
      ) {
        setDataStructure("bst") // Using BST visualization as placeholder
        if (selectedConcept.toLowerCase().includes("avl")) {
          setConceptTitle("AVL Tree")
          setConceptDescription(
            "A self-balancing binary search tree where the heights of the two child subtrees differ by at most one.",
          )
          setMessage(
            "AVL Tree: A self-balancing binary search tree where the heights of the two child subtrees differ by at most one.",
          )
          setConceptProperties({
            operations: [
              "Insert: O(log n)",
              "Search: O(log n)",
              "Delete: O(log n)",
              "Balance Factor = height(left subtree) - height(right subtree)",
            ],
            complexity: {
              time: "O(log n) for all operations",
              space: "O(n)",
            },
          })
        } else if (selectedConcept.toLowerCase().includes("red-black")) {
          setConceptTitle("Red-Black Tree")
          setConceptDescription(
            "A self-balancing binary search tree with extra color information to ensure the tree remains balanced during insertions and deletions.",
          )
          setMessage(
            "Red-Black Tree: A self-balancing binary search tree with extra color information to ensure the tree remains balanced during insertions and deletions.",
          )
          setConceptProperties({
            operations: [
              "Insert: O(log n)",
              "Search: O(log n)",
              "Delete: O(log n)",
              "Properties: Root is black, No red node has a red child, All paths from root to leaves have same number of black nodes",
            ],
            complexity: {
              time: "O(log n) for all operations",
              space: "O(n)",
            },
          })
        } else {
          setConceptTitle("Binary Tree")
          setConceptDescription(
            "A tree data structure where each node has at most two children, referred to as the left and right child.",
          )
          setMessage(
            "Binary Tree: A tree data structure where each node has at most two children, referred to as the left and right child.",
          )
          setConceptProperties({
            operations: [
              "Insert: O(log n) to O(n) depending on tree structure",
              "Search: O(log n) to O(n) depending on tree structure",
              "Delete: O(log n) to O(n) depending on tree structure",
            ],
            complexity: {
              time: "O(log n) to O(n) depending on tree structure",
              space: "O(n)",
            },
          })
        }
      } else if (selectedConcept.toLowerCase().includes("array")) {
        setDataStructure("linkedlist") // Using linked list visualization as placeholder
        setConceptTitle("Array")
        setConceptDescription(
          "A collection of elements stored at contiguous memory locations, allowing for constant-time access to elements via their index.",
        )
        setMessage(
          "Array: A collection of elements stored at contiguous memory locations, allowing for constant-time access to elements via their index.",
        )
        setConceptProperties({
          operations: [
            "Access: O(1)",
            "Search: O(n) for unsorted, O(log n) for sorted with binary search",
            "Insert/Delete at end: O(1) amortized",
            "Insert/Delete at arbitrary position: O(n)",
          ],
          complexity: {
            time: "O(1) for access, O(n) for most other operations",
            space: "O(n)",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("stack")) {
        setDataStructure("linkedlist") // Using linked list visualization as placeholder
        setConceptTitle("Stack")
        setConceptDescription("A linear data structure that follows the Last In First Out (LIFO) principle.")
        setMessage("Stack: A linear data structure that follows the Last In First Out (LIFO) principle.")
        setConceptProperties({
          operations: [
            "Push: O(1)",
            "Pop: O(1)",
            "Peek: O(1)",
            "Applications: Function calls, Expression evaluation, Backtracking algorithms",
          ],
          complexity: {
            time: "O(1) for all operations",
            space: "O(n)",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("queue")) {
        setDataStructure("linkedlist") // Using linked list visualization as placeholder
        setConceptTitle("Queue")
        setConceptDescription("A linear data structure that follows the First In First Out (FIFO) principle.")
        setMessage("Queue: A linear data structure that follows the First In First Out (FIFO) principle.")
        setConceptProperties({
          operations: [
            "Enqueue: O(1)",
            "Dequeue: O(1)",
            "Front: O(1)",
            "Applications: BFS, Job scheduling, Print queue management",
          ],
          complexity: {
            time: "O(1) for all operations",
            space: "O(n)",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("hash")) {
        setDataStructure("linkedlist") // Using linked list visualization as placeholder
        setConceptTitle("Hash Table")
        setConceptDescription(
          "A data structure that implements an associative array abstract data type, a structure that can map keys to values.",
        )
        setMessage(
          "Hash Table: A data structure that implements an associative array abstract data type, a structure that can map keys to values.",
        )
        setConceptProperties({
          operations: [
            "Insert: O(1) average, O(n) worst case",
            "Search: O(1) average, O(n) worst case",
            "Delete: O(1) average, O(n) worst case",
            "Hash function: Converts keys into array indices",
          ],
          complexity: {
            time: "O(1) average, O(n) worst case",
            space: "O(n)",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("graph")) {
        setDataStructure("bst") // Using BST visualization as placeholder
        setConceptTitle("Graph")
        setConceptDescription("A non-linear data structure consisting of vertices and edges connecting these vertices.")
        setMessage("Graph: A non-linear data structure consisting of vertices and edges connecting these vertices.")
        setConceptProperties({
          operations: [
            "Add vertex: O(1)",
            "Add edge: O(1)",
            "Remove vertex: O(|V| + |E|)",
            "Remove edge: O(|E|)",
            "Representations: Adjacency Matrix, Adjacency List",
          ],
          complexity: {
            time: "Varies by operation and representation",
            space: "O(|V| + |E|) for adjacency list, O(|V|²) for adjacency matrix",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("heap")) {
        setDataStructure("bst") // Using BST visualization as placeholder
        setConceptTitle("Heap")
        setConceptDescription("A specialized tree-based data structure that satisfies the heap property.")
        setMessage("Heap: A specialized tree-based data structure that satisfies the heap property.")
        setConceptProperties({
          operations: [
            "Insert: O(log n)",
            "Extract min/max: O(log n)",
            "Find min/max: O(1)",
            "Heapify: O(n)",
            "Types: Min Heap (parent < children), Max Heap (parent > children)",
          ],
          complexity: {
            time: "O(log n) for most operations, O(1) for find min/max",
            space: "O(n)",
          },
        })
      } else if (selectedConcept.toLowerCase().includes("trie")) {
        setDataStructure("bst") // Using BST visualization as placeholder
        setConceptTitle("Trie")
        setConceptDescription(
          "A tree-like data structure used to store a dynamic set of strings, where the keys are usually strings.",
        )
        setMessage(
          "Trie: A tree-like data structure used to store a dynamic set of strings, where the keys are usually strings.",
        )
        setConceptProperties({
          operations: [
            "Insert: O(m) where m is key length",
            "Search: O(m) where m is key length",
            "Delete: O(m) where m is key length",
            "Applications: Autocomplete, Spell checking, IP routing",
          ],
          complexity: {
            time: "O(m) where m is key length",
            space: "O(ALPHABET_SIZE * m * n) where n is number of keys",
          },
        })
      } else {
        // Default case
        setDataStructure("bst")
        setConceptTitle("Data Structures Visualizer")
        setConceptDescription("Explore and interact with common data structures through visual representations")
        setMessage("Select a data structure to visualize its operations.")
        setConceptProperties({
          operations: [],
          complexity: {
            time: "",
            space: "",
          },
        })
      }

      // Reset the data structure to visualize with default values
      handleReset()
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Data Structures Visualizer`
    }
  }, [selectedConcept])

  // Initialize with some data
  useEffect(() => {
    // Binary Search Tree
    ;[50, 30, 70, 20, 40, 60, 80].forEach((value) => bst.insert(value))
    bst.calculatePositions()

    // Linked List
    ;[10, 20, 30, 40, 50].forEach((value) => linkedList.append(value))
    linkedList.calculatePositions()

    // Stack
    ;[10, 20, 30].forEach((value) => stack.push(value))

    // Queue
    ;[10, 20, 30].forEach((value) => queue.enqueue(value))

    // Set canvas size
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (dataStructure === "bst") {
      drawBinaryTree(ctx, bst)
    } else if (dataStructure === "linkedlist") {
      drawLinkedList(ctx, linkedList)
    }
  }, [dataStructure, highlightedNode, canvasSize])

  // Draw Binary Search Tree
  const drawBinaryTree = (ctx: CanvasRenderingContext2D, tree: BinarySearchTree) => {
    const drawNode = (node: TreeNode | null) => {
      if (node === null) return

      // Draw connections to children
      if (node.left) {
        ctx.beginPath()
        ctx.moveTo(node.x, node.y + 20)
        ctx.lineTo(node.left.x, node.left.y - 20)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      if (node.right) {
        ctx.beginPath()
        ctx.moveTo(node.x, node.y + 20)
        ctx.lineTo(node.right.x, node.right.y - 20)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw node
      ctx.beginPath()
      ctx.arc(node.x, node.y, 20, 0, Math.PI * 2)

      // Highlight node if it matches the search value
      if (node.value === highlightedNode) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node value
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.value.toString(), node.x, node.y)

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw children
      drawNode(node.left)
      drawNode(node.right)
    }

    drawNode(tree.root)
  }

  // Draw Linked List
  const drawLinkedList = (ctx: CanvasRenderingContext2D, list: LinkedList) => {
    let current = list.head

    while (current !== null) {
      // Draw arrow to next node
      if (current.next) {
        ctx.beginPath()
        ctx.moveTo(current.x + 30, current.y)
        ctx.lineTo(current.next.x - 30, current.next.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2

        // Draw arrowhead
        const angle = Math.atan2(current.next.y - current.y, current.next.x - current.x)
        ctx.lineTo(
          current.next.x - 30 - 10 * Math.cos(angle - Math.PI / 6),
          current.next.y - 10 * Math.sin(angle - Math.PI / 6),
        )
        ctx.moveTo(current.next.x - 30, current.next.y)
        ctx.lineTo(
          current.next.x - 30 - 10 * Math.cos(angle + Math.PI / 6),
          current.next.y - 10 * Math.sin(angle + Math.PI / 6),
        )

        ctx.stroke()
      }

      // Draw node
      ctx.beginPath()
      ctx.rect(current.x - 30, current.y - 20, 60, 40)

      // Highlight node if it matches the search value
      if (current.value === highlightedNode) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node value
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(current.value.toString(), current.x, current.y)

      // Reset shadow
      ctx.shadowBlur = 0

      current = current.next
    }
  }

  // Handle adding a node
  const handleAddNode = () => {
    const value = Number.parseInt(inputValue)

    if (isNaN(value)) {
      setMessage("Please enter a valid number")
      return
    }

    if (dataStructure === "bst") {
      bst.insert(value)
      bst.calculatePositions()
      setMessage(`Added node with value ${value} to Binary Search Tree`)
    } else if (dataStructure === "linkedlist") {
      linkedList.append(value)
      linkedList.calculatePositions()
      setMessage(`Added node with value ${value} to Linked List`)
    }

    setInputValue("")
    setHighlightedNode(value)

    // Animate highlight
    setIsAnimating(true)
    setTimeout(() => {
      setHighlightedNode(null)
      setIsAnimating(false)
    }, 1500)
  }

  // Handle searching for a node
  const handleSearchNode = () => {
    const value = Number.parseInt(searchValue)

    if (isNaN(value)) {
      setMessage("Please enter a valid number")
      return
    }

    if (dataStructure === "bst") {
      const node = bst.search(value)
      if (node) {
        setMessage(`Found node with value ${value}`)
        setHighlightedNode(value)
      } else {
        setMessage(`Node with value ${value} not found`)
      }
    } else if (dataStructure === "linkedlist") {
      let found = false
      let current = linkedList.head

      while (current !== null) {
        if (current.value === value) {
          found = true
          break
        }
        current = current.next
      }

      if (found) {
        setMessage(`Found node with value ${value}`)
        setHighlightedNode(value)
      } else {
        setMessage(`Node with value ${value} not found`)
      }
    }

    setSearchValue("")

    // Animate highlight
    setIsAnimating(true)
    setTimeout(() => {
      setHighlightedNode(null)
      setIsAnimating(false)
    }, 1500)
  }

  // Handle deleting a node
  const handleDeleteNode = () => {
    const value = Number.parseInt(inputValue)

    if (isNaN(value)) {
      setMessage("Please enter a valid number")
      return
    }

    if (dataStructure === "bst") {
      bst.delete(value)
      bst.calculatePositions()
      setMessage(`Deleted node with value ${value} from Binary Search Tree`)
    } else if (dataStructure === "linkedlist") {
      linkedList.delete(value)
      linkedList.calculatePositions()
      setMessage(`Deleted node with value ${value} from Linked List`)
    }

    setInputValue("")
  }

  // Reset the data structure
  const handleReset = () => {
    if (dataStructure === "bst") {
      // Reset BST
      bst.root = null
      ;[50, 30, 70, 20, 40, 60, 80].forEach((value) => bst.insert(value))
      bst.calculatePositions()
      setMessage("Reset Binary Search Tree to default")
    } else if (dataStructure === "linkedlist") {
      // Reset Linked List
      linkedList.head = null
      ;[10, 20, 30, 40, 50].forEach((value) => linkedList.append(value))
      linkedList.calculatePositions()
      setMessage("Reset Linked List to default")
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleReset}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                {message && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                  >
                    {message}
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Select Data Structure</h3>
                    <Tabs defaultValue="bst" value={dataStructure} onValueChange={setDataStructure} className="w-full">
                      <TabsList className="grid w-full grid-cols-2 bg-gray-800/50">
                        <TabsTrigger value="bst">Binary Search Tree</TabsTrigger>
                        <TabsTrigger value="linkedlist">Linked List</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Operations</h3>
                    <div className="space-y-4">
                      <div className="flex space-x-2">
                        <Input
                          type="number"
                          placeholder="Enter a value"
                          value={inputValue}
                          onChange={(e) => setInputValue(e.target.value)}
                          className="bg-gray-800/50 border-gray-700 text-white"
                        />
                      </div>

                      <div className="flex space-x-2">
                        <Button onClick={handleAddNode} className="flex-1 bg-cyan-600 hover:bg-cyan-700 text-white">
                          <Plus className="h-4 w-4 mr-2" />
                          Add
                        </Button>
                        <Button
                          onClick={handleDeleteNode}
                          className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                        >
                          <Minus className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>

                      <div className="pt-2 border-t border-gray-800">
                        <h3 className="text-sm font-medium text-gray-400 mb-3">Search</h3>
                        <div className="flex space-x-2">
                          <Input
                            type="number"
                            placeholder="Search value"
                            value={searchValue}
                            onChange={(e) => setSearchValue(e.target.value)}
                            className="bg-gray-800/50 border-gray-700 text-white"
                          />
                          <Button onClick={handleSearchNode} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                            Search
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {conceptProperties.operations.length > 0 && (
                    <div className="pt-4 border-t border-gray-800">
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Key Properties</h3>
                      <div className="space-y-2 text-sm text-gray-300">
                        <ul className="list-disc pl-5 space-y-1">
                          {conceptProperties.operations.map((op, index) => (
                            <li key={index}>{op}</li>
                          ))}
                        </ul>
                        {conceptProperties.complexity.time && (
                          <div className="mt-2">
                            <p className="text-cyan-400 font-mono">
                              Time Complexity: {conceptProperties.complexity.time}
                            </p>
                            <p className="text-cyan-400 font-mono">
                              Space Complexity: {conceptProperties.complexity.space}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <ConceptList category="data-structures" title="Data Structure" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

