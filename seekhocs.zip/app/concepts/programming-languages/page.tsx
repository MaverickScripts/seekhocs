"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getConceptsByCategory } from "@/lib/concepts"
import ConceptList from "@/components/concept-list"
import { Code, Terminal, Cpu } from "lucide-react"

// Code examples for different languages
const codeExamples = {
  "Variables and Data Types": {
    cpp: `// C++ Variables and Data Types
#include <iostream>
#include <string>
using namespace std;

int main() {
  // Integer types
  int num = 42;
  long bigNum = 1234567890L;
  
  // Floating point types
  float decimal = 3.14f;
  double precise = 3.141592653589793;
  
  // Character and string
  char letter = 'A';
  string text = "Hello, World!";
  
  // Boolean
  bool isTrue = true;
  
  cout << "Integer: " << num << endl;
  cout << "String: " << text << endl;
  
  return 0;
}`,
    javascript: `// JavaScript Variables and Data Types
// Number type (both integers and floats)
const num = 42;
const decimal = 3.14;

// String type
const text = "Hello, World!";

// Boolean type
const isTrue = true;

// Undefined and null
let undefinedVar;
const nullVar = null;

// Symbol (unique identifier)
const uniqueId = Symbol('id');

// Object types
const person = { name: "John", age: 30 };
const numbers = [1, 2, 3, 4, 5];

// BigInt for large integers
const bigNumber = 9007199254740991n;

console.log("Number:", num);
console.log("String:", text);
console.log("Object:", person);`,
    python: `# Python Variables and Data Types
# Integer and float
num = 42
decimal = 3.14

# String
text = "Hello, World!"

# Boolean
is_true = True

# None type (similar to null)
empty = None

# List (mutable sequence)
numbers = [1, 2, 3, 4, 5]

# Tuple (immutable sequence)
coordinates = (10, 20)

# Dictionary (key-value pairs)
person = {"name": "John", "age": 30}

# Set (unordered collection of unique items)
unique_numbers = {1, 2, 3, 4, 5}

print(f"Integer: {num}")
print(f"String: {text}")
print(f"Dictionary: {person}")
print(f"List: {numbers}")`,
  },
  "Control Structures": {
    cpp: `// C++ Control Structures
#include <iostream>
#include <vector>
using namespace std;

int main() {
  // If-else statement
  int x = 10;
  if (x > 5) {
    cout << "x is greater than 5" << endl;
  } else if (x == 5) {
    cout << "x is equal to 5" << endl;
  } else {
    cout << "x is less than 5" << endl;
  }
  
  // Switch statement
  int day = 3;
  switch (day) {
    case 1: cout << "Monday"; break;
    case 2: cout << "Tuesday"; break;
    case 3: cout << "Wednesday"; break;
    default: cout << "Other day"; break;
  }
  cout << endl;
  
  // For loop
  for (int i = 0; i < 5; i++) {
    cout << i << " ";
  }
  cout << endl;
  
  // While loop
  int j = 0;
  while (j < 5) {
    cout << j << " ";
    j++;
  }
  cout << endl;
  
  // Do-while loop
  int k = 0;
  do {
    cout << k << " ";
    k++;
  } while (k < 5);
  cout << endl;
  
  // Range-based for loop
  vector<int> nums = {1, 2, 3, 4, 5};
  for (const auto& num : nums) {
    cout << num << " ";
  }
  cout << endl;
  
  return 0;
}`,
    javascript: `// JavaScript Control Structures
// If-else statement
const x = 10;
if (x > 5) {
  console.log("x is greater than 5");
} else if (x === 5) {
  console.log("x is equal to 5");
} else {
  console.log("x is less than 5");
}

// Switch statement
const day = 3;
switch (day) {
  case 1: console.log("Monday"); break;
  case 2: console.log("Tuesday"); break;
  case 3: console.log("Wednesday"); break;
  default: console.log("Other day"); break;
}

// For loop
for (let i = 0; i < 5; i++) {
  console.log(i);
}

// While loop
let j = 0;
while (j < 5) {
  console.log(j);
  j++;
}

// Do-while loop
let k = 0;
do {
  console.log(k);
  k++;
} while (k < 5);

// For...of loop (for iterables)
const nums = [1, 2, 3, 4, 5];
for (const num of nums) {
  console.log(num);
}

// For...in loop (for object properties)
const person = { name: "John", age: 30 };
for (const key in person) {
  console.log(key + ": " + person[key]);
}

// Ternary operator
const age = 20;
const status = age >= 18 ? "adult" : "minor";
console.log(status);`,
    python: `# Python Control Structures
# If-else statement
x = 10
if x > 5:
    print("x is greater than 5")
elif x == 5:
    print("x is equal to 5")
else:
    print("x is less than 5")

# Python doesn't have switch, but we can use dictionary mapping
day = 3
day_names = {
    1: "Monday",
    2: "Tuesday",
    3: "Wednesday"
}
print(day_names.get(day, "Other day"))

# For loop
for i in range(5):
    print(i, end=" ")
print()

# While loop
j = 0
while j < 5:
    print(j, end=" ")
    j += 1
print()

# For loop with list
nums = [1, 2, 3, 4, 5]
for num in nums:
    print(num, end=" ")
print()

# List comprehension
squares = [x**2 for x in range(5)]
print(squares)

# Dictionary comprehension
names = ["Alice", "Bob", "Charlie"]
name_lengths = {name: len(name) for name in names}
print(name_lengths)

# Conditional expression (ternary operator)
age = 20
status = "adult" if age >= 18 else "minor"
print(status)`,
  },
  "Functions and Methods": {
    cpp: `// C++ Functions and Methods
#include <iostream>
#include <string>
using namespace std;

// Basic function
int add(int a, int b) {
  return a + b;
}

// Function with default parameters
void greet(string name = "Guest") {
  cout << "Hello, " << name << "!" << endl;
}

// Function overloading
void display(int x) {
  cout << "Integer: " << x << endl;
}

void display(double x) {
  cout << "Double: " << x << endl;
}

void display(string x) {
  cout << "String: " << x << endl;
}

// Pass by reference
void increment(int& x) {
  x++;
}

// Class with methods
class Calculator {
private:
  int value;

public:
  Calculator(int val = 0) : value(val) {}
  
  int getValue() const {
    return value;
  }
  
  void add(int x) {
    value += x;
  }
  
  void subtract(int x) {
    value -= x;
  }
};

int main() {
  // Function calls
  cout << "Sum: " << add(5, 3) << endl;
  
  greet();
  greet("John");
  
  display(10);
  display(3.14);
  display("Hello");
  
  int num = 5;
  increment(num);
  cout << "After increment: " << num << endl;
  
  // Using class methods
  Calculator calc(10);
  calc.add(5);
  calc.subtract(3);
  cout << "Calculator value: " << calc.getValue() << endl;
  
  return 0;
}`,
    javascript: `// JavaScript Functions and Methods
// Function declaration
function add(a, b) {
  return a + b;
}

// Function expression
const subtract = function(a, b) {
  return a - b;
};

// Arrow function
const multiply = (a, b) => a * b;

// Default parameters
function greet(name = "Guest") {
  console.log(\`Hello, \${name}!\`);
}

// Rest parameters
function sum(...numbers) {
  return numbers.reduce((total, num) => total + num, 0);
}

// Callback function
function processData(data, callback) {
  // Process data
  const result = data.toUpperCase();
  // Call the callback with the result
  callback(result);
}

// Object methods
const calculator = {
  value: 0,
  
  add(x) {
    this.value += x;
    return this;
  },
  
  subtract(x) {
    this.value -= x;
    return this;
  },
  
  getValue() {
    return this.value;
  }
};

// Function calls
console.log("Sum:", add(5, 3));
console.log("Difference:", subtract(10, 4));
console.log("Product:", multiply(6, 7));

greet();
greet("John");

console.log("Sum of numbers:", sum(1, 2, 3, 4, 5));

processData("hello", result => {
  console.log("Processed data:", result);
});

// Method chaining
calculator.add(10).add(5).subtract(3);
console.log("Calculator value:", calculator.getValue());`,
    python: `# Python Functions and Methods
# Basic function
def add(a, b):
    return a + b

# Function with default parameters
def greet(name="Guest"):
    print(f"Hello, {name}!")

# Function with type hints (Python 3.5+)
def multiply(a: int, b: int) -> int:
    return a * b

# *args for variable positional arguments
def sum_all(*args):
    return sum(args)

# **kwargs for variable keyword arguments
def display_info(**kwargs):
    for key, value in kwargs.items():
        print(f"{key}: {value}")

# Lambda function (anonymous function)
square = lambda x: x ** 2

# Decorator function
def timer(func):
    def wrapper(*args, **kwargs):
        import time
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"Function {func.__name__} took {end - start:.6f} seconds")
        return result
    return wrapper

@timer
def slow_function():
    import time
    time.sleep(1)
    return "Done!"

# Class with methods
class Calculator:
    def __init__(self, value=0):
        self.value = value
    
    def add(self, x):
        self.value += x
        return self
    
    def subtract(self, x):
        self.value -= x
        return self
    
    def get_value(self):
        return self.value

# Function calls
print("Sum:", add(5, 3))
greet()
greet("John")
print("Product:", multiply(6, 7))
print("Sum of numbers:", sum_all(1, 2, 3, 4, 5))

display_info(name="John", age=30, city="New York")
print("Square of 8:", square(8))

result = slow_function()
print(result)

# Method chaining
calc = Calculator(10)
calc.add(5).subtract(3)
print("Calculator value:", calc.get_value())`,
  },
  "Object-Oriented Programming": {
    cpp: `// C++ Object-Oriented Programming
#include <iostream>
#include <string>
using namespace std;

// Base class
class Animal {
protected:
  string name;
  
public:
  // Constructor
  Animal(const string& animalName) : name(animalName) {}
  
  // Virtual method for polymorphism
  virtual void makeSound() const {
    cout << "Some animal sound" << endl;
  }
  
  // Getter
  string getName() const {
    return name;
  }
  
  // Virtual destructor
  virtual ~Animal() {
    cout << "Animal " << name << " destroyed" << endl;
  }
};

// Derived class
class Dog : public Animal {
private:
  string breed;
  
public:
  // Constructor with base class initialization
  Dog(const string& dogName, const string& dogBreed) 
    : Animal(dogName), breed(dogBreed) {}
  
  // Override base class method
  void makeSound() const override {
    cout << "Woof! Woof!" << endl;
  }
  
  // Additional method
  void fetch() const {
    cout << name << " is fetching the ball!" << endl;
  }
  
  // Getter
  string getBreed() const {
    return breed;
  }
};

// Another derived class
class Cat : public Animal {
public:
  Cat(const string& catName) : Animal(catName) {}
  
  void makeSound() const override {
    cout << "Meow!" << endl;
  }
  
  void purr() const {
    cout << name << " is purring..." << endl;
  }
};

int main() {
  // Create objects
  Dog dog("Buddy", "Golden Retriever");
  Cat cat("Whiskers");
  
  // Access methods
  cout << "Dog: " << dog.getName() << ", Breed: " << dog.getBreed() << endl;
  cout << "Cat: " << cat.getName() << endl;
  
  // Polymorphism
  Animal* animals[2] = { &dog, &cat };
  for (int i = 0; i < 2; i++) {
    cout << animals[i]->getName() << " says: ";
    animals[i]->makeSound();
  }
  
  // Specific methods
  dog.fetch();
  cat.purr();
  
  return 0;
}`,
    javascript: `// JavaScript Object-Oriented Programming
// ES6 Class syntax
class Animal {
  constructor(animalName) {
    this.name = animalName;
  }
  
  makeSound() {
    console.log("Some animal sound");
  }
  
  getName() {
    return this.name;
  }
}

// Inheritance
class Dog extends Animal {
  constructor(dogName, dogBreed) {
    super(dogName); // Call parent constructor
    this.breed = dogBreed;
  }
  
  // Override parent method
  makeSound() {
    console.log("Woof! Woof!");
  }
  
  // Additional method
  fetch() {
    console.log(\`\${this.name} is fetching the ball!\`);
  }
  
  getBreed() {
    return this.breed;
  }
}

// Another derived class
class Cat extends Animal {
  constructor(catName) {
    super(catName);
  }
  
  makeSound() {
    console.log("Meow!");
  }
  
  purr() {
    console.log(\`\${this.name} is purring...\`);
  }
}

// Prototype-based OOP (pre-ES6 style)
function Person(personName, personAge) {
  this.name = personName;
  this.age = personAge;
}

Person.prototype.greet = function() {
  console.log(\`Hello, my name is \${this.name} and I'm \${this.age} years old.\`);
};

// Create objects
const dog = new Dog("Buddy", "Golden Retriever");
const cat = new Cat("Whiskers");
const person = new Person("John", 30);

// Access methods
console.log("Dog:", dog.getName(), "Breed:", dog.getBreed());
console.log("Cat:", cat.getName());

// Polymorphism
const animals = [dog, cat];
animals.forEach(animal => {
  console.log(\`\${animal.getName()} says:\`);
  animal.makeSound();
});

// Specific methods
dog.fetch();
cat.purr();
person.greet();`,
    python: `# Python Object-Oriented Programming
# Base class
class Animal:
    def __init__(self, animal_name):
        self.name = animal_name
    
    def make_sound(self):
        print("Some animal sound")
    
    def get_name(self):
        return self.name

# Derived class
class Dog(Animal):
    def __init__(self, dog_name, dog_breed):
        # Call parent constructor
        super().__init__(dog_name)
        self.breed = dog_breed
    
    # Override parent method
    def make_sound(self):
        print("Woof! Woof!")
    
    # Additional method
    def fetch(self):
        print(f"{self.name} is fetching the ball!")
    
    def get_breed(self):
        return self.breed

# Another derived class
class Cat(Animal):
    def __init__(self, cat_name):
        super().__init__(cat_name)
    
    def make_sound(self):
        print("Meow!")
    
    def purr(self):
        print(f"{self.name} is purring...")

# Multiple inheritance (Python-specific feature)
class Bird:
    def fly(self):
        print("Flying high!")

class Parrot(Animal, Bird):
    def __init__(self, parrot_name, parrot_color):
        Animal.__init__(self, parrot_name)
        self.color = parrot_color
    
    def make_sound(self):
        print("Squawk!")
    
    def talk(self, message):
        print(f"{self.name} says: {message}")

# Create objects
dog = Dog("Buddy", "Golden Retriever")
cat = Cat("Whiskers")
parrot = Parrot("Polly", "Green")

# Access methods
print(f"Dog: {dog.get_name()}, Breed: {dog.get_breed()}")
print(f"Cat: {cat.get_name()}")
print(f"Parrot: {parrot.get_name()}, Color: {parrot.color}")

# Polymorphism
animals = [dog, cat, parrot]
for animal in animals:
    print(f"{animal.get_name()} says:", end=" ")
    animal.make_sound()

# Specific methods
dog.fetch()
cat.purr()
parrot.fly()
parrot.talk("Hello, world!")`,
  },
  "Error Handling": {
    cpp: `// C++ Error Handling
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

// Function that may throw an exception
double divide(double a, double b) {
  if (b == 0) {
    throw runtime_error("Division by zero!");
  }
  return a / b;
}

// Custom exception class
class NegativeValueException : public exception {
private:
  string message;
  
public:
  NegativeValueException(const string& msg) : message(msg) {}
  
  const char* what() const noexcept override {
    return message.c_str();
  }
};

// Function with custom exception
double squareRoot(double x) {
  if (x < 0) {
    throw NegativeValueException("Cannot calculate square root of a negative number");
  }
  return sqrt(x);
}

int main() {
  // Basic try-catch
  try {
    double result = divide(10, 0);
    cout << "Result: " << result << endl;
  } catch (const runtime_error& e) {
    cerr << "Error: " << e.what() << endl;
  }
  
  // Multiple catch blocks
  try {
    double num = -4;
    double result = squareRoot(num);
    cout << "Square root: " << result << endl;
  } catch (const NegativeValueException& e) {
    cerr << "Custom error: " << e.what() << endl;
  } catch (const exception& e) {
    cerr << "Standard exception: " << e.what() << endl;
  } catch (...) {
    cerr << "Unknown exception occurred" << endl;
  }
  
  // Finally equivalent using RAII
  {
    cout << "Resource acquisition" << endl;
    try {
      cout << "Try block executed" << endl;
      throw runtime_error("Test exception");
    } catch (const exception& e) {
      cerr << "Caught: " << e.what() << endl;
    }
    cout << "Resource cleanup (like finally)" << endl;
  }
  
  return 0;
}`,
    javascript: `// JavaScript Error Handling
// Basic try-catch
try {
  const result = 10 / 0; // In JS, this is Infinity, not an error
  console.log("Result:", result);
  
  // Force an error
  throw new Error("This is a forced error");
} catch (error) {
  console.error("Error caught:", error.message);
} finally {
  console.log("This always executes");
}

// Custom error class
class NegativeValueError extends Error {
  constructor(message) {
    super(message);
    this.name = "NegativeValueError";
  }
}

// Function with custom error
function squareRoot(x) {
  if (x < 0) {
    throw new NegativeValueError("Cannot calculate square root of a negative number");
  }
  return Math.sqrt(x);
}

// Using the custom error
try {
  const num = -4;
  const result = squareRoot(num);
  console.log("Square root:", result);
} catch (error) {
  if (error instanceof NegativeValueError) {
    console.error("Custom error:", error.message);
  } else {
    console.error("Unexpected error:", error.message);
  }
}

// Async error handling with Promises
function fetchData() {
  return new Promise((resolve, reject) => {
    // Simulate an API call
    setTimeout(() => {
      const success = false;
      if (success) {
        resolve({ data: "Success!" });
      } else {
        reject(new Error("Failed to fetch data"));
      }
    }, 1000);
  });
}

// Using Promise catch
fetchData()
  .then(result => {
    console.log("Data:", result.data);
  })
  .catch(error => {
    console.error("Promise error:", error.message);
  });

// Using async/await with try-catch
async function getData() {
  try {
    const result = await fetchData();
    console.log("Async data:", result.data);
  } catch (error) {
    console.error("Async error:", error.message);
  }
}

getData();`,
    python: `# Python Error Handling
# Basic try-except
try:
    result = 10 / 0  # This will raise a ZeroDivisionError
    print("Result:", result)
except ZeroDivisionError as e:
    print(f"Error caught: {e}")
finally:
    print("This always executes")

# Multiple except blocks
try:
    # Open a file that doesn't exist
    with open("nonexistent_file.txt", "r") as file:
        content = file.read()
except FileNotFoundError as e:
    print(f"File error: {e}")
except IOError as e:
    print(f"IO error: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")

# Custom exception class
class NegativeValueError(Exception):
    """Exception raised when a negative value is provided where it's not allowed."""
    pass

# Function with custom exception
def square_root(x):
    if x < 0:
        raise NegativeValueError("Cannot calculate square root of a negative number")
    import math
    return math.sqrt(x)

# Using the custom exception
try:
    num = -4
    result = square_root(num)
    print("Square root:", result)
except NegativeValueError as e:
    print(f"Custom error: {e}")

# Context manager for resource handling
class Resource:
    def __init__(self, resource_name):
        self.name = resource_name
        print(f"Resource {resource_name} acquired")
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print(f"Resource {self.name} released")
        # Return True to suppress exceptions
        return False

# Using the context manager
try:
    with Resource("database") as resource:
        print("Working with resource")
        # Uncomment to see exception handling
        # raise ValueError("Test exception")
except ValueError as e:
    print(f"Error while using resource: {e}")

# Exception chaining
try:
    try:
        raise ValueError("Original error")
    except ValueError as e:
        raise RuntimeError("A new error occurred") from e
except RuntimeError as e:
    print(f"Error: {e}")
    print(f"Caused by: {e.__cause__}")`,
  },
}

// Visualization components for different concepts
const VariablesVisualization = () => {
  const [language, setLanguage] = useState<"cpp" | "javascript" | "python">("javascript")
  const [step, setStep] = useState(0)

  // Simplified memory visualization for variables
  const memoryVisualization = {
    cpp: [
      { address: "0x1000", name: "num", type: "int", value: "42", size: "4 bytes" },
      { address: "0x1004", name: "bigNum", type: "long", value: "1234567890", size: "8 bytes" },
      { address: "0x100C", name: "decimal", type: "float", value: "3.14", size: "4 bytes" },
      { address: "0x1010", name: "precise", type: "double", value: "3.14159", size: "8 bytes" },
      { address: "0x1018", name: "letter", type: "char", value: "'A'", size: "1 byte" },
      { address: "0x1020", name: "text", type: "string", value: '"Hello, World!"', size: "14 bytes + overhead" },
      { address: "0x1030", name: "isTrue", type: "bool", value: "true", size: "1 byte" },
    ],
    javascript: [
      { name: "num", type: "Number", value: "42", reference: false },
      { name: "decimal", type: "Number", value: "3.14", reference: false },
      { name: "text", type: "String", value: '"Hello, World!"', reference: true },
      { name: "isTrue", type: "Boolean", value: "true", reference: false },
      { name: "undefinedVar", type: "undefined", value: "undefined", reference: false },
      { name: "nullVar", type: "null", value: "null", reference: false },
      { name: "uniqueId", type: "Symbol", value: "Symbol('id')", reference: true },
      { name: "person", type: "Object", value: '{name: "John", age: 30}', reference: true },
      { name: "numbers", type: "Array", value: "[1, 2, 3, 4, 5]", reference: true },
    ],
    python: [
      { id: "1", name: "num", type: "int", value: "42", reference_count: 1 },
      { id: "2", name: "decimal", type: "float", value: "3.14", reference_count: 1 },
      { id: "3", name: "text", type: "str", value: '"Hello, World!"', reference_count: 1 },
      { id: "4", name: "is_true", type: "bool", value: "True", reference_count: 1 },
      { id: "5", name: "empty", type: "NoneType", value: "None", reference_count: 1 },
      { id: "6", name: "numbers", type: "list", value: "[1, 2, 3, 4, 5]", reference_count: 1 },
      { id: "7", name: "coordinates", type: "tuple", value: "(10, 20)", reference_count: 1 },
      { id: "8", name: "person", type: "dict", value: '{"name": "John", "age": 30}', reference_count: 1 },
    ],
  }

  return (
    <div className="p-4 bg-black rounded-lg border border-gray-800">
      <div className="mb-4">
        <h3 className="text-xl font-semibold mb-2">Memory Model Visualization</h3>
        <p className="text-gray-400 mb-4">See how variables are stored in memory across different languages</p>
        <div className="flex space-x-4 mb-4">
          <button
            className={`px-4 py-2 rounded ${language === "cpp" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setLanguage("cpp")}
          >
            C++
          </button>
          <button
            className={`px-4 py-2 rounded ${language === "javascript" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setLanguage("javascript")}
          >
            JavaScript
          </button>
          <button
            className={`px-4 py-2 rounded ${language === "python" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setLanguage("python")}
          >
            Python
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-900">
              {language === "cpp" && (
                <>
                  <th className="p-2 text-left">Memory Address</th>
                  <th className="p-2 text-left">Name</th>
                  <th className="p-2 text-left">Type</th>
                  <th className="p-2 text-left">Value</th>
                  <th className="p-2 text-left">Size</th>
                </>
              )}
              {language === "javascript" && (
                <>
                  <th className="p-2 text-left">Name</th>
                  <th className="p-2 text-left">Type</th>
                  <th className="p-2 text-left">Value</th>
                  <th className="p-2 text-left">Storage</th>
                </>
              )}
              {language === "python" && (
                <>
                  <th className="p-2 text-left">Object ID</th>
                  <th className="p-2 text-left">Name</th>
                  <th className="p-2 text-left">Type</th>
                  <th className="p-2 text-left">Value</th>
                  <th className="p-2 text-left">Ref Count</th>
                </>
              )}
            </tr>
          </thead>
          <tbody>
            {language === "cpp" &&
              memoryVisualization.cpp.map((item, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-gray-800" : "bg-gray-900"}>
                  <td className="p-2 font-mono">{item.address}</td>
                  <td className="p-2">{item.name}</td>
                  <td className="p-2 text-blue-400">{item.type}</td>
                  <td className="p-2 text-green-400">{item.value}</td>
                  <td className="p-2 text-gray-400">{item.size}</td>
                </tr>
              ))}
            {language === "javascript" &&
              memoryVisualization.javascript.map((item, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-gray-800" : "bg-gray-900"}>
                  <td className="p-2">{item.name}</td>
                  <td className="p-2 text-blue-400">{item.type}</td>
                  <td className="p-2 text-green-400">{item.value}</td>
                  <td className="p-2">{item.reference ? "Heap (Reference)" : "Stack (Primitive)"}</td>
                </tr>
              ))}
            {language === "python" &&
              memoryVisualization.python.map((item, index) => (
                <tr key={index} className={index % 2 === 0 ? "bg-gray-800" : "bg-gray-900"}>
                  <td className="p-2 font-mono">id-{item.id}</td>
                  <td className="p-2">{item.name}</td>
                  <td className="p-2 text-blue-400">{item.type}</td>
                  <td className="p-2 text-green-400">{item.value}</td>
                  <td className="p-2 text-gray-400">{item.reference_count}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 text-sm text-gray-400">
        {language === "cpp" && (
          <p>
            C++ uses static typing with explicit memory management. Variables are stored at specific memory addresses
            with fixed sizes based on their type.
          </p>
        )}
        {language === "javascript" && (
          <p>
            JavaScript uses dynamic typing. Primitive values are stored on the stack, while objects and arrays are
            stored on the heap with references.
          </p>
        )}
        {language === "python" && (
          <p>
            Python treats everything as an object. Each object has a unique ID, a type, and a reference count that
            tracks how many variables point to it.
          </p>
        )}
      </div>
    </div>
  )
}

const ControlFlowVisualization = () => {
  const [language, setLanguage] = useState<"cpp" | "javascript" | "python">("javascript")
  const [flowType, setFlowType] = useState<"conditional" | "loop">("conditional")

  return (
    <div className="p-4 bg-black rounded-lg border border-gray-800">
      <div className="mb-4">
        <h3 className="text-xl font-semibold mb-2">Control Flow Visualization</h3>
        <p className="text-gray-400 mb-4">See how control structures direct program execution</p>
        <div className="flex space-x-4 mb-4">
          <button
            className={`px-4 py-2 rounded ${language === "cpp" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setLanguage("cpp")}
          >
            C++
          </button>
          <button
            className={`px-4 py-2 rounded ${language === "javascript" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setLanguage("javascript")}
          >
            JavaScript
          </button>
          <button
            className={`px-4 py-2 rounded ${language === "python" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setLanguage("python")}
          >
            Python
          </button>
        </div>
        <div className="flex space-x-4 mb-4">
          <button
            className={`px-4 py-2 rounded ${flowType === "conditional" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setFlowType("conditional")}
          >
            Conditionals
          </button>
          <button
            className={`px-4 py-2 rounded ${flowType === "loop" ? "bg-blue-600" : "bg-gray-800"}`}
            onClick={() => setFlowType("loop")}
          >
            Loops
          </button>
        </div>
      </div>

      <div className="bg-gray-900 p-4 rounded-lg">
        {flowType === "conditional" && (
          <div className="flex flex-col items-center">
            <div className="w-full max-w-md">
              <div className="bg-blue-900/30 p-4 rounded-lg mb-4">
                <div className="font-mono text-sm mb-2">x = 10</div>
                <div className="font-bold mb-2">if (x &gt; 5)</div>
                <div className="border-l-2 border-blue-500 pl-4 mb-2">
                  <div className="bg-blue-500/20 p-2 rounded">Print "x is greater than 5"</div>
                </div>
                <div className="font-bold mb-2">else if (x == 5)</div>
                <div className="border-l-2 border-gray-500 pl-4 mb-2">
                  <div className="p-2 rounded">Print "x is equal to 5"</div>
                </div>
                <div className="font-bold mb-2">else</div>
                <div className="border-l-2 border-gray-500 pl-4">
                  <div className="p-2 rounded">Print "x is less than 5"</div>
                </div>
              </div>

              <div className="text-center text-gray-400 mb-4">Execution Flow</div>

              <div className="flex justify-center">
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">1</div>
                  <div className="text-sm">
                    Evaluate
                    <br />x &gt; 5
                  </div>
                </div>
                <div className="w-8 mx-2 border-t-2 border-blue-500 self-start mt-4"></div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">2</div>
                  <div className="text-sm">
                    True
                    <br />
                    Execute
                  </div>
                </div>
                <div className="w-8 mx-2 border-t-2 border-blue-500 self-start mt-4"></div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">3</div>
                  <div className="text-sm">
                    Skip
                    <br />
                    else blocks
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {flowType === "loop" && (
          <div className="flex flex-col items-center">
            <div className="w-full max-w-md">
              <div className="bg-blue-900/30 p-4 rounded-lg mb-4">
                <div className="font-bold mb-2">for (int i = 0; i &lt; 5; i++)</div>
                <div className="border-l-2 border-blue-500 pl-4">
                  <div className="bg-blue-500/20 p-2 rounded">Print i</div>
                </div>
              </div>

              <div className="text-center text-gray-400 mb-4">Execution Flow</div>

              <div className="flex flex-wrap justify-center gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">1</div>
                  <div className="text-sm">
                    Initialize
                    <br />i = 0
                  </div>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">2</div>
                  <div className="text-sm">
                    Check
                    <br />i &lt; 5
                  </div>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">3</div>
                  <div className="text-sm">
                    Execute
                    <br />
                    body
                  </div>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mb-2">4</div>
                  <div className="text-sm">
                    Increment
                    <br />
                    i++
                  </div>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center mb-2">5</div>
                  <div className="text-sm">
                    Repeat
                    <br />
                    steps 2-4
                  </div>
                </div>
              </div>

              <div className="mt-4 bg-gray-800 p-2 rounded-lg">
                <div className="font-mono text-sm">Output: 0 1 2 3 4</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default function ProgrammingLanguagesPage() {
  const [selectedConcept, setSelectedConcept] = useState("Variables and Data Types")
  const [selectedLanguage, setSelectedLanguage] = useState<"cpp" | "javascript" | "python">("javascript")

  const concepts = getConceptsByCategory("programming-languages")

  return (
    <div className="container mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Programming Languages</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Compare C++, JavaScript, and Python with interactive examples and visualizations
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card
          className={`cursor-pointer transition-all ${selectedLanguage === "cpp" ? "border-blue-600 bg-blue-950/20" : "bg-black border-gray-800"}`}
          onClick={() => setSelectedLanguage("cpp")}
        >
          <CardHeader className="flex flex-row items-center gap-2 p-4">
            <Code className="h-5 w-5" />
            <CardTitle>C++</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <CardDescription>Statically-typed, compiled language with manual memory management</CardDescription>
          </CardContent>
        </Card>

        <Card
          className={`cursor-pointer transition-all ${selectedLanguage === "javascript" ? "border-blue-600 bg-blue-950/20" : "bg-black border-gray-800"}`}
          onClick={() => setSelectedLanguage("javascript")}
        >
          <CardHeader className="flex flex-row items-center gap-2 p-4">
            <Terminal className="h-5 w-5" />
            <CardTitle>JavaScript</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <CardDescription>Dynamically-typed, interpreted language with automatic memory management</CardDescription>
          </CardContent>
        </Card>

        <Card
          className={`cursor-pointer transition-all ${selectedLanguage === "python" ? "border-blue-600 bg-blue-950/20" : "bg-black border-gray-800"}`}
          onClick={() => setSelectedLanguage("python")}
        >
          <CardHeader className="flex flex-row items-center gap-2 p-4">
            <Cpu className="h-5 w-5" />
            <CardTitle>Python</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <CardDescription>
              Dynamically-typed, interpreted language with automatic memory management and high-level abstractions
            </CardDescription>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <ConceptList concepts={concepts} selectedConcept={selectedConcept} onSelectConcept={setSelectedConcept} />
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="code" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="code">Code Examples</TabsTrigger>
              <TabsTrigger value="theory">Theory</TabsTrigger>
              <TabsTrigger value="visualization">Visualization</TabsTrigger>
            </TabsList>

            <TabsContent value="code" className="mt-0">
              <Card className="bg-black border-gray-800">
                <CardHeader>
                  <CardTitle>
                    {selectedConcept} in{" "}
                    {selectedLanguage === "cpp" ? "C++" : selectedLanguage === "javascript" ? "JavaScript" : "Python"}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="bg-gray-900 p-4 rounded-lg overflow-x-auto">
                    <code className="text-sm font-mono text-white">
                      {codeExamples[selectedConcept as keyof typeof codeExamples]?.[selectedLanguage] ||
                        "Code example not available for this concept."}
                    </code>
                  </pre>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="theory" className="mt-0">
              <Card className="bg-black border-gray-800">
                <CardHeader>
                  <CardTitle>{selectedConcept} - Theoretical Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedConcept === "Variables and Data Types" && (
                    <div className="space-y-4">
                      <p>
                        Variables are named storage locations that hold data. Data types define the kind of data a
                        variable can store and how it's represented in memory.
                      </p>

                      <h3 className="text-xl font-semibold mt-4">Comparison across languages:</h3>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                        <div className="bg-gray-900 p-4 rounded-lg">
                          <h4 className="font-bold mb-2">C++</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            <li>Statically typed (types checked at compile time)</li>
                            <li>Explicit type declarations required</li>
                            <li>Primitive types stored on stack</li>
                            <li>Manual memory management</li>
                            <li>Fixed-size types (int, float, double)</li>
                            <li>Pointers for memory access</li>
                          </ul>
                        </div>

                        <div className="bg-gray-900 p-4 rounded-lg">
                          <h4 className="font-bold mb-2">JavaScript</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            <li>Dynamically typed (types checked at runtime)</li>
                            <li>Type inference (no explicit declarations)</li>
                            <li>Primitive vs reference types</li>
                            <li>Automatic garbage collection</li>
                            <li>Single Number type for all numerics</li>
                            <li>Objects for complex data structures</li>
                          </ul>
                        </div>

                        <div className="bg-gray-900 p-4 rounded-lg">
                          <h4 className="font-bold mb-2">Python</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            <li>Dynamically typed (types checked at runtime)</li>
                            <li>Everything is an object</li>
                            <li>Reference counting for memory management</li>
                            <li>Rich built-in data structures</li>
                            <li>Arbitrary precision integers</li>
                            <li>Duck typing philosophy</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedConcept === "Control Structures" && (
                    <div className="space-y-4">
                      <p>
                        Control structures direct the flow of execution in a program, allowing for conditional execution
                        and repetition of code blocks.
                      </p>

                      <h3 className="text-xl font-semibold mt-4">Comparison across languages:</h3>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                        <div className="bg-gray-900 p-4 rounded-lg">
                          <h4 className="font-bold mb-2">C++</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            <li>if-else, switch-case statements</li>
                            <li>for, while, do-while loops</li>
                            <li>Range-based for loops</li>
                            <li>Break, continue, goto statements</li>
                            <li>No native foreach construct</li>
                            <li>Braces required for multi-line blocks</li>
                          </ul>
                        </div>

                        <div className="bg-gray-900 p-4 rounded-lg">
                          <h4 className="font-bold mb-2">JavaScript</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            <li>if-else, switch-case statements</li>
                            <li>for, while, do-while loops</li>
                            <li>for...of for iterables, for...in for objects</li>
                            <li>Array methods (forEach, map, filter)</li>
                            <li>Ternary operator for inline conditionals</li>
                            <li>Optional braces (not recommended)</li>
                          </ul>
                        </div>

                        <div className="bg-gray-900 p-4 rounded-lg">
                          <h4 className="font-bold mb-2">Python</h4>
                          <ul className="list-disc list-inside space-y-1 text-sm">
                            <li>if-elif-else statements</li>
                            <li>for-in loops, while loops</li>
                            <li>No do-while or switch statements</li>
                            <li>List/dict/set comprehensions</li>
                            <li>Indentation defines code blocks</li>
                            <li>Conditional expressions (ternary)</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}

                  {!["Variables and Data Types", "Control Structures"].includes(selectedConcept) && (
                    <div className="text-center py-8">
                      <p className="text-gray-400">Theoretical content for "{selectedConcept}" is coming soon.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="visualization" className="mt-0">
              <Card className="bg-black border-gray-800">
                <CardHeader>
                  <CardTitle>{selectedConcept} Visualization</CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedConcept === "Variables and Data Types" && <VariablesVisualization />}
                  {selectedConcept === "Control Structures" && <ControlFlowVisualization />}

                  {!["Variables and Data Types", "Control Structures"].includes(selectedConcept) && (
                    <div className="text-center py-8">
                      <p className="text-gray-400">Visualization for "{selectedConcept}" is coming soon.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
