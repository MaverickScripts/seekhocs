import { Skeleton } from "@/components/ui/skeleton"

export default function ProgrammingLanguagesLoading() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <Skeleton className="h-12 w-3/4 mx-auto mb-4" />
        <Skeleton className="h-6 w-1/2 mx-auto" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 rounded-lg" />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <Skeleton className="h-96 rounded-lg" />
        </div>

        <div className="lg:col-span-3">
          <Skeleton className="h-12 w-full mb-8 rounded-lg" />
          <Skeleton className="h-96 rounded-lg" />
        </div>
      </div>
    </div>
  )
}
