"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import ConceptCard from "@/components/concept-card"

export default function ConceptsPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = [
    {
      title: "Algorithms",
      description: "Visualize sorting, searching, and graph algorithms in real-time",
      icon: "Binary",
      href: "/concepts/algorithms",
    },
    {
      title: "Data Structures",
      description: "Explore trees, graphs, arrays and more with interactive models",
      icon: "LayoutGrid",
      href: "/concepts/data-structures",
    },
    {
      title: "Computer Architecture",
      description: "Understand CPUs, memory hierarchies and hardware components",
      icon: "Cpu",
      href: "/concepts/architecture",
    },
    {
      title: "Neural Networks",
      description: "See how neural networks learn and process information",
      icon: "Network",
      href: "/concepts/neural-networks",
    },
    {
      title: "Operating Systems",
      description: "Visualize processes, memory management and scheduling",
      icon: "Layers",
      href: "/concepts/operating-systems",
    },
    {
      title: "Cryptography",
      description: "Explore encryption algorithms and security concepts",
      icon: "Lock",
      href: "/concepts/cryptography",
    },
    {
      title: "Automata Theory",
      description: "Visualize Turing machines, DFAs, NFAs, and regular expressions",
      icon: "Binary",
      href: "/concepts/automata-theory",
    },
    {
      title: "Compilers",
      description: "Explore lexical analysis, parsing, and code generation",
      icon: "Code",
      href: "/concepts/compilers",
    },
    {
      title: "Networking",
      description: "Simulate TCP/IP, routing algorithms, and HTTP/DNS protocols",
      icon: "Network",
      href: "/concepts/networking",
    },
    {
      title: "Database Systems",
      description: "Visualize SQL queries, NoSQL models, and indexing techniques",
      icon: "Database",
      href: "/concepts/database-systems",
    },
    {
      title: "Programming Languages",
      description: "Compare C++, JavaScript, and Python with interactive examples",
      icon: "Code",
      href: "/concepts/programming-languages",
    },
  ]

  const filteredCategories = categories.filter(
    (category) =>
      category.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      category.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore Concepts</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
          Discover interactive visualizations for a wide range of computer science topics
        </p>

        <div className="max-w-md mx-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search concepts..."
              className="pl-10 bg-black border-gray-800 text-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCategories.length > 0 ? (
          filteredCategories.map((category, index) => (
            <ConceptCard
              key={index}
              title={category.title}
              description={category.description}
              icon={category.icon}
              href={category.href}
              delay={index * 0.1}
            />
          ))
        ) : (
          <div className="col-span-3 text-center py-12">
            <p className="text-gray-400">No concepts found matching "{searchQuery}"</p>
          </div>
        )}
      </div>
    </div>
  )
}
