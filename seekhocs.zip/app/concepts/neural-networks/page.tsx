"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, Plus, Minus } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import Footer from "@/components/footer"
import { useSearchParams } from "next/navigation"

export default function NeuralNetworksPage() {
  // Add concept-specific visualization logic
  // Add a useEffect that sets networkType based on selected concept
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")
  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(50)
  const [learningRate, setLearningRate] = useState(0.1)
  const [epoch, setEpoch] = useState(0)
  const [networkType, setNetworkType] = useState("feedforward")
  const [layers, setLayers] = useState([3, 4, 2, 1])
  const [weights, setWeights] = useState<number[][][]>([])
  const [activations, setActivations] = useState<number[][]>([])
  const [error, setError] = useState(0)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [message, setMessage] = useState(
    "Feedforward Neural Networks: Neural networks where connections between nodes do not form cycles.",
  )

  // Initialize weights and activations
  useEffect(() => {
    initializeNetwork()

    // Set canvas size
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [layers])

  // Add this useEffect after the existing useEffect for initializing weights and activations:
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setEpoch(0)
      setIsPlaying(false)

      // Set network type based on selected concept
      if (
        selectedConcept.toLowerCase().includes("recurrent") ||
        selectedConcept.toLowerCase().includes("rnn") ||
        selectedConcept.toLowerCase().includes("lstm") ||
        selectedConcept.toLowerCase().includes("gru")
      ) {
        setNetworkType("recurrent")

        if (selectedConcept.toLowerCase().includes("lstm")) {
          setMessage(
            "LSTM Networks: Long Short-Term Memory networks are a type of RNN capable of learning long-term dependencies.",
          )
        } else if (selectedConcept.toLowerCase().includes("gru")) {
          setMessage("GRU Networks: Gated Recurrent Unit networks are a simpler variant of LSTM with fewer parameters.")
        } else {
          setMessage(
            "Recurrent Neural Networks: Neural networks with feedback connections, suitable for sequential data.",
          )
        }
      } else if (
        selectedConcept.toLowerCase().includes("convolutional") ||
        selectedConcept.toLowerCase().includes("cnn")
      ) {
        setNetworkType("feedforward") // Using feedforward as placeholder
        setMessage(
          "Convolutional Neural Networks: Neural networks designed for processing grid-like data such as images.",
        )
      } else if (selectedConcept.toLowerCase().includes("autoencoder")) {
        setNetworkType("feedforward")
        setMessage(
          "Autoencoders: Neural networks trained to copy their input to their output, learning efficient encodings in the process.",
        )
      } else if (selectedConcept.toLowerCase().includes("gan")) {
        setNetworkType("feedforward")
        setMessage(
          "Generative Adversarial Networks: A framework where two neural networks compete, one generating content and the other evaluating it.",
        )
      } else if (selectedConcept.toLowerCase().includes("reinforcement")) {
        setNetworkType("feedforward")
        setMessage(
          "Reinforcement Learning: A type of machine learning where an agent learns to make decisions by taking actions to maximize rewards.",
        )
      } else if (selectedConcept.toLowerCase().includes("activation")) {
        setNetworkType("feedforward")
        setMessage(
          "Activation Functions: Functions that determine the output of a neural network node, introducing non-linearity to the model.",
        )
      } else if (selectedConcept.toLowerCase().includes("backpropagation")) {
        setNetworkType("feedforward")
        setMessage(
          "Backpropagation: An algorithm for training neural networks by calculating gradients of the loss function with respect to the weights.",
        )
      } else {
        setNetworkType("feedforward")
        setMessage("Feedforward Neural Networks: Neural networks where connections between nodes do not form cycles.")
      }

      // Reset the network with new parameters
      initializeNetwork()
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Neural Networks Visualizer`
    }
  }, [selectedConcept])

  // Initialize network with random weights
  const initializeNetwork = () => {
    // Initialize weights
    const newWeights: number[][][] = []

    for (let i = 0; i < layers.length - 1; i++) {
      const layerWeights: number[][] = []

      for (let j = 0; j < layers[i]; j++) {
        const nodeWeights: number[] = []

        for (let k = 0; k < layers[i + 1]; k++) {
          // Random weight between -0.5 and 0.5
          nodeWeights.push(Math.random() - 0.5)
        }

        layerWeights.push(nodeWeights)
      }

      newWeights.push(layerWeights)
    }

    setWeights(newWeights)

    // Initialize activations
    const newActivations: number[][] = []

    for (let i = 0; i < layers.length; i++) {
      const layerActivations: number[] = []

      for (let j = 0; j < layers[i]; j++) {
        // Random activation between 0 and 1 for input layer, 0 for others
        layerActivations.push(i === 0 ? Math.random() : 0)
      }

      newActivations.push(layerActivations)
    }

    setActivations(newActivations)
    setEpoch(0)
    setError(0)
  }

  // Forward pass through the network
  const forwardPass = () => {
    const newActivations = [...activations]

    // For each layer (except input)
    for (let i = 1; i < layers.length; i++) {
      // For each neuron in the current layer
      for (let j = 0; j < layers[i]; j++) {
        let sum = 0

        // For each neuron in the previous layer
        for (let k = 0; k < layers[i - 1]; k++) {
          sum += newActivations[i - 1][k] * weights[i - 1][k][j]
        }

        // Apply sigmoid activation function
        newActivations[i][j] = 1 / (1 + Math.exp(-sum))
      }
    }

    setActivations(newActivations)

    // Calculate error (simplified)
    const outputLayer = newActivations[newActivations.length - 1]
    const target = 0.8 // Target value for demonstration
    const newError = outputLayer.reduce((sum, output) => sum + Math.pow(target - output, 2), 0) / outputLayer.length
    setError(newError)
  }

  // Backpropagation (simplified for visualization)
  const backpropagate = () => {
    const newWeights = [...weights]

    // Update weights (simplified)
    for (let i = 0; i < newWeights.length; i++) {
      for (let j = 0; j < newWeights[i].length; j++) {
        for (let k = 0; k < newWeights[i][j].length; k++) {
          // Simple weight update for visualization
          newWeights[i][j][k] += (Math.random() - 0.5) * learningRate * (1 - error)
        }
      }
    }

    setWeights(newWeights)
    setEpoch((prev) => prev + 1)
  }

  // Training step
  const trainStep = () => {
    forwardPass()
    backpropagate()
  }

  // Start training
  const startTraining = () => {
    setIsPlaying(true)
  }

  // Pause training
  const pauseTraining = () => {
    setIsPlaying(false)
  }

  // Reset network
  const resetNetwork = () => {
    initializeNetwork()
    setIsPlaying(false)
  }

  // Add a neuron to a layer
  const addNeuron = (layerIndex: number) => {
    if (layerIndex < 0 || layerIndex >= layers.length) return

    const newLayers = [...layers]
    newLayers[layerIndex]++
    setLayers(newLayers)
  }

  // Remove a neuron from a layer
  const removeNeuron = (layerIndex: number) => {
    if (layerIndex < 0 || layerIndex >= layers.length || layers[layerIndex] <= 1) return

    const newLayers = [...layers]
    newLayers[layerIndex]--
    setLayers(newLayers)
  }

  // Training animation
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          trainStep()
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, activations, weights, speed])

  // Draw the neural network
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Calculate node positions
    const nodePositions: { x: number; y: number }[][] = []
    const layerSpacing = canvas.width / (layers.length + 1)
    const maxNeurons = Math.max(...layers)

    for (let i = 0; i < layers.length; i++) {
      const layerNodes: { x: number; y: number }[] = []
      const neuronSpacing = canvas.height / (layers[i] + 1)

      for (let j = 0; j < layers[i]; j++) {
        layerNodes.push({
          x: (i + 1) * layerSpacing,
          y: (j + 1) * neuronSpacing,
        })
      }

      nodePositions.push(layerNodes)
    }

    // Draw connections between neurons
    for (let i = 0; i < layers.length - 1; i++) {
      for (let j = 0; j < layers[i]; j++) {
        for (let k = 0; k < layers[i + 1]; k++) {
          const startX = nodePositions[i][j].x
          const startY = nodePositions[i][j].y
          const endX = nodePositions[i + 1][k].x
          const endY = nodePositions[i + 1][k].y

          // Calculate connection strength for color
          const weight = weights[i]?.[j]?.[k] || 0
          const normalizedWeight = (weight + 1) / 2 // Map from [-1, 1] to [0, 1]

          // Draw connection
          ctx.beginPath()
          ctx.moveTo(startX, startY)
          ctx.lineTo(endX, endY)

          // Color based on weight
          const r = Math.floor(255 * (1 - normalizedWeight))
          const g = Math.floor(255 * normalizedWeight)
          const b = 255
          const a = 0.3 + normalizedWeight * 0.7 // Opacity based on weight

          ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${a})`
          ctx.lineWidth = 1 + normalizedWeight * 2
          ctx.stroke()
        }
      }
    }

    // Draw neurons
    for (let i = 0; i < layers.length; i++) {
      for (let j = 0; j < layers[i]; j++) {
        const x = nodePositions[i][j].x
        const y = nodePositions[i][j].y
        const activation = activations[i]?.[j] || 0

        // Draw neuron
        ctx.beginPath()
        ctx.arc(x, y, 15, 0, Math.PI * 2)

        // Color based on activation
        const r = Math.floor(255 * (1 - activation))
        const g = Math.floor(255 * activation)
        const b = 255

        ctx.fillStyle = `rgb(${r}, ${g}, ${b})`
        ctx.shadowColor = `rgb(${r}, ${g}, ${b})`
        ctx.shadowBlur = 10 * activation
        ctx.fill()

        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Reset shadow
        ctx.shadowBlur = 0

        // Draw activation value
        ctx.fillStyle = "#ffffff"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(activation.toFixed(2), x, y)
      }
    }

    // Draw layer labels
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"

    ctx.fillText("Input Layer", nodePositions[0][0].x, 20)

    for (let i = 1; i < layers.length - 1; i++) {
      ctx.fillText(`Hidden Layer ${i}`, nodePositions[i][0].x, 20)
    }

    ctx.fillText("Output Layer", nodePositions[layers.length - 1][0].x, 20)
  }, [layers, weights, activations, canvasSize])

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Neural Network Visualizer
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Explore how neural networks learn through interactive visualization
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Network Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetNetwork}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseTraining}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startTraining} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Train
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-800/50 rounded-md">
                    <div className="text-sm text-gray-400 mb-1">Epoch</div>
                    <div className="text-xl font-mono text-cyan-400">{epoch}</div>
                  </div>
                  <div className="p-3 bg-gray-800/50 rounded-md">
                    <div className="text-sm text-gray-400 mb-1">Error</div>
                    <div className="text-xl font-mono text-cyan-400">{error.toFixed(4)}</div>
                  </div>
                </div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Network Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Network Type</h3>
                    <Tabs
                      defaultValue="feedforward"
                      value={networkType}
                      onValueChange={setNetworkType}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-2 bg-gray-800/50">
                        <TabsTrigger value="feedforward">Feedforward</TabsTrigger>
                        <TabsTrigger value="recurrent">Recurrent</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Network Architecture</h3>
                    <div className="grid grid-cols-4 gap-2">
                      {layers.map((neurons, index) => (
                        <div key={index} className="flex flex-col items-center">
                          <div className="text-xs text-gray-400 mb-1">
                            {index === 0 ? "Input" : index === layers.length - 1 ? "Output" : `Hidden ${index}`}
                          </div>
                          <div className="flex items-center space-x-1">
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 w-7 p-0 border-gray-700"
                              onClick={() => removeNeuron(index)}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <div className="w-8 text-center font-mono text-cyan-400">{neurons}</div>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 w-7 p-0 border-gray-700"
                              onClick={() => addNeuron(index)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Learning Rate</h3>
                    <div className="flex items-center space-x-4">
                      <Slider
                        value={[learningRate * 100]}
                        min={1}
                        max={100}
                        step={1}
                        onValueChange={(value) => setLearningRate(value[0] / 100)}
                        className="flex-1"
                      />
                      <span className="w-12 text-right font-mono text-cyan-400">{learningRate.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">How Neural Networks Work</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      <p>Neural networks are computational models inspired by the human brain. They consist of:</p>
                      <ul className="list-disc pl-5 space-y-1 mt-2">
                        <li>Neurons (nodes) organized in layers</li>
                        <li>Connections between neurons with weights</li>
                        <li>Activation functions that determine neuron output</li>
                      </ul>
                      <p className="mt-2">The learning process involves:</p>
                      <ol className="list-decimal pl-5 space-y-1 mt-1">
                        <li>Forward propagation: Input signals flow through the network</li>
                        <li>Error calculation: Compare output with expected result</li>
                        <li>Backpropagation: Adjust weights to minimize error</li>
                      </ol>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Concept Description</h3>
                    <div className="text-sm text-gray-300">{message}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

