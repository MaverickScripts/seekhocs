"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Packet class for network visualization
class Packet {
  id: number
  source: string
  destination: string
  data: string
  protocol: string
  layer: number
  x: number
  y: number
  status: "sending" | "received" | "processing" | "error"

  constructor(id: number, source: string, destination: string, data: string, protocol: string) {
    this.id = id
    this.source = source
    this.destination = destination
    this.data = data
    this.protocol = protocol
    this.layer = 7 // Start at application layer
    this.x = 0
    this.y = 0
    this.status = "sending"
  }
}

// Node class for network visualization
class NetworkNode {
  id: string
  type: "client" | "server" | "router" | "switch"
  x: number
  y: number
  isActive: boolean

  constructor(id: string, type: "client" | "server" | "router" | "switch", x: number, y: number) {
    this.id = id
    this.type = type
    this.x = x
    this.y = y
    this.isActive = false
  }
}

export default function NetworkingPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [networkTopic, setNetworkTopic] = useState("tcp-ip")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [packets, setPackets] = useState<Packet[]>([])
  const [currentPacketIndex, setCurrentPacketIndex] = useState(0)
  const [nodes, setNodes] = useState<NetworkNode[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [message, setMessage] = useState("")
  const [url, setUrl] = useState("https://example.com")
  const [requestDetails, setRequestDetails] = useState("")
  const [responseDetails, setResponseDetails] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Networking Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore networking protocols and concepts through interactive visualizations",
  )

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Initialize based on selected concept
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)
      setCurrentPacketIndex(0)
      setCurrentStep(0)
      setPackets([])

      // Set network topic based on selected concept
      if (selectedConcept.toLowerCase().includes("tcp") || selectedConcept.toLowerCase().includes("ip")) {
        setNetworkTopic("tcp-ip")
        setConceptTitle("TCP/IP Protocol")
        setConceptDescription(
          "The Transmission Control Protocol/Internet Protocol suite is the set of communications protocols used on the Internet and similar networks.",
        )
        setMessage("TCP/IP: The foundation of Internet communications, organized in layers.")
        initializeTcpIpVisualization()
      } else if (selectedConcept.toLowerCase().includes("osi")) {
        setNetworkTopic("tcp-ip") // Using TCP/IP visualization for OSI model
        setConceptTitle("OSI Model")
        setConceptDescription(
          "The Open Systems Interconnection model is a conceptual framework that standardizes the functions of a telecommunication or computing system into seven abstraction layers.",
        )
        setMessage("OSI Model: A seven-layer conceptual framework for understanding network interactions.")
        initializeTcpIpVisualization()
      } else if (selectedConcept.toLowerCase().includes("http")) {
        setNetworkTopic("http")
        setConceptTitle("HTTP Protocol")
        setConceptDescription(
          "The Hypertext Transfer Protocol is an application layer protocol for distributed, collaborative, hypermedia information systems.",
        )
        setMessage("HTTP: The protocol used for transmitting hypermedia documents on the World Wide Web.")
        initializeHttpVisualization()
      } else if (selectedConcept.toLowerCase().includes("dns")) {
        setNetworkTopic("http") // Using HTTP visualization for DNS
        setConceptTitle("DNS System")
        setConceptDescription(
          "The Domain Name System is a hierarchical and decentralized naming system for computers, services, or other resources connected to the Internet or a private network.",
        )
        setMessage("DNS: Translates domain names to IP addresses for locating computer services and devices.")
        initializeHttpVisualization()
      } else if (selectedConcept.toLowerCase().includes("routing")) {
        setNetworkTopic("routing")
        setConceptTitle("Routing Algorithms")
        setConceptDescription(
          "Routing algorithms determine the specific choice of route for data packets traveling across a network or between multiple networks.",
        )
        setMessage("Routing Algorithms: Determine the optimal path for data to travel across networks.")
        initializeRoutingVisualization()
      } else {
        // Default to TCP/IP
        setNetworkTopic("tcp-ip")
        setConceptTitle("Networking Visualizer")
        setConceptDescription("Explore networking protocols and concepts through interactive visualizations")
        setMessage("Select a networking concept to visualize its operation.")
        initializeTcpIpVisualization()
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Networking Visualizer`
    }
  }, [selectedConcept])

  // Initialize TCP/IP visualization
  const initializeTcpIpVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const routerNode = new NetworkNode("Router", "router", 400, 200)
    const serverNode = new NetworkNode("Server", "server", 700, 200)

    setNodes([clientNode, routerNode, serverNode])

    // Create a packet
    const packet = new Packet(1, "Client", "Server", "Hello, Server!", "TCP/IP")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("TCP/IP: Data travels through multiple protocol layers before transmission.")
  }

  // Initialize HTTP visualization
  const initializeHttpVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const serverNode = new NetworkNode("Server", "server", 700, 200)

    setNodes([clientNode, serverNode])

    // Create request and response packets
    const requestPacket = new Packet(1, "Client", "Server", "GET /index.html HTTP/1.1", "HTTP")
    const responsePacket = new Packet(2, "Server", "Client", "HTTP/1.1 200 OK", "HTTP")

    setPackets([requestPacket, responsePacket])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("HTTP: A request-response protocol in the client-server computing model.")

    // Set request and response details
    setRequestDetails(`GET /index.html HTTP/1.1
Host: example.com
User-Agent: Mozilla/5.0
Accept: text/html
Connection: keep-alive`)

    setResponseDetails(`HTTP/1.1 200 OK
Date: ${new Date().toUTCString()}
Content-Type: text/html
Content-Length: 1234
Connection: keep-alive

<!DOCTYPE html>
<html>
<head>
  <title>Example Domain</title>
</head>
<body>
  <h1>Example Domain</h1>
  <p>This domain is for use in examples.</p>
</body>
</html>`)
  }

  // Initialize routing visualization
  const initializeRoutingVisualization = () => {
    // Create a network of nodes
    const nodes = [
      new NetworkNode("A", "router", 100, 100),
      new NetworkNode("B", "router", 300, 100),
      new NetworkNode("C", "router", 500, 100),
      new NetworkNode("D", "router", 100, 300),
      new NetworkNode("E", "router", 300, 300),
      new NetworkNode("F", "router", 500, 300),
    ]

    setNodes(nodes)

    // Create a packet
    const packet = new Packet(1, "A", "F", "Routing data", "IP")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("Routing Algorithms: Finding the optimal path through a network.")
  }

  // Animation loop
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          if (networkTopic === "tcp-ip") {
            // TCP/IP animation
            if (currentStep < 14) {
              // 7 layers down + 7 layers up
              setCurrentStep(currentStep + 1)

              // Update packet layer
              const updatedPackets = [...packets]
              const packet = updatedPackets[currentPacketIndex]

              if (currentStep < 7) {
                // Moving down through layers
                packet.layer = 7 - currentStep
                packet.x = 100 + currentStep * 50
                packet.y = 200 + currentStep * 20

                if (currentStep === 3) {
                  // At network layer, packet reaches router
                  packet.status = "processing"
                  nodes[1].isActive = true
                } else {
                  nodes[1].isActive = false
                }
              } else {
                // Moving up through layers
                packet.layer = currentStep - 7
                packet.x = 400 + (currentStep - 7) * 50
                packet.y = 340 - (currentStep - 7) * 20

                if (currentStep === 10) {
                  // At network layer, packet reaches server
                  packet.status = "received"
                  nodes[2].isActive = true
                } else {
                  nodes[2].isActive = false
                }
              }

              setPackets(updatedPackets)

              // Update message based on layer
              const layerNames = [
                "Physical Layer",
                "Data Link Layer",
                "Network Layer",
                "Transport Layer",
                "Session Layer",
                "Presentation Layer",
                "Application Layer",
              ]

              if (currentStep < 7) {
                setMessage(`Encapsulating data at ${layerNames[6 - currentStep]}`)
              } else {
                setMessage(`Decapsulating data at ${layerNames[currentStep - 7]}`)
              }
            } else {
              setIsPlaying(false)
              setMessage("TCP/IP communication complete.")
            }
          } else if (networkTopic === "http") {
            // HTTP animation
            if (currentStep < 6) {
              setCurrentStep(currentStep + 1)

              const updatedPackets = [...packets]
              const packet = updatedPackets[currentPacketIndex]

              if (currentPacketIndex === 0) {
                // Request packet
                if (currentStep < 3) {
                  // Moving from client to server
                  packet.x = 100 + currentStep * 200
                  packet.y = 200

                  if (currentStep === 2) {
                    // Packet reaches server
                    packet.status = "received"
                    nodes[1].isActive = true
                    setMessage("Server processing the HTTP request...")
                  } else {
                    setMessage("Sending HTTP request to server...")
                  }
                } else {
                  // Start response
                  setCurrentPacketIndex(1)
                  updatedPackets[1].x = 700
                  updatedPackets[1].y = 200
                  setMessage("Server sending HTTP response...")
                }
              } else {
                // Response packet
                const responseStep = currentStep - 3
                updatedPackets[1].x = 700 - responseStep * 200

                if (responseStep === 2) {
                  // Response reaches client
                  updatedPackets[1].status = "received"
                  nodes[0].isActive = true
                  setMessage("Client received the HTTP response.")
                  setIsPlaying(false)
                }
              }

              setPackets(updatedPackets)
            } else {
              setIsPlaying(false)
              setMessage("HTTP request-response cycle complete.")
            }
          } else if (networkTopic === "routing") {
            // Routing animation
            if (currentStep < 5) {
              setCurrentStep(currentStep + 1)

              const updatedPackets = [...packets]
              const packet = updatedPackets[0]

              // Simulate Dijkstra's algorithm path: A -> B -> E -> F
              const path = [
                { x: 100, y: 100 }, // A
                { x: 300, y: 100 }, // B
                { x: 300, y: 300 }, // E
                { x: 500, y: 300 }, // F
              ]

              if (currentStep < path.length) {
                packet.x = path[currentStep].x
                packet.y = path[currentStep].y

                // Activate current node
                const nodeIndex = ["A", "B", "E", "F"][currentStep]
                nodes.forEach((node) => {
                  node.isActive = node.id === nodeIndex
                })

                setMessage(`Routing packet through node ${nodeIndex}...`)

                if (currentStep === path.length - 1) {
                  packet.status = "received"
                  setMessage("Packet has reached its destination.")
                  setIsPlaying(false)
                }
              }

              setPackets(updatedPackets)
            } else {
              setIsPlaying(false)
              setMessage("Routing complete.")
            }
          }
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, networkTopic, currentStep, currentPacketIndex, packets, nodes, speed])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (networkTopic === "tcp-ip") {
      drawTcpIpVisualization(ctx)
    } else if (networkTopic === "http") {
      drawHttpVisualization(ctx)
    } else if (networkTopic === "routing") {
      drawRoutingVisualization(ctx)
    }
  }, [networkTopic, packets, nodes, currentStep, currentPacketIndex, canvasSize, url, requestDetails, responseDetails])

  // Draw TCP/IP visualization
  const drawTcpIpVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw layer labels
    const layerNames = ["Physical", "Data Link", "Network", "Transport", "Session", "Presentation", "Application"]

    const layerHeight = 30
    const startY = height - layerHeight * 7 - 20

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"

    for (let i = 0; i < 7; i++) {
      const y = startY + i * layerHeight

      ctx.fillText(`${i + 1}. ${layerNames[i]}`, 80, y + layerHeight / 2)

      // Draw layer lines
      ctx.beginPath()
      ctx.moveTo(90, y)
      ctx.lineTo(width - 20, y)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw bottom line
    ctx.beginPath()
    ctx.moveTo(90, startY + 7 * layerHeight)
    ctx.lineTo(width - 20, startY + 7 * layerHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw nodes
    nodes.forEach((node) => {
      let nodeImage

      if (node.type === "client") {
        // Draw client
        ctx.beginPath()
        ctx.rect(node.x - 30, node.y - 40, 60, 40)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw monitor
        ctx.beginPath()
        ctx.rect(node.x - 20, node.y - 35, 40, 25)
        ctx.fillStyle = "#1a202c"
        ctx.fill()

        // Draw stand
        ctx.beginPath()
        ctx.rect(node.x - 5, node.y - 10, 10, 15)
        ctx.fillStyle = "#2d3748"
        ctx.fill()

        // Draw base
        ctx.beginPath()
        ctx.rect(node.x - 15, node.y + 5, 30, 5)
        ctx.fillStyle = "#2d3748"
        ctx.fill()
      } else if (node.type === "server") {
        // Draw server
        ctx.beginPath()
        ctx.rect(node.x - 25, node.y - 40, 50, 80)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw server details
        for (let i = 0; i < 3; i++) {
          ctx.beginPath()
          ctx.rect(node.x - 15, node.y - 30 + i * 20, 30, 10)
          ctx.fillStyle = "#1a202c"
          ctx.fill()
        }
      } else if (node.type === "router") {
        // Draw router
        ctx.beginPath()
        ctx.rect(node.x - 30, node.y - 15, 60, 30)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw antennas
        ctx.beginPath()
        ctx.moveTo(node.x - 20, node.y - 15)
        ctx.lineTo(node.x - 20, node.y - 25)
        ctx.moveTo(node.x, node.y - 15)
        ctx.lineTo(node.x, node.y - 25)
        ctx.moveTo(node.x + 20, node.y - 15)
        ctx.lineTo(node.x + 20, node.y - 25)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id, node.x, node.y + 30)
    })

    // Draw packets
    packets.forEach((packet) => {
      // Draw packet
      ctx.beginPath()
      ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

      if (packet.status === "sending") {
        ctx.fillStyle = "#4fd1c5"
      } else if (packet.status === "received") {
        ctx.fillStyle = "#9f7aea"
      } else if (packet.status === "processing") {
        ctx.fillStyle = "#f6ad55"
      } else {
        ctx.fillStyle = "#f87171"
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw packet label
      ctx.fillStyle = "#000000"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(`Packet ${packet.id}`, packet.x, packet.y)

      // Draw packet details
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(`Layer: ${packet.layer}`, 20, 20)
      ctx.fillText(`Protocol: ${packet.protocol}`, 20, 40)
      ctx.fillText(`Source: ${packet.source}`, 20, 60)
      ctx.fillText(`Destination: ${packet.destination}`, 20, 80)
    })
  }

  // Draw HTTP visualization
  const drawHttpVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw URL
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(`URL: ${url}`, width / 2, 20)

    // Draw nodes
    nodes.forEach((node) => {
      if (node.type === "client") {
        // Draw client
        ctx.beginPath()
        ctx.rect(node.x - 30, node.y - 40, 60, 40)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw monitor
        ctx.beginPath()
        ctx.rect(node.x - 20, node.y - 35, 40, 25)
        ctx.fillStyle = "#1a202c"
        ctx.fill()

        // Draw stand
        ctx.beginPath()
        ctx.rect(node.x - 5, node.y - 10, 10, 15)
        ctx.fillStyle = "#2d3748"
        ctx.fill()

        // Draw base
        ctx.beginPath()
        ctx.rect(node.x - 15, node.y + 5, 30, 5)
        ctx.fillStyle = "#2d3748"
        ctx.fill()
      } else if (node.type === "server") {
        // Draw server
        ctx.beginPath()
        ctx.rect(node.x - 25, node.y - 40, 50, 80)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw server details
        for (let i = 0; i < 3; i++) {
          ctx.beginPath()
          ctx.rect(node.x - 15, node.y - 30 + i * 20, 30, 10)
          ctx.fillStyle = "#1a202c"
          ctx.fill()
        }
      }

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id, node.x, node.y + 50)
    })

    // Draw connection line
    ctx.beginPath()
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[1].x, nodes[1].y)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.setLineDash([5, 5])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw packets
    packets.forEach((packet, index) => {
      if ((index === 0 && currentStep < 3) || (index === 1 && currentStep >= 3)) {
        // Draw packet
        ctx.beginPath()
        ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

        if (packet.status === "sending") {
          ctx.fillStyle = index === 0 ? "#4fd1c5" : "#9f7aea"
        } else if (packet.status === "received") {
          ctx.fillStyle = index === 0 ? "#9f7aea" : "#4fd1c5"
        } else {
          ctx.fillStyle = "#f87171"
        }

        ctx.fill()
        ctx.strokeStyle = "#ffffff"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw packet label
        ctx.fillStyle = "#000000"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(index === 0 ? "Request" : "Response", packet.x, packet.y)
      }
    })

    // Draw request and response details
    if (currentStep >= 1) {
      // Draw request details
      ctx.fillStyle = "#ffffff"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      const requestLines = requestDetails.split("\n")
      for (let i = 0; i < requestLines.length; i++) {
        ctx.fillText(requestLines[i], 20, 250 + i * 15)
      }
    }

    if (currentStep >= 4) {
      // Draw response details
      ctx.fillStyle = "#ffffff"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      const responseLines = responseDetails.split("\n").slice(0, 5) // Show only headers
      for (let i = 0; i < responseLines.length; i++) {
        ctx.fillText(responseLines[i], width - 300, 250 + i * 15)
      }
    }
  }

  // Draw routing visualization
  const drawRoutingVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw connections between nodes
    const connections = [
      { from: "A", to: "B" },
      { from: "B", to: "C" },
      { from: "A", to: "D" },
      { from: "B", to: "E" },
      { from: "C", to: "F" },
      { from: "D", to: "E" },
      { from: "E", to: "F" },
    ]

    connections.forEach(({ from, to }) => {
      const fromNode = nodes.find((n) => n.id === from)
      const toNode = nodes.find((n) => n.id === to)

      if (fromNode && toNode) {
        ctx.beginPath()
        ctx.moveTo(fromNode.x, fromNode.y)
        ctx.lineTo(toNode.x, toNode.y)

        // Highlight the path A -> B -> E -> F
        if ((from === "A" && to === "B") || (from === "B" && to === "E") || (from === "E" && to === "F")) {
          ctx.strokeStyle = "#9f7aea"
          ctx.lineWidth = 3
        } else {
          ctx.strokeStyle = "#4fd1c5"
          ctx.lineWidth = 1
        }

        ctx.stroke()

        // Draw distance
        const midX = (fromNode.x + toNode.x) / 2
        const midY = (fromNode.y + toNode.y) / 2
        const distance = Math.floor(
          Math.sqrt(Math.pow(toNode.x - fromNode.x, 2) + Math.pow(toNode.y - fromNode.y, 2)) / 10,
        )

        ctx.fillStyle = "#ffffff"
        ctx.font = "12px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(distance.toString(), midX, midY - 10)
      }
    })

    // Draw nodes
    nodes.forEach((node) => {
      // Draw router
      ctx.beginPath()
      ctx.arc(node.x, node.y, 20, 0, Math.PI * 2)
      ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id, node.x, node.y)
    })

    // Draw packets
    packets.forEach((packet) => {
      // Draw packet
      ctx.beginPath()
      ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

      if (packet.status === "sending") {
        ctx.fillStyle = "#4fd1c5"
      } else if (packet.status === "received") {
        ctx.fillStyle = "#9f7aea"
      } else {
        ctx.fillStyle = "#f87171"
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw packet label
      ctx.fillStyle = "#000000"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(`Packet`, packet.x, packet.y)
    })

    // Draw algorithm info
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Dijkstra's Algorithm", 20, 20)
    ctx.fillText("Shortest Path: A -> B -> E -> F", 20, 40)
    ctx.fillText("Total Distance: 12", 20, 60)
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setIsPlaying(false)
    setCurrentStep(0)
    setCurrentPacketIndex(0)

    if (networkTopic === "tcp-ip") {
      initializeTcpIpVisualization()
    } else if (networkTopic === "http") {
      initializeHttpVisualization()
    } else if (networkTopic === "routing") {
      initializeRoutingVisualization()
    }
  }

  // Step forward one step
  const stepForward = () => {
    if (networkTopic === "tcp-ip") {
      if (currentStep < 14) {
        // Simulate one step of the animation
        const event = new Event("step")
        document.dispatchEvent(event)

        // Update packet layer
        const updatedPackets = [...packets]
        const packet = updatedPackets[currentPacketIndex]

        if (currentStep < 7) {
          // Moving down through layers
          packet.layer = 7 - currentStep
          packet.x = 100 + currentStep * 50
          packet.y = 200 + currentStep * 20

          if (currentStep === 3) {
            // At network layer, packet reaches router
            packet.status = "processing"
            const updatedNodes = [...nodes]
            updatedNodes[1].isActive = true
            setNodes(updatedNodes)
          }
        } else {
          // Moving up through layers
          packet.layer = currentStep - 7
          packet.x = 400 + (currentStep - 7) * 50
          packet.y = 340 - (currentStep - 7) * 20

          if (currentStep === 10) {
            // At network layer, packet reaches server
            packet.status = "received"
            const updatedNodes = [...nodes]
            updatedNodes[2].isActive = true
            setNodes(updatedNodes)
          }
        }

        setPackets(updatedPackets)
        setCurrentStep(currentStep + 1)

        // Update message based on layer
        const layerNames = [
          "Physical Layer",
          "Data Link Layer",
          "Network Layer",
          "Transport Layer",
          "Session Layer",
          "Presentation Layer",
          "Application Layer",
        ]

        if (currentStep < 7) {
          setMessage(`Encapsulating data at ${layerNames[6 - currentStep]}`)
        } else {
          setMessage(`Decapsulating data at ${layerNames[currentStep - 7]}`)
        }
      }
    } else if (networkTopic === "http") {
      if (currentStep < 6) {
        const updatedPackets = [...packets]
        const packet = updatedPackets[currentPacketIndex]

        if (currentPacketIndex === 0) {
          // Request packet
          if (currentStep < 3) {
            // Moving from client to server
            packet.x = 100 + currentStep * 200
            packet.y = 200

            if (currentStep === 2) {
              // Packet reaches server
              packet.status = "received"
              const updatedNodes = [...nodes]
              updatedNodes[1].isActive = true
              setNodes(updatedNodes)
              setMessage("Server processing the HTTP request...")
            } else {
              setMessage("Sending HTTP request to server...")
            }
          } else {
            // Start response
            setCurrentPacketIndex(1)
            updatedPackets[1].x = 700
            updatedPackets[1].y = 200
            setMessage("Server sending HTTP response...")
          }
        } else {
          // Response packet
          const responseStep = currentStep - 3
          updatedPackets[1].x = 700 - responseStep * 200

          if (responseStep === 2) {
            // Response reaches client
            updatedPackets[1].status = "received"
            const updatedNodes = [...nodes]
            updatedNodes[0].isActive = true
            setNodes(updatedNodes)
            setMessage("Client received the HTTP response.")
          }
        }

        setPackets(updatedPackets)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "routing") {
      if (currentStep < 5) {
        const updatedPackets = [...packets]
        const packet = updatedPackets[0]

        // Simulate Dijkstra's algorithm path: A -> B -> E -> F
        const path = [
          { x: 100, y: 100 }, // A
          { x: 300, y: 100 }, // B
          { x: 300, y: 300 }, // E
          { x: 500, y: 300 }, // F
        ]

        if (currentStep < path.length) {
          packet.x = path[currentStep].x
          packet.y = path[currentStep].y

          // Activate current node
          const nodeIndex = ["A", "B", "E", "F"][currentStep]
          const updatedNodes = [...nodes]
          updatedNodes.forEach((node) => {
            node.isActive = node.id === nodeIndex
          })
          setNodes(updatedNodes)

          setMessage(`Routing packet through node ${nodeIndex}...`)

          if (currentStep === path.length - 1) {
            packet.status = "received"
            setMessage("Packet has reached its destination.")
          }
        }

        setPackets(updatedPackets)
        setCurrentStep(currentStep + 1)
      }
    }
  }

  // Handle URL change
  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value)
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={stepForward}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Network Topic</h3>
                    <Tabs
                      defaultValue="tcp-ip"
                      value={networkTopic}
                      onValueChange={(value) => {
                        setNetworkTopic(value)
                        resetAnimation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="tcp-ip">TCP/IP</TabsTrigger>
                        <TabsTrigger value="http">HTTP/DNS</TabsTrigger>
                        <TabsTrigger value="routing">Routing</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {networkTopic === "http" && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-400 mb-3">URL</h3>
                      <Input
                        value={url}
                        onChange={handleUrlChange}
                        placeholder="Enter URL"
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                  )}

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Network Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {networkTopic === "tcp-ip" ? (
                        <>
                          <p>The TCP/IP protocol suite consists of four layers:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Application Layer: HTTP, FTP, SMTP, DNS</li>
                            <li>Transport Layer: TCP, UDP</li>
                            <li>Internet Layer: IP, ICMP, ARP</li>
                            <li>Link Layer: Ethernet, Wi-Fi, PPP</li>
                          </ul>
                          <p className="mt-2">
                            Data encapsulation occurs as information travels down the layers, with each layer adding its
                            own header information.
                          </p>
                        </>
                      ) : networkTopic === "http" ? (
                        <>
                          <p>HTTP (Hypertext Transfer Protocol) is a request-response protocol:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Client sends a request to the server</li>
                            <li>Server processes the request</li>
                            <li>Server sends a response back to the client</li>
                            <li>Common methods: GET, POST, PUT, DELETE</li>
                            <li>Status codes: 200 OK, 404 Not Found, 500 Server Error</li>
                          </ul>
                        </>
                      ) : (
                        <>
                          <p>Routing algorithms determine the path data takes through a network:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Dijkstra's Algorithm: Finds the shortest path</li>
                            <li>Distance Vector: Routers share information with neighbors</li>
                            <li>Link State: Routers build a map of the entire network</li>
                            <li>Path Vector: Used in BGP for internet routing</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="networking" title="Networking" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

