"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Packet class for network visualization
class Packet {
  id: number
  source: string
  destination: string
  data: string
  protocol: string
  layer: number
  x: number
  y: number
  status: "sending" | "received" | "processing" | "error"

  constructor(id: number, source: string, destination: string, data: string, protocol: string) {
    this.id = id
    this.source = source
    this.destination = destination
    this.data = data
    this.protocol = protocol
    this.layer = 7 // Start at application layer
    this.x = 0
    this.y = 0
    this.status = "sending"
  }
}

// Node class for network visualization
class NetworkNode {
  id: string
  type: "client" | "server" | "router" | "switch"
  x: number
  y: number
  isActive: boolean

  constructor(id: string, type: "client" | "server" | "router" | "switch", x: number, y: number) {
    this.id = id
    this.type = type
    this.x = x
    this.y = y
    this.isActive = false
  }
}

export default function NetworkingPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [networkTopic, setNetworkTopic] = useState("tcp-ip")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [packets, setPackets] = useState<Packet[]>([])
  const [currentPacketIndex, setCurrentPacketIndex] = useState(0)
  const [nodes, setNodes] = useState<NetworkNode[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [message, setMessage] = useState("")
  const [url, setUrl] = useState("https://example.com")
  const [requestDetails, setRequestDetails] = useState("")
  const [responseDetails, setResponseDetails] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Networking Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore networking protocols and concepts through interactive visualizations",
  )

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Add this useEffect after the existing useEffect for setting canvas size:
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)
      setCurrentStep(0)
      setCurrentPacketIndex(0)
      setPackets([])
      setNodes([])

      // Set network topic based on selected concept
      if (selectedConcept.toLowerCase().includes("tcp") || selectedConcept.toLowerCase().includes("ip")) {
        setNetworkTopic("tcp-ip")
        setConceptTitle("TCP/IP Protocol Suite")
        setConceptDescription(
          "The Transmission Control Protocol/Internet Protocol suite is the set of communications protocols used on the Internet and similar networks.",
        )
        setMessage("TCP/IP: The foundation of Internet communications, organized in layers.")
        initializeTcpIpVisualization()
      } else if (selectedConcept.toLowerCase().includes("osi")) {
        setNetworkTopic("osi")
        setConceptTitle("OSI Model")
        setConceptDescription(
          "The Open Systems Interconnection model is a conceptual framework that standardizes the functions of a telecommunication or computing system into seven abstraction layers.",
        )
        setMessage("OSI Model: A seven-layer conceptual framework for understanding network interactions.")
        initializeOsiVisualization()
      } else if (selectedConcept.toLowerCase().includes("http")) {
        setNetworkTopic("http")
        setConceptTitle("HTTP Protocol")
        setConceptDescription(
          "The Hypertext Transfer Protocol is an application layer protocol for distributed, collaborative, hypermedia information systems.",
        )
        setMessage("HTTP: The protocol used for transmitting hypermedia documents on the World Wide Web.")
        initializeHttpVisualization()
      } else if (selectedConcept.toLowerCase().includes("dns")) {
        setNetworkTopic("dns")
        setConceptTitle("DNS System")
        setConceptDescription(
          "The Domain Name System is a hierarchical and decentralized naming system for computers, services, or other resources connected to the Internet or a private network.",
        )
        setMessage("DNS: Translates domain names to IP addresses for locating computer services and devices.")
        initializeDnsVisualization()
      } else if (selectedConcept.toLowerCase().includes("routing")) {
        setNetworkTopic("routing")
        setConceptTitle("Routing Algorithms")
        setConceptDescription(
          "Routing algorithms determine the specific choice of route for data packets traveling across a network or between multiple networks.",
        )
        setMessage("Routing Algorithms: Determine the optimal path for data to travel across networks.")
        initializeRoutingVisualization()
      } else if (selectedConcept.toLowerCase().includes("subnet")) {
        setNetworkTopic("subnetting")
        setConceptTitle("IP Subnetting")
        setConceptDescription(
          "IP Subnetting is the process of dividing an IP network into sub-networks to improve security and performance.",
        )
        setMessage("Subnetting: Divide networks into smaller, more manageable and secure parts.")
        initializeSubnettingVisualization()
      } else if (selectedConcept.toLowerCase().includes("wireless")) {
        setNetworkTopic("wireless")
        setConceptTitle("Wireless Networks")
        setConceptDescription(
          "Wireless networks use radio waves to connect devices such as laptops to the Internet, the business network and applications.",
        )
        setMessage("Wireless Networks: Connecting devices without physical cables.")
        initializeWirelessVisualization()
      } else if (selectedConcept.toLowerCase().includes("socket")) {
        setNetworkTopic("sockets")
        setConceptTitle("Socket Programming")
        setConceptDescription(
          "Socket programming is the process of creating networked applications using network sockets.",
        )
        setMessage("Socket Programming: The foundation of network communication in software.")
        initializeSocketVisualization()
      } else {
        // Default to TCP/IP
        setNetworkTopic("tcp-ip")
        setConceptTitle("Networking Visualizer")
        setConceptDescription("Explore networking protocols and concepts through interactive visualizations")
        setMessage("Select a networking concept to visualize its operation.")
        initializeTcpIpVisualization()
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Networking Visualizer`
    }
  }, [selectedConcept])

  // Initialize TCP/IP visualization
  const initializeTcpIpVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const routerNode = new NetworkNode("Router", "router", 400, 200)
    const serverNode = new NetworkNode("Server", "server", 700, 200)

    setNodes([clientNode, routerNode, serverNode])

    // Create a packet
    const packet = new Packet(1, "Client", "Server", "Hello, Server!", "TCP/IP")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("TCP/IP: Data travels through multiple protocol layers before transmission.")
  }

  // Initialize HTTP visualization
  const initializeHttpVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const serverNode = new NetworkNode("Server", "server", 700, 200)

    setNodes([clientNode, serverNode])

    // Create request and response packets
    const requestPacket = new Packet(1, "Client", "Server", "GET /index.html HTTP/1.1", "HTTP")
    const responsePacket = new Packet(2, "Server", "Client", "HTTP/1.1 200 OK", "HTTP")

    setPackets([requestPacket, responsePacket])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("HTTP: A request-response protocol in the client-server computing model.")

    // Set request and response details
    setRequestDetails(`GET /index.html HTTP/1.1
Host: example.com
User-Agent: Mozilla/5.0
Accept: text/html
Connection: keep-alive`)

    setResponseDetails(`HTTP/1.1 200 OK
Date: ${new Date().toUTCString()}
Content-Type: text/html
Content-Length: 1234
Connection: keep-alive

<!DOCTYPE html>
<html>
<head>
  <title>Example Domain</title>
</head>
<body>
  <h1>Example Domain</h1>
  <p>This domain is for use in examples.</p>
</body>
</html>`)
  }

  // Initialize routing visualization
  const initializeRoutingVisualization = () => {
    // Create a network of nodes
    const nodes = [
      new NetworkNode("A", "router", 100, 100),
      new NetworkNode("B", "router", 300, 100),
      new NetworkNode("C", "router", 500, 100),
      new NetworkNode("D", "router", 100, 300),
      new NetworkNode("E", "router", 300, 300),
      new NetworkNode("F", "router", 500, 300),
    ]

    setNodes(nodes)

    // Create a packet
    const packet = new Packet(1, "A", "F", "Routing data", "IP")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("Routing Algorithms: Finding the optimal path through a network.")
  }

  // Initialize OSI visualization
  const initializeOsiVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const routerNode = new NetworkNode("Router", "router", 400, 200)
    const serverNode = new NetworkNode("Server", "server", 700, 200)

    setNodes([clientNode, routerNode, serverNode])

    // Create a packet
    const packet = new Packet(1, "Client", "Server", "Hello, OSI Model!", "All Layers")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("OSI Model: Seven layers from Physical to Application.")
  }

  // Initialize DNS visualization
  const initializeDnsVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const localDnsNode = new NetworkNode("Local DNS", "server", 250, 100)
    const rootDnsNode = new NetworkNode("Root DNS", "server", 400, 100)
    const tldDnsNode = new NetworkNode("TLD DNS", "server", 550, 100)
    const authDnsNode = new NetworkNode("Auth DNS", "server", 700, 200)

    setNodes([clientNode, localDnsNode, rootDnsNode, tldDnsNode, authDnsNode])

    // Create packets for DNS queries and responses
    const dnsQuery = new Packet(1, "Client", "DNS Server", "Query: example.com?", "DNS")
    const dnsResponse = new Packet(2, "DNS Server", "Client", "Response: 93.184.216.34", "DNS")

    setPackets([dnsQuery, dnsResponse])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("DNS: Domain name resolution process.")
  }

  // Initialize subnetting visualization
  const initializeSubnettingVisualization = () => {
    // Create node structure based on subnets
    const routerNode = new NetworkNode("Router", "router", 400, 150)
    const subnet1Node1 = new NetworkNode("192.168.1.1", "client", 200, 250)
    const subnet1Node2 = new NetworkNode("192.168.1.2", "client", 350, 250)
    const subnet2Node1 = new NetworkNode("192.168.2.1", "client", 450, 250)
    const subnet2Node2 = new NetworkNode("192.168.2.2", "client", 600, 250)

    setNodes([routerNode, subnet1Node1, subnet1Node2, subnet2Node1, subnet2Node2])

    // Create a packet
    const packet = new Packet(1, "Router", "192.168.2.1", "Data for Subnet 2", "IP")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("Subnetting: Networks divided into smaller subnetworks.")
  }

  // Initialize wireless visualization
  const initializeWirelessVisualization = () => {
    // Create nodes
    const apNode = new NetworkNode("Access Point", "router", 400, 150)
    const device1Node = new NetworkNode("Device 1", "client", 200, 250)
    const device2Node = new NetworkNode("Device 2", "client", 400, 300)
    const device3Node = new NetworkNode("Device 3", "client", 600, 250)

    setNodes([apNode, device1Node, device2Node, device3Node])

    // Create a packet
    const packet = new Packet(1, "Device 1", "Access Point", "Wireless Data", "802.11")
    setPackets([packet])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("Wireless Networks: Communication without physical connections.")
  }

  // Initialize socket visualization
  const initializeSocketVisualization = () => {
    // Create nodes
    const clientNode = new NetworkNode("Client", "client", 100, 200)
    const serverNode = new NetworkNode("Server", "server", 700, 200)

    setNodes([clientNode, serverNode])

    // Create packets for the socket communication
    const connectPacket = new Packet(1, "Client", "Server", "Connect()", "TCP")
    const acceptPacket = new Packet(2, "Server", "Client", "Accept()", "TCP")
    const dataPacket = new Packet(3, "Client", "Server", "Send(data)", "TCP")
    const ackPacket = new Packet(4, "Server", "Client", "Receive(data)", "TCP")

    setPackets([connectPacket, acceptPacket, dataPacket, ackPacket])

    setCurrentPacketIndex(0)
    setCurrentStep(0)
    setMessage("Socket Programming: Client-server communication basics.")
  }

  // Find the stepForward function and replace it with this improved version
  const stepForward = () => {
    if (networkTopic === "tcp-ip") {
      // TCP/IP animation
      if (currentStep < 14) {
        // Simulate one step of the animation
        const event = new Event("step")
        document.dispatchEvent(event)

        // Update packet layer
        const updatedPackets = [...packets]
        const packet = updatedPackets[currentPacketIndex]

        if (currentStep < 7) {
          // Moving down through layers
          packet.layer = 7 - currentStep
          packet.x = 100 + currentStep * 50
          packet.y = 200 + currentStep * 20

          if (currentStep === 3) {
            // At network layer, packet reaches router
            packet.status = "processing"
            const updatedNodes = [...nodes]
            updatedNodes[1].isActive = true
            setNodes(updatedNodes)
          }
        } else {
          // Moving up through layers
          packet.layer = currentStep - 7
          packet.x = 400 + (currentStep - 7) * 50
          packet.y = 340 - (currentStep - 7) * 20

          if (currentStep === 10) {
            // At network layer, packet reaches server
            packet.status = "received"
            const updatedNodes = [...nodes]
            updatedNodes[2].isActive = true
            setNodes(updatedNodes)
          }
        }

        setPackets(updatedPackets)
        setCurrentStep(currentStep + 1)

        // Update message based on layer
        const layerNames = [
          "Physical Layer",
          "Data Link Layer",
          "Network Layer",
          "Transport Layer",
          "Session Layer",
          "Presentation Layer",
          "Application Layer",
        ]

        if (currentStep < 7) {
          setMessage(`Encapsulating data at ${layerNames[6 - currentStep]}`)
        } else {
          setMessage(`Decapsulating data at ${layerNames[currentStep - 7]}`)
        }
      }
    } else if (networkTopic === "http") {
      // HTTP animation
      if (currentStep < 6) {
        const updatedPackets = [...packets]
        const updatedNodes = [...nodes]

        if (currentPacketIndex === 0) {
          // Request packet
          if (currentStep < 3) {
            // Moving from client to server
            updatedPackets[0].x = 100 + currentStep * 200
            updatedPackets[0].y = 200

            if (currentStep === 2) {
              // Packet reaches server
              updatedPackets[0].status = "received"
              updatedNodes[1].isActive = true
              setNodes(updatedNodes)
              setMessage("Server processing the HTTP request...")
            } else {
              setMessage("Sending HTTP request to server...")
            }
          } else {
            // Start response
            setCurrentPacketIndex(1)
            updatedPackets[1].x = 700
            updatedPackets[1].y = 200
            setMessage("Server sending HTTP response...")
          }
        } else {
          // Response packet
          const responseStep = currentStep - 3
          updatedPackets[1].x = 700 - responseStep * 200

          if (responseStep === 2) {
            // Response reaches client
            updatedPackets[1].status = "received"
            updatedNodes[0].isActive = true
            setNodes(updatedNodes)
            setMessage("Client received the HTTP response.")
          }
        }

        setPackets(updatedPackets)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "dns") {
      // DNS animation
      if (currentStep < 8) {
        const updatedPackets = [...packets]
        const updatedNodes = [...nodes]

        // Reset all nodes
        updatedNodes.forEach((n) => (n.isActive = false))

        // DNS lookup process animation
        if (currentStep === 0) {
          // Client to Local DNS
          updatedPackets[0].x = 100
          updatedPackets[0].y = 200
          updatedNodes[0].isActive = true
          setMessage("Client sends DNS query to Local DNS resolver...")
        } else if (currentStep === 1) {
          // Query reaches Local DNS
          updatedPackets[0].x = 250
          updatedPackets[0].y = 100
          updatedNodes[1].isActive = true
          setMessage("Local DNS resolver receives query...")
        } else if (currentStep === 2) {
          // Local DNS to Root DNS
          updatedPackets[0].x = 400
          updatedPackets[0].y = 100
          updatedNodes[2].isActive = true
          setMessage("Local DNS queries Root DNS server...")
        } else if (currentStep === 3) {
          // Root DNS to TLD DNS
          updatedPackets[0].x = 550
          updatedPackets[0].y = 100
          updatedNodes[3].isActive = true
          setMessage("Root DNS directs to TLD DNS server...")
        } else if (currentStep === 4) {
          // TLD DNS to Authoritative DNS
          updatedPackets[0].x = 700
          updatedPackets[0].y = 200
          updatedNodes[4].isActive = true
          setMessage("TLD DNS directs to Authoritative DNS server...")
        } else if (currentStep === 5) {
          // Authoritative DNS to Local DNS (response)
          setCurrentPacketIndex(1)
          updatedPackets[1].x = 700
          updatedPackets[1].y = 200
          updatedNodes[4].isActive = true
          setMessage("Authoritative DNS sends IP address to Local DNS...")
        } else if (currentStep === 6) {
          // Response back through Local DNS
          updatedPackets[1].x = 250
          updatedPackets[1].y = 100
          updatedNodes[1].isActive = true
          setMessage("Local DNS resolver receives IP address...")
        } else if (currentStep === 7) {
          // Local DNS to Client
          updatedPackets[1].x = 100
          updatedPackets[1].y = 200
          updatedNodes[0].isActive = true
          updatedPackets[1].status = "received"
          setMessage("Client receives IP address for the domain.")
        }

        setPackets(updatedPackets)
        setNodes(updatedNodes)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "routing") {
      // Routing animation
      if (currentStep < 5) {
        const updatedPackets = [...packets]
        const packet = updatedPackets[0]
        const updatedNodes = [...nodes]

        // Reset all nodes
        updatedNodes.forEach((n) => (n.isActive = false))

        // Simulate Dijkstra's algorithm path: A -> B -> E -> F
        const path = [
          { x: 100, y: 100 }, // A
          { x: 300, y: 100 }, // B
          { x: 300, y: 300 }, // E
          { x: 500, y: 300 }, // F
        ]

        if (currentStep < path.length) {
          packet.x = path[currentStep].x
          packet.y = path[currentStep].y

          // Activate current node
          const nodeIndex = ["A", "B", "E", "F"][currentStep]
          const nodeToActivate = updatedNodes.find((n) => n.id === nodeIndex)
          if (nodeToActivate) {
            nodeToActivate.isActive = true
          }

          setMessage(`Routing packet through node ${nodeIndex}...`)

          if (currentStep === path.length - 1) {
            packet.status = "received"
            setMessage("Packet has reached its destination.")
          }
        }

        setPackets(updatedPackets)
        setNodes(updatedNodes)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "osi") {
      // OSI animation
      if (currentStep < 14) {
        const updatedPackets = [...packets]
        const packet = updatedPackets[currentPacketIndex]
        const updatedNodes = [...nodes]

        // Reset all nodes
        updatedNodes.forEach((n) => (n.isActive = false))

        // OSI has 7 layers, going up and down
        if (currentStep < 7) {
          // Moving down through layers
          packet.layer = 7 - currentStep
          packet.x = 100 + currentStep * 50
          packet.y = 200 + currentStep * 20

          // Update message based on layer
          const layerNames = [
            "Physical Layer: Bits transmission",
            "Data Link Layer: Frame formatting and error detection",
            "Network Layer: Logical addressing and routing",
            "Transport Layer: End-to-end connections and reliability",
            "Session Layer: Session establishment and maintenance",
            "Presentation Layer: Data translation and encryption",
            "Application Layer: Network processes to applications",
          ]
          setMessage(`Encapsulating at ${layerNames[6 - currentStep]}`)

          if (currentStep === 3) {
            updatedNodes[1].isActive = true
          }
        } else {
          // Moving up through layers
          packet.layer = currentStep - 7
          packet.x = 400 + (currentStep - 7) * 50
          packet.y = 340 - (currentStep - 7) * 20

          // Update message based on layer
          const layerNames = [
            "Physical Layer: Receiving bits",
            "Data Link Layer: Checking frames and errors",
            "Network Layer: Evaluating destination addresses",
            "Transport Layer: Reassembling segments",
            "Session Layer: Managing session communication",
            "Presentation Layer: Translating data for application",
            "Application Layer: Delivering to application",
          ]
          setMessage(`Decapsulating at ${layerNames[currentStep - 7]}`)

          if (currentStep === 10) {
            packet.status = "received"
            updatedNodes[2].isActive = true
          }
        }

        setPackets(updatedPackets)
        setNodes(updatedNodes)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "subnetting") {
      // Subnetting animation
      if (currentStep < 4) {
        const updatedPackets = [...packets]
        const packet = updatedPackets[0]
        const updatedNodes = [...nodes]

        // Reset all nodes
        updatedNodes.forEach((n) => (n.isActive = false))

        if (currentStep === 0) {
          // Start at router
          packet.x = 400
          packet.y = 150
          updatedNodes[0].isActive = true // Router
          setMessage("Router examines destination IP address: 192.168.2.1")
        } else if (currentStep === 1) {
          // Router determines subnet
          packet.x = 400
          packet.y = 200
          updatedNodes[0].isActive = true
          setMessage("Router determines packet belongs to 192.168.2.0/24 subnet")
        } else if (currentStep === 2) {
          // Move toward destination
          packet.x = 450
          packet.y = 230
          setMessage("Router forwards packet to the 192.168.2.0/24 subnet")
        } else if (currentStep === 3) {
          // Reach destination
          packet.x = 450
          packet.y = 250
          packet.status = "received"
          updatedNodes[3].isActive = true // 192.168.2.1
          setMessage("Packet arrives at destination host 192.168.2.1")
        }

        setPackets(updatedPackets)
        setNodes(updatedNodes)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "wireless") {
      // Wireless animation
      if (currentStep < 5) {
        const updatedPackets = [...packets]
        const packet = updatedPackets[0]
        const updatedNodes = [...nodes]

        // Reset all nodes
        updatedNodes.forEach((n) => (n.isActive = false))

        if (currentStep === 0) {
          // Device 1 prepares to send
          packet.x = 200
          packet.y = 250
          updatedNodes[1].isActive = true // Device 1
          setMessage("Device 1 prepares to send wireless data")
        } else if (currentStep === 1) {
          // Device 1 sends data
          packet.x = 300
          packet.y = 200
          updatedNodes[1].isActive = true
          setMessage("Device 1 broadcasts wireless signal")
        } else if (currentStep === 2) {
          // Data reaches access point
          packet.x = 400
          packet.y = 150
          packet.status = "received"
          updatedNodes[0].isActive = true // Access Point
          setMessage("Access Point receives the wireless signal")
        } else if (currentStep === 3) {
          // Access point processes data
          packet.status = "processing"
          updatedNodes[0].isActive = true
          setMessage("Access Point processes the data packet")
        } else if (currentStep === 4) {
          // Access point forwards data
          packet.status = "sending"
          updatedNodes[0].isActive = true
          setMessage("Access Point forwards data to the network")
        }

        setPackets(updatedPackets)
        setNodes(updatedNodes)
        setCurrentStep(currentStep + 1)
      }
    } else if (networkTopic === "sockets") {
      // Socket programming animation
      if (currentStep < 8) {
        const updatedPackets = [...packets]
        const updatedNodes = [...nodes]

        // Reset node activity
        updatedNodes.forEach((n) => (n.isActive = false))

        if (currentStep === 0) {
          // Client prepares connection
          updatedNodes[0].isActive = true
          setMessage("Client: socket() - Creates a new socket")
          setCurrentPacketIndex(0)
        } else if (currentStep === 1) {
          // Client initiates connection
          updatedPackets[0].x = 100
          updatedPackets[0].y = 200
          updatedNodes[0].isActive = true
          setMessage("Client: connect() - Initiates connection to server")
        } else if (currentStep === 2) {
          // Connection request travels
          updatedPackets[0].x = 400
          updatedPackets[0].y = 200
          setMessage("TCP SYN packet travels to server")
        } else if (currentStep === 3) {
          // Server receives connection
          updatedPackets[0].x = 700
          updatedPackets[0].y = 200
          updatedPackets[0].status = "received"
          updatedNodes[1].isActive = true
          setMessage("Server: accept() - Accepts client connection")
          setCurrentPacketIndex(1)
        } else if (currentStep === 4) {
          // Server acknowledges
          updatedPackets[1].x = 700
          updatedPackets[1].y = 200
          updatedNodes[1].isActive = true
          setMessage("Server sends acknowledgment")
        } else if (currentStep === 5) {
          // Acknowledgement travels back
          updatedPackets[1].x = 400
          updatedPackets[1].y = 200
          setMessage("TCP SYN-ACK packet travels to client")
        } else if (currentStep === 6) {
          // Client receives acknowledgement
          updatedPackets[1].x = 100
          updatedPackets[1].y = 200
          updatedPackets[1].status = "received"
          updatedNodes[0].isActive = true
          setMessage("Client receives acknowledgment - Connection established")
          setCurrentPacketIndex(2)
        } else if (currentStep === 7) {
          // Connection established
          updatedNodes[0].isActive = true
          updatedNodes[1].isActive = true
          setMessage("Connection established - Ready for data transfer")
        }

        setPackets(updatedPackets)
        setNodes(updatedNodes)
        setCurrentStep(currentStep + 1)
      }
    }
  }

  // Animation loop
  // Find the useEffect for animation loop and replace it with this improved version
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          stepForward()
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, networkTopic, currentStep, currentPacketIndex, packets, nodes, speed])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (networkTopic === "tcp-ip") {
      drawTcpIpVisualization(ctx)
    } else if (networkTopic === "osi") {
      drawOsiVisualization(ctx)
    } else if (networkTopic === "http") {
      drawHttpVisualization(ctx)
    } else if (networkTopic === "dns") {
      drawDnsVisualization(ctx)
    } else if (networkTopic === "routing") {
      drawRoutingVisualization(ctx)
    } else if (networkTopic === "subnetting") {
      drawSubnettingVisualization(ctx)
    } else if (networkTopic === "wireless") {
      drawWirelessVisualization(ctx)
    } else if (networkTopic === "sockets") {
      drawSocketVisualization(ctx)
    }
  }, [networkTopic, packets, nodes, currentStep, currentPacketIndex, canvasSize, url, requestDetails, responseDetails])

  // Draw TCP/IP visualization
  const drawTcpIpVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw layer labels
    const layerNames = ["Physical", "Data Link", "Network", "Transport", "Session", "Presentation", "Application"]

    const layerHeight = 30
    const startY = height - layerHeight * 7 - 20

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"

    for (let i = 0; i < 7; i++) {
      const y = startY + i * layerHeight

      ctx.fillText(`${i + 1}. ${layerNames[i]}`, 80, y + layerHeight / 2)

      // Draw layer lines
      ctx.beginPath()
      ctx.moveTo(90, y)
      ctx.lineTo(width - 20, y)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw bottom line
    ctx.beginPath()
    ctx.moveTo(90, startY + 7 * layerHeight)
    ctx.lineTo(width - 20, startY + 7 * layerHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw nodes
    nodes.forEach((node) => {
      let nodeImage

      if (node.type === "client") {
        // Draw client
        ctx.beginPath()
        ctx.rect(node.x - 30, node.y - 40, 60, 40)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw monitor
        ctx.beginPath()
        ctx.rect(node.x - 20, node.y - 35, 40, 25)
        ctx.fillStyle = "#1a202c"
        ctx.fill()

        // Draw stand
        ctx.beginPath()
        ctx.rect(node.x - 5, node.y - 10, 10, 15)
        ctx.fillStyle = "#2d3748"
        ctx.fill()

        // Draw base
        ctx.beginPath()
        ctx.rect(node.x - 15, node.y + 5, 30, 5)
        ctx.fillStyle = "#2d3748"
        ctx.fill()
      } else if (node.type === "server") {
        // Draw server
        ctx.beginPath()
        ctx.rect(node.x - 25, node.y - 40, 50, 80)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw server details
        for (let i = 0; i < 3; i++) {
          ctx.beginPath()
          ctx.rect(node.x - 15, node.y - 30 + i * 20, 30, 10)
          ctx.fillStyle = "#1a202c"
          ctx.fill()
        }
      } else if (node.type === "router") {
        // Draw router
        ctx.beginPath()
        ctx.rect(node.x - 30, node.y - 15, 60, 30)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw antennas
        ctx.beginPath()
        ctx.moveTo(node.x - 20, node.y - 15)
        ctx.lineTo(node.x - 20, node.y - 25)
        ctx.moveTo(node.x, node.y - 15)
        ctx.lineTo(node.x, node.y - 25)
        ctx.moveTo(node.x + 20, node.y - 15)
        ctx.lineTo(node.x + 20, node.y - 25)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()
      }

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id, node.x, node.y + 30)
    })

    // Draw packets
    packets.forEach((packet) => {
      // Draw packet
      ctx.beginPath()
      ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

      if (packet.status === "sending") {
        ctx.fillStyle = "#4fd1c5"
      } else if (packet.status === "received") {
        ctx.fillStyle = "#9f7aea"
      } else if (packet.status === "processing") {
        ctx.fillStyle = "#f6ad55"
      } else {
        ctx.fillStyle = "#f87171"
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw packet label
      ctx.fillStyle = "#000000"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(`Packet ${packet.id}`, packet.x, packet.y)

      // Draw packet details
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(`Layer: ${packet.layer}`, 20, 20)
      ctx.fillText(`Protocol: ${packet.protocol}`, 20, 40)
      ctx.fillText(`Source: ${packet.source}`, 20, 60)
      ctx.fillText(`Destination: ${packet.destination}`, 20, 80)
    })
  }

  // Draw HTTP visualization
  const drawHttpVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw URL
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(`URL: ${url}`, width / 2, 20)

    // Draw nodes
    nodes.forEach((node) => {
      if (node.type === "client") {
        // Draw client
        ctx.beginPath()
        ctx.rect(node.x - 30, node.y - 40, 60, 40)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw monitor
        ctx.beginPath()
        ctx.rect(node.x - 20, node.y - 35, 40, 25)
        ctx.fillStyle = "#1a202c"
        ctx.fill()

        // Draw stand
        ctx.beginPath()
        ctx.rect(node.x - 5, node.y - 10, 10, 15)
        ctx.fillStyle = "#2d3748"
        ctx.fill()

        // Draw base
        ctx.beginPath()
        ctx.rect(node.x - 15, node.y + 5, 30, 5)
        ctx.fillStyle = "#2d3748"
        ctx.fill()
      } else if (node.type === "server") {
        // Draw server
        ctx.beginPath()
        ctx.rect(node.x - 25, node.y - 40, 50, 80)
        ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw server details
        for (let i = 0; i < 3; i++) {
          ctx.beginPath()
          ctx.rect(node.x - 15, node.y - 30 + i * 20, 30, 10)
          ctx.fillStyle = "#1a202c"
          ctx.fill()
        }
      }

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id, node.x, node.y + 50)
    })

    // Draw connection line
    ctx.beginPath()
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[1].x, nodes[1].y)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.setLineDash([5, 5])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw packets
    packets.forEach((packet, index) => {
      if ((index === 0 && currentStep < 3) || (index === 1 && currentStep >= 3)) {
        // Draw packet
        ctx.beginPath()
        ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

        if (packet.status === "sending") {
          ctx.fillStyle = index === 0 ? "#4fd1c5" : "#9f7aea"
        } else if (packet.status === "received") {
          ctx.fillStyle = index === 0 ? "#9f7aea" : "#4fd1c5"
        } else {
          ctx.fillStyle = "#f87171"
        }

        ctx.fill()
        ctx.strokeStyle = "#ffffff"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw packet label
        ctx.fillStyle = "#000000"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(index === 0 ? "Request" : "Response", packet.x, packet.y)
      }
    })

    // Draw request and response details
    if (currentStep >= 1) {
      // Draw request details
      ctx.fillStyle = "#ffffff"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      const requestLines = requestDetails.split("\n")
      for (let i = 0; i < requestLines.length; i++) {
        ctx.fillText(requestLines[i], 20, 250 + i * 15)
      }
    }

    if (currentStep >= 4) {
      // Draw response details
      ctx.fillStyle = "#ffffff"
      ctx.font = "10px monospace"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      const responseLines = responseDetails.split("\n").slice(0, 5) // Show only headers
      for (let i = 0; i < responseLines.length; i++) {
        ctx.fillText(responseLines[i], width - 300, 250 + i * 15)
      }
    }
  }

  // Draw routing visualization
  const drawRoutingVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw connections between nodes
    const connections = [
      { from: "A", to: "B" },
      { from: "B", to: "C" },
      { from: "A", to: "D" },
      { from: "B", to: "E" },
      { from: "C", to: "F" },
      { from: "D", to: "E" },
      { from: "E", to: "F" },
    ]

    connections.forEach(({ from, to }) => {
      const fromNode = nodes.find((n) => n.id === from)
      const toNode = nodes.find((n) => n.id === to)

      if (fromNode && toNode) {
        ctx.beginPath()
        ctx.moveTo(fromNode.x, fromNode.y)
        ctx.lineTo(toNode.x, toNode.y)

        // Highlight the path A -> B -> E -> F
        if ((from === "A" && to === "B") || (from === "B" && to === "E") || (from === "E" && to === "F")) {
          ctx.strokeStyle = "#9f7aea"
          ctx.lineWidth = 3
        } else {
          ctx.strokeStyle = "#4fd1c5"
          ctx.lineWidth = 1
        }

        ctx.stroke()

        // Draw distance
        const midX = (fromNode.x + toNode.x) / 2
        const midY = (fromNode.y + toNode.y) / 2
        const distance = Math.floor(
          Math.sqrt(Math.pow(toNode.x - fromNode.x, 2) + Math.pow(toNode.y - fromNode.y, 2)) / 10,
        )

        ctx.fillStyle = "#ffffff"
        ctx.font = "12px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(distance.toString(), midX, midY - 10)
      }
    })

    // Draw nodes
    nodes.forEach((node) => {
      // Draw router
      ctx.beginPath()
      ctx.arc(node.x, node.y, 20, 0, Math.PI * 2)
      ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node label
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id, node.x, node.y)
    })

    // Draw packets
    packets.forEach((packet) => {
      // Draw packet
      ctx.beginPath()
      ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

      if (packet.status === "sending") {
        ctx.fillStyle = "#4fd1c5"
      } else if (packet.status === "received") {
        ctx.fillStyle = "#9f7aea"
      } else {
        ctx.fillStyle = "#f87171"
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw packet label
      ctx.fillStyle = "#000000"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(`Packet`, packet.x, packet.y)
    })

    // Draw algorithm info
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Dijkstra's Algorithm", 20, 20)
    ctx.fillText("Shortest Path: A -> B -> E -> F", 20, 40)
    ctx.fillText("Total Distance: 12", 20, 60)
  }

  // Draw OSI visualization
  const drawOsiVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw layer labels - OSI has 7 distinct layers with specific names
    const layerNames = [
      "1. Physical",
      "2. Data Link",
      "3. Network",
      "4. Transport",
      "5. Session",
      "6. Presentation",
      "7. Application",
    ]

    const layerHeight = 30
    const startY = height - layerHeight * 7 - 20

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"

    for (let i = 0; i < 7; i++) {
      const y = startY + i * layerHeight

      ctx.fillText(layerNames[i], 80, y + layerHeight / 2)

      // Draw layer lines
      ctx.beginPath()
      ctx.moveTo(90, y)
      ctx.lineTo(width - 20, y)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw bottom line
    ctx.beginPath()
    ctx.moveTo(90, startY + 7 * layerHeight)
    ctx.lineTo(width - 20, startY + 7 * layerHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw nodes
    nodes.forEach((node) => {
      drawNetworkNode(ctx, node)
    })

    // Draw packets
    packets.forEach((packet) => {
      drawNetworkPacket(ctx, packet)
    })

    // Draw OSI-specific information
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("OSI Model Key Points:", 20, 20)
    ctx.fillText("• Created by ISO for standardization", 20, 40)
    ctx.fillText("• Conceptual model, not implementation", 20, 60)
    ctx.fillText("• Each layer has specific protocols and functions", 20, 80)
  }

  // Draw DNS visualization
  const drawDnsVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw DNS resolution steps
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(`Domain: example.com`, width / 2, 20)

    // Draw DNS hierarchy labels
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("DNS Resolution Steps:", 20, 20)
    ctx.fillText("1. Client queries local DNS resolver", 20, 40)
    ctx.fillText("2. Local DNS queries root DNS servers", 20, 60)
    ctx.fillText("3. Root DNS refers to TLD (.com) servers", 20, 80)
    ctx.fillText("4. TLD servers refer to authoritative DNS", 20, 100)
    ctx.fillText("5. Authoritative DNS provides IP address", 20, 120)

    // Draw nodes
    nodes.forEach((node) => {
      drawNetworkNode(ctx, node)
    })

    // Draw connections between DNS servers
    ctx.beginPath()
    // Client to Local DNS
    ctx.moveTo(100, 200)
    ctx.lineTo(250, 100)
    // Local DNS to Root DNS
    ctx.moveTo(250, 100)
    ctx.lineTo(400, 100)
    // Root DNS to TLD DNS
    ctx.moveTo(400, 100)
    ctx.lineTo(550, 100)
    // TLD DNS to Auth DNS
    ctx.moveTo(550, 100)
    ctx.lineTo(700, 200)

    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.setLineDash([5, 5])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw packets
    const activePacket = currentPacketIndex < packets.length ? packets[currentPacketIndex] : null
    if (activePacket) {
      drawNetworkPacket(ctx, activePacket)

      // Draw packet information
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "right"
      ctx.textBaseline = "top"
      ctx.fillText(`Packet: ${activePacket.data}`, width - 20, 20)
      ctx.fillText(`Type: ${currentPacketIndex === 0 ? "DNS Query" : "DNS Response"}`, width - 20, 40)
    }
  }

  // Draw subnetting visualization
  const drawSubnettingVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw subnet information
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("IP Subnetting Visualization", width / 2, 20)

    // Draw subnet details
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Network: 192.168.0.0/16", 20, 50)
    ctx.fillText("Subnet 1: 192.168.1.0/24", 20, 70)
    ctx.fillText("Subnet 2: 192.168.2.0/24", 20, 90)

    // Draw subnet boundaries
    // Subnet 1 boundary
    ctx.beginPath()
    ctx.rect(100, 220, 300, 60)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()
    ctx.fillStyle = "rgba(79, 209, 197, 0.1)"
    ctx.fill()

    // Subnet 2 boundary
    ctx.beginPath()
    ctx.rect(400, 220, 300, 60)
    ctx.strokeStyle = "#9f7aea"
    ctx.lineWidth = 1
    ctx.stroke()
    ctx.fillStyle = "rgba(159, 122, 234, 0.1)"
    ctx.fill()

    // Label subnets
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Subnet 1: 192.168.1.0/24", 250, 205)
    ctx.fillText("Subnet 2: 192.168.2.0/24", 550, 205)

    // Draw nodes
    nodes.forEach((node) => {
      drawNetworkNode(ctx, node)
    })

    // Draw connections to router
    ctx.beginPath()
    // Router to Subnet 1 devices
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[1].x, nodes[1].y)
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[2].x, nodes[2].y)

    // Router to Subnet 2 devices
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[3].x, nodes[3].y)
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[4].x, nodes[4].y)

    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw packets
    packets.forEach((packet) => {
      drawNetworkPacket(ctx, packet)
    })
  }

  // Draw wireless visualization
  const drawWirelessVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw wireless network information
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Wireless Network Visualization", width / 2, 20)

    // Draw access point coverage (signal radius)
    ctx.beginPath()
    ctx.arc(nodes[0].x, nodes[0].y, 150, 0, Math.PI * 2)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.setLineDash([2, 2])
    ctx.stroke()
    ctx.fillStyle = "rgba(79, 209, 197, 0.05)"
    ctx.fill()
    ctx.setLineDash([])

    // Draw wireless waves from active nodes
    nodes.forEach((node, index) => {
      if (node.isActive && node.type === "client") {
        // Draw wireless waves
        for (let i = 1; i <= 3; i++) {
          ctx.beginPath()
          ctx.arc(node.x, node.y, i * 15, 0, Math.PI * 2)
          ctx.strokeStyle = "#9f7aea"
          ctx.lineWidth = 1
          ctx.setLineDash([2, 2])
          ctx.stroke()
          ctx.setLineDash([])
        }
      }
    })

    // Draw nodes
    nodes.forEach((node) => {
      drawNetworkNode(ctx, node)
    })

    // Draw packets
    packets.forEach((packet) => {
      drawNetworkPacket(ctx, packet)
    })

    // Draw wireless information
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Wireless Standards:", 20, 50)
    ctx.fillText("• IEEE 802.11a/b/g/n/ac/ax (Wi-Fi)", 20, 70)
    ctx.fillText("• 2.4 GHz and 5 GHz bands", 20, 90)
    ctx.fillText("• Security: WPA2, WPA3", 20, 110)
  }

  // Draw socket visualization
  const drawSocketVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw socket programming information
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Socket Programming Visualization", width / 2, 20)

    // Draw connection between client and server
    ctx.beginPath()
    ctx.moveTo(nodes[0].x, nodes[0].y)
    ctx.lineTo(nodes[1].x, nodes[1].y)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.setLineDash([5, 5])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw nodes
    nodes.forEach((node) => {
      drawNetworkNode(ctx, node)
    })

    // Draw socket code examples
    ctx.fillStyle = "#ffffff"
    ctx.font = "10px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"

    // Client side code
    ctx.fillText("// Client socket code", 50, 260)
    ctx.fillText("socket = new Socket();", 50, 280)
    ctx.fillText("socket.connect(serverIP, port);", 50, 295)
    ctx.fillText("socket.send(data);", 50, 310)
    ctx.fillText("response = socket.receive();", 50, 325)
    ctx.fillText("socket.close();", 50, 340)

    // Server side code
    ctx.fillText("// Server socket code", 580, 260)
    ctx.fillText("serverSocket = new ServerSocket(port);", 580, 280)
    ctx.fillText("socket = serverSocket.accept();", 580, 295)
    ctx.fillText("data = socket.receive();", 580, 310)
    ctx.fillText("socket.send(response);", 580, 325)
    ctx.fillText("socket.close();", 580, 340)

    // Draw packets if in the appropriate step
    if (currentStep >= 1 && currentStep <= 7) {
      const packet = packets[currentPacketIndex]
      if (packet) {
        drawNetworkPacket(ctx, packet)
      }
    }
  }

  // Helper function to draw network nodes
  const drawNetworkNode = (ctx: CanvasRenderingContext2D, node: NetworkNode) => {
    if (node.type === "client") {
      // Draw client
      ctx.beginPath()
      ctx.rect(node.x - 30, node.y - 40, 60, 40)
      ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw monitor
      ctx.beginPath()
      ctx.rect(node.x - 20, node.y - 35, 40, 25)
      ctx.fillStyle = "#1a202c"
      ctx.fill()

      // Draw stand
      ctx.beginPath()
      ctx.rect(node.x - 5, node.y - 10, 10, 15)
      ctx.fillStyle = "#2d3748"
      ctx.fill()

      // Draw base
      ctx.beginPath()
      ctx.rect(node.x - 15, node.y + 5, 30, 5)
      ctx.fillStyle = "#2d3748"
      ctx.fill()
    } else if (node.type === "server") {
      // Draw server
      ctx.beginPath()
      ctx.rect(node.x - 25, node.y - 40, 50, 80)
      ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw server details
      for (let i = 0; i < 3; i++) {
        ctx.beginPath()
        ctx.rect(node.x - 15, node.y - 30 + i * 20, 30, 10)
        ctx.fillStyle = "#1a202c"
        ctx.fill()
      }
    } else if (node.type === "router") {
      // Draw router
      ctx.beginPath()
      ctx.rect(node.x - 30, node.y - 15, 60, 30)
      ctx.fillStyle = node.isActive ? "#9f7aea" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw antennas
      ctx.beginPath()
      ctx.moveTo(node.x - 20, node.y - 15)
      ctx.lineTo(node.x - 20, node.y - 25)
      ctx.moveTo(node.x, node.y - 15)
      ctx.lineTo(node.x, node.y - 25)
      ctx.moveTo(node.x + 20, node.y - 15)
      ctx.lineTo(node.x + 20, node.y - 25)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()
    }

    // Draw node label
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(node.id, node.x, node.y + 30)
  }

  // Helper function to draw network packets
  const drawNetworkPacket = (ctx: CanvasRenderingContext2D, packet: Packet) => {
    // Draw packet
    ctx.beginPath()
    ctx.rect(packet.x - 15, packet.y - 10, 30, 20)

    if (packet.status === "sending") {
      ctx.fillStyle = "#4fd1c5"
    } else if (packet.status === "received") {
      ctx.fillStyle = "#9f7aea"
    } else if (packet.status === "processing") {
      ctx.fillStyle = "#f6ad55"
    } else {
      ctx.fillStyle = "#f87171"
    }

    ctx.fill()
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw packet label
    ctx.fillStyle = "#000000"
    ctx.font = "10px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(`Packet ${packet.id}`, packet.x, packet.y)
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setIsPlaying(false)
    setCurrentStep(0)
    setCurrentPacketIndex(0)

    if (networkTopic === "tcp-ip") {
      initializeTcpIpVisualization()
    } else if (networkTopic === "http") {
      initializeHttpVisualization()
    } else if (networkTopic === "routing") {
      initializeRoutingVisualization()
    }
  }

  // Handle URL change
  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value)
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={stepForward}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Network Topic</h3>
                    <Tabs
                      defaultValue="tcp-ip"
                      value={networkTopic}
                      onValueChange={(value) => {
                        setNetworkTopic(value)
                        resetAnimation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="tcp-ip">TCP/IP</TabsTrigger>
                        <TabsTrigger value="http">HTTP/DNS</TabsTrigger>
                        <TabsTrigger value="routing">Routing</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {networkTopic === "http" && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-400 mb-3">URL</h3>
                      <Input
                        value={url}
                        onChange={handleUrlChange}
                        placeholder="Enter URL"
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                    </div>
                  )}

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Network Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {networkTopic === "tcp-ip" ? (
                        <>
                          <p>The TCP/IP protocol suite consists of four layers:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Application Layer: HTTP, FTP, SMTP, DNS</li>
                            <li>Transport Layer: TCP, UDP</li>
                            <li>Internet Layer: IP, ICMP, ARP</li>
                            <li>Link Layer: Ethernet, Wi-Fi, PPP</li>
                          </ul>
                          <p className="mt-2">
                            Data encapsulation occurs as information travels down the layers, with each layer adding its
                            own header information.
                          </p>
                        </>
                      ) : networkTopic === "http" ? (
                        <>
                          <p>HTTP (Hypertext Transfer Protocol) is a request-response protocol:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Client sends a request to the server</li>
                            <li>Server processes the request</li>
                            <li>Server sends a response back to the client</li>
                            <li>Common methods: GET, POST, PUT, DELETE</li>
                            <li>Status codes: 200 OK, 404 Not Found, 500 Server Error</li>
                          </ul>
                        </>
                      ) : (
                        <>
                          <p>Routing algorithms determine the path data takes through a network:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Dijkstra's Algorithm: Finds the shortest path</li>
                            <li>Distance Vector: Routers share information with neighbors</li>
                            <li>Link State: Routers build a map of the entire network</li>
                            <li>Path Vector: Used in BGP for internet routing</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="networking" title="Networking" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
