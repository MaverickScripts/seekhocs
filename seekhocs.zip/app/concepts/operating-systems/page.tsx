"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, Plus, Minus } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import Footer from "@/components/footer"
import { useSearchParams } from "next/navigation"

// Process class
class Process {
  id: number
  name: string
  burstTime: number
  remainingTime: number
  arrivalTime: number
  startTime: number
  finishTime: number
  color: string
  state: "ready" | "running" | "waiting" | "terminated"
  x: number
  y: number

  constructor(id: number, name: string, burstTime: number, arrivalTime: number) {
    this.id = id
    this.name = name
    this.burstTime = burstTime
    this.remainingTime = burstTime
    this.arrivalTime = arrivalTime
    this.startTime = -1
    this.finishTime = -1
    this.color = this.getRandomColor()
    this.state = "ready"
    this.x = 0
    this.y = 0
  }

  getRandomColor() {
    const colors = [
      "#4fd1c5",
      "#9f7aea",
      "#f687b3",
      "#68d391",
      "#f6ad55",
      "#63b3ed",
      "#fc8181",
      "#b794f4",
      "#4fd1c5",
      "#f6e05e",
    ]
    return colors[this.id % colors.length]
  }
}

export default function OperatingSystemsPage() {
  // Add the missing searchParams declaration at the top of the component
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")
  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(50)
  const [currentTime, setCurrentTime] = useState(0)
  const [algorithm, setAlgorithm] = useState("fcfs")
  const [processes, setProcesses] = useState<Process[]>([])
  const [currentProcess, setCurrentProcess] = useState<Process | null>(null)
  const [quantum, setQuantum] = useState(2)
  const [message, setMessage] = useState("CPU Scheduler Visualization")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })

  // Initialize processes
  useEffect(() => {
    resetSimulation()

    // Set canvas size
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [algorithm])

  // Add this useEffect after the existing useEffect for initializing processes:
  useEffect(() => {
    if (selectedConcept) {
      // Reset simulation state
      setCurrentTime(0)
      setIsPlaying(false)

      // Set algorithm based on selected concept
      if (selectedConcept.toLowerCase().includes("round robin") || selectedConcept.toLowerCase().includes("rr")) {
        setAlgorithm("rr")
        setMessage("Round Robin Scheduling: Each process is assigned a fixed time slice in a cyclic way.")
      } else if (
        selectedConcept.toLowerCase().includes("shortest job") ||
        selectedConcept.toLowerCase().includes("sjf")
      ) {
        setAlgorithm("sjf")
        setMessage("Shortest Job First: The process with the smallest execution time is selected for execution next.")
      } else if (
        selectedConcept.toLowerCase().includes("first come") ||
        selectedConcept.toLowerCase().includes("fcfs")
      ) {
        setAlgorithm("fcfs")
        setMessage("First-Come, First-Served: Processes are executed in the order they arrive in the ready queue.")
      } else if (
        selectedConcept.toLowerCase().includes("process") ||
        selectedConcept.toLowerCase().includes("thread")
      ) {
        // Default to FCFS for process/thread management concepts
        setAlgorithm("fcfs")

        if (selectedConcept.toLowerCase().includes("thread")) {
          setMessage(
            "Thread Management: Threads are the smallest sequence of programmed instructions that can be managed independently by a scheduler.",
          )
        } else {
          setMessage(
            "Process Management: Processes are instances of executing programs that are managed by the operating system.",
          )
        }
      } else if (selectedConcept.toLowerCase().includes("memory")) {
        // Default to FCFS for memory management concepts
        setAlgorithm("fcfs")
        setMessage(
          "Memory Management: The act of managing computer memory, including allocation, deallocation, and tracking.",
        )
      } else if (selectedConcept.toLowerCase().includes("deadlock")) {
        setAlgorithm("fcfs")
        setMessage(
          "Deadlocks: A situation where two or more processes are unable to proceed because each is waiting for resources held by another.",
        )
      } else if (
        selectedConcept.toLowerCase().includes("synchronization") ||
        selectedConcept.toLowerCase().includes("concurrency")
      ) {
        setAlgorithm("rr") // Using RR for concurrency visualization

        if (selectedConcept.toLowerCase().includes("synchronization")) {
          setMessage("Synchronization: Mechanisms to control the access of multiple processes to shared resources.")
        } else {
          setMessage("Concurrency Control: Ensuring correct results for concurrent operations on shared data.")
        }
      } else if (selectedConcept.toLowerCase().includes("file") || selectedConcept.toLowerCase().includes("i/o")) {
        setAlgorithm("fcfs")

        if (selectedConcept.toLowerCase().includes("file")) {
          setMessage(
            "File Systems: Methods and data structures that an operating system uses to keep track of files on a disk.",
          )
        } else {
          setMessage("I/O Management: Managing input/output operations between the CPU and peripheral devices.")
        }
      } else {
        // Default to FCFS for other concepts
        setAlgorithm("fcfs")
        setMessage("CPU Scheduling: Determining which process runs on the CPU when there are multiple ready processes.")
      }

      // Reset the simulation with new parameters
      resetSimulation()
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Operating Systems Visualizer`
    }
  }, [selectedConcept])

  // Reset simulation
  const resetSimulation = () => {
    // Create sample processes
    const newProcesses = [
      new Process(0, "P1", 6, 0),
      new Process(1, "P2", 4, 1),
      new Process(2, "P3", 8, 2),
      new Process(3, "P4", 3, 3),
      new Process(4, "P5", 5, 4),
    ]

    // Calculate positions
    calculateProcessPositions(newProcesses)

    setProcesses(newProcesses)
    setCurrentProcess(null)
    setCurrentTime(0)
    setIsPlaying(false)

    // Set message based on algorithm
    if (algorithm === "fcfs") {
      setMessage("First-Come, First-Served (FCFS) Scheduling")
    } else if (algorithm === "sjf") {
      setMessage("Shortest Job First (SJF) Scheduling")
    } else if (algorithm === "rr") {
      setMessage("Round Robin (RR) Scheduling with Quantum = " + quantum)
    }
  }

  // Calculate process positions
  const calculateProcessPositions = (procs: Process[]) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Position processes in a circle
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) * 0.3

    procs.forEach((process, index) => {
      const angle = (index / procs.length) * Math.PI * 2
      process.x = centerX + radius * Math.cos(angle)
      process.y = centerY + radius * Math.sin(angle)
    })
  }

  // Simulation step
  const simulationStep = () => {
    // Clone processes to avoid direct state mutation
    const updatedProcesses = [...processes]
    let updatedCurrentProcess = currentProcess
    let nextProcess: Process | null = null

    // Update current time
    const newTime = currentTime + 1
    setCurrentTime(newTime)

    // Check if we need to select a new process
    if (!updatedCurrentProcess || updatedCurrentProcess.remainingTime <= 0) {
      // Current process is finished
      if (updatedCurrentProcess) {
        const index = updatedProcesses.findIndex((p) => p.id === updatedCurrentProcess!.id)
        if (index !== -1) {
          updatedProcesses[index].state = "terminated"
          updatedProcesses[index].finishTime = currentTime
        }
      }

      // Select next process based on algorithm
      if (algorithm === "fcfs") {
        // First-Come, First-Served
        nextProcess =
          updatedProcesses
            .filter((p) => p.state !== "terminated" && p.arrivalTime <= newTime)
            .sort((a, b) => a.arrivalTime - b.arrivalTime)[0] || null
      } else if (algorithm === "sjf") {
        // Shortest Job First
        nextProcess =
          updatedProcesses
            .filter((p) => p.state !== "terminated" && p.arrivalTime <= newTime)
            .sort((a, b) => a.remainingTime - b.remainingTime)[0] || null
      } else if (algorithm === "rr") {
        // Round Robin
        if (updatedCurrentProcess) {
          // If quantum is reached or process is finished
          const remainingProcesses = updatedProcesses.filter(
            (p) => p.state !== "terminated" && p.arrivalTime <= newTime,
          )
          if (remainingProcesses.length > 0) {
            const currentIndex = remainingProcesses.findIndex((p) => p.id === updatedCurrentProcess!.id)
            const nextIndex = (currentIndex + 1) % remainingProcesses.length
            nextProcess = remainingProcesses[nextIndex]
          }
        } else {
          // Initial selection
          nextProcess =
            updatedProcesses
              .filter((p) => p.state !== "terminated" && p.arrivalTime <= newTime)
              .sort((a, b) => a.arrivalTime - b.arrivalTime)[0] || null
        }
      }

      // Update process states
      if (nextProcess) {
        // Set new process to running
        const index = updatedProcesses.findIndex((p) => p.id === nextProcess!.id)
        if (index !== -1) {
          updatedProcesses[index].state = "running"
          if (updatedProcesses[index].startTime === -1) {
            updatedProcesses[index].startTime = newTime
          }
        }

        // Set message
        setMessage(`Time ${newTime}: Process ${nextProcess.name} is running`)
      } else {
        // No process to run
        setMessage(`Time ${newTime}: CPU idle`)
      }

      updatedCurrentProcess = nextProcess
    } else {
      // Continue with current process
      const index = updatedProcesses.findIndex((p) => p.id === updatedCurrentProcess!.id)
      if (index !== -1) {
        updatedProcesses[index].remainingTime--

        // Check if process is finished
        if (updatedProcesses[index].remainingTime <= 0) {
          updatedProcesses[index].state = "terminated"
          updatedProcesses[index].finishTime = newTime
          setMessage(`Time ${newTime}: Process ${updatedProcesses[index].name} completed`)
        } else {
          setMessage(
            `Time ${newTime}: Process ${updatedProcesses[index].name} is running (${updatedProcesses[index].remainingTime} units left)`,
          )
        }
      }
    }

    // Update states
    setProcesses(updatedProcesses)
    setCurrentProcess(updatedCurrentProcess)

    // Check if all processes are terminated
    if (updatedProcesses.every((p) => p.state === "terminated")) {
      setIsPlaying(false)
      setMessage(`Simulation completed at time ${newTime}`)
    }
  }

  // Animation loop
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          simulationStep()
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, currentTime, processes, currentProcess, speed, algorithm, quantum])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw timeline
    drawTimeline(ctx)

    // Draw processes
    drawProcesses(ctx)

    // Draw connections
    drawConnections(ctx)

    // Draw CPU
    drawCPU(ctx)
  }, [processes, currentProcess, currentTime, canvasSize])

  // Draw timeline
  const drawTimeline = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw timeline
    const timelineY = height * 0.8
    const timelineLength = width * 0.8
    const timelineStart = width * 0.1

    ctx.beginPath()
    ctx.moveTo(timelineStart, timelineY)
    ctx.lineTo(timelineStart + timelineLength, timelineY)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw time markers
    const maxTime = Math.max(20, currentTime + 5)
    const timeStep = timelineLength / maxTime

    for (let t = 0; t <= maxTime; t += 5) {
      const x = timelineStart + t * timeStep

      ctx.beginPath()
      ctx.moveTo(x, timelineY - 5)
      ctx.lineTo(x, timelineY + 5)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      ctx.fillStyle = "#ffffff"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText(t.toString(), x, timelineY + 10)
    }

    // Draw current time marker
    const currentX = timelineStart + currentTime * timeStep

    ctx.beginPath()
    ctx.moveTo(currentX, timelineY - 15)
    ctx.lineTo(currentX, timelineY + 15)
    ctx.strokeStyle = "#9f7aea"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw process execution blocks
    const blockHeight = 20

    processes.forEach((process, index) => {
      if (process.startTime !== -1) {
        const startX = timelineStart + process.startTime * timeStep
        const endX =
          process.finishTime !== -1
            ? timelineStart + process.finishTime * timeStep
            : timelineStart + currentTime * timeStep
        const blockY = timelineY - blockHeight - index * (blockHeight + 5)

        ctx.beginPath()
        ctx.rect(startX, blockY, endX - startX, blockHeight)
        ctx.fillStyle = process.color
        ctx.fill()
        ctx.strokeStyle = "#ffffff"
        ctx.lineWidth = 1
        ctx.stroke()

        ctx.fillStyle = "#000000"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(process.name, (startX + endX) / 2, blockY + blockHeight / 2)
      }
    })
  }

  // Draw processes
  const drawProcesses = (ctx: CanvasRenderingContext2D) => {
    processes.forEach((process) => {
      // Draw process circle
      ctx.beginPath()
      ctx.arc(process.x, process.y, 25, 0, Math.PI * 2)

      // Fill based on state
      if (process.state === "running") {
        ctx.fillStyle = process.color
        ctx.shadowColor = process.color
        ctx.shadowBlur = 15
      } else if (process.state === "terminated") {
        ctx.fillStyle = "#2d3748"
      } else {
        ctx.fillStyle = process.color
        ctx.globalAlpha = 0.7
      }

      ctx.fill()
      ctx.globalAlpha = 1.0
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 2
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw process name
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(process.name, process.x, process.y - 5)

      // Draw remaining time
      if (process.state !== "terminated") {
        ctx.fillStyle = "#ffffff"
        ctx.font = "10px Arial"
        ctx.fillText(process.remainingTime.toString(), process.x, process.y + 10)
      } else {
        ctx.fillStyle = "#ffffff"
        ctx.font = "10px Arial"
        ctx.fillText("Done", process.x, process.y + 10)
      }
    })
  }

  // Draw connections
  const drawConnections = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw connection from current process to CPU
    if (currentProcess) {
      const cpuX = width / 2
      const cpuY = height * 0.4

      ctx.beginPath()
      ctx.moveTo(currentProcess.x, currentProcess.y)
      ctx.lineTo(cpuX, cpuY)
      ctx.strokeStyle = currentProcess.color
      ctx.lineWidth = 3
      ctx.shadowColor = currentProcess.color
      ctx.shadowBlur = 10
      ctx.stroke()
      ctx.shadowBlur = 0
    }
  }

  // Draw CPU
  const drawCPU = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    const cpuX = width / 2 - 40
    const cpuY = height * 0.4 - 20
    const cpuWidth = 80
    const cpuHeight = 40

    // Draw CPU
    ctx.beginPath()
    ctx.rect(cpuX, cpuY, cpuWidth, cpuHeight)

    if (currentProcess) {
      ctx.fillStyle = currentProcess.color
      ctx.shadowColor = currentProcess.color
      ctx.shadowBlur = 15
    } else {
      ctx.fillStyle = "#2d3748"
    }

    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Reset shadow
    ctx.shadowBlur = 0

    // Draw CPU label
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("CPU", width / 2, height * 0.4)
  }

  // Start simulation
  const startSimulation = () => {
    setIsPlaying(true)
  }

  // Pause simulation
  const pauseSimulation = () => {
    setIsPlaying(false)
  }

  // Add a new process
  const addProcess = () => {
    const id = processes.length
    const name = `P${id + 1}`
    const burstTime = Math.floor(Math.random() * 8) + 2 // 2-10
    const arrivalTime = currentTime

    const newProcess = new Process(id, name, burstTime, arrivalTime)

    // Calculate position
    const updatedProcesses = [...processes, newProcess]
    calculateProcessPositions(updatedProcesses)

    setProcesses(updatedProcesses)
    setMessage(`Added new process ${name} with burst time ${burstTime}`)
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Operating Systems Visualizer
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Explore CPU scheduling algorithms and process management
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">CPU Scheduler Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetSimulation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseSimulation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startSimulation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Scheduler Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Scheduling Algorithm</h3>
                    <Tabs
                      defaultValue="fcfs"
                      value={algorithm}
                      onValueChange={(value) => {
                        setAlgorithm(value)
                        resetSimulation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="fcfs">FCFS</TabsTrigger>
                        <TabsTrigger value="sjf">SJF</TabsTrigger>
                        <TabsTrigger value="rr">Round Robin</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {algorithm === "rr" && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-400 mb-3">Time Quantum</h3>
                      <div className="flex items-center space-x-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setQuantum(Math.max(1, quantum - 1))}
                          className="border-gray-700"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="text-center font-mono text-cyan-400 w-8">{quantum}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setQuantum(quantum + 1)}
                          className="border-gray-700"
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Process Management</h3>
                    <Button onClick={addProcess} className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">
                      <Plus className="h-4 w-4 mr-2" />
                      Add New Process
                    </Button>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Algorithm Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {algorithm === "fcfs" ? (
                        <>
                          <p>First-Come, First-Served (FCFS) is the simplest scheduling algorithm:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Processes are executed in the order they arrive</li>
                            <li>Non-preemptive: once a process starts, it runs until completion</li>
                            <li>Easy to implement but can lead to the "convoy effect"</li>
                          </ul>
                        </>
                      ) : algorithm === "sjf" ? (
                        <>
                          <p>Shortest Job First (SJF) prioritizes shorter processes:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Selects the process with the smallest burst time</li>
                            <li>Non-preemptive: once a process starts, it runs until completion</li>
                            <li>Optimal for minimizing average waiting time</li>
                            <li>Difficult to implement as burst time is not known in advance</li>
                          </ul>
                        </>
                      ) : (
                        <>
                          <p>Round Robin (RR) uses time slices to ensure fairness:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Each process gets a small unit of CPU time (quantum)</li>
                            <li>Preemptive: process is switched after its time quantum expires</li>
                            <li>Good for time-sharing systems</li>
                            <li>Performance depends on the size of the time quantum</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

