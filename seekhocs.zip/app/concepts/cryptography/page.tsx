"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, Key, RefreshCw } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import ParticleBackground from "@/components/particle-background"
import Footer from "@/components/footer"
import { useSearchParams } from "next/navigation"

export default function CryptographyPage() {
  // Add the missing searchParams declaration at the top of the component
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")
  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(50)
  const [algorithm, setAlgorithm] = useState("caesar")
  const [plaintext, setPlaintext] = useState("HELLO WORLD")
  const [key, setKey] = useState("3")
  const [ciphertext, setCiphertext] = useState("")
  const [step, setStep] = useState(0)
  const [message, setMessage] = useState("Encryption Visualization")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Add this useEffect after the existing useEffect for setting canvas size:
  useEffect(() => {
    if (selectedConcept) {
      // Reset visualization state
      setStep(0)
      setIsPlaying(false)
      setCiphertext("")

      // Set algorithm based on selected concept
      if (selectedConcept.toLowerCase().includes("caesar")) {
        setAlgorithm("caesar")
        setKey("3")
        setMessage(
          "Caesar Cipher: A substitution cipher where each letter is shifted a fixed number of places down the alphabet.",
        )
      } else if (
        selectedConcept.toLowerCase().includes("vigenère") ||
        selectedConcept.toLowerCase().includes("vigenere")
      ) {
        setAlgorithm("vigenere")
        setKey("KEY")
        setMessage(
          "Vigenère Cipher: A method of encrypting text using a series of interwoven Caesar ciphers based on a keyword.",
        )
      } else if (
        selectedConcept.toLowerCase().includes("rsa") ||
        selectedConcept.toLowerCase().includes("public key")
      ) {
        setAlgorithm("rsa")
        setKey("65537")
        setMessage(
          "RSA Algorithm: A public-key cryptosystem used for secure data transmission based on the factorization of large prime numbers.",
        )
      } else if (
        selectedConcept.toLowerCase().includes("aes") ||
        selectedConcept.toLowerCase().includes("des") ||
        selectedConcept.toLowerCase().includes("symmetric")
      ) {
        // Use Caesar as a placeholder for symmetric encryption
        setAlgorithm("caesar")
        setKey("8")

        if (selectedConcept.toLowerCase().includes("aes")) {
          setMessage(
            "AES Encryption: Advanced Encryption Standard, a specification for the encryption of electronic data.",
          )
        } else if (selectedConcept.toLowerCase().includes("des")) {
          setMessage(
            "DES Encryption: Data Encryption Standard, a symmetric-key algorithm for the encryption of digital data.",
          )
        } else {
          setMessage("Symmetric Encryption: Encryption where the same key is used for both encryption and decryption.")
        }
      } else if (
        selectedConcept.toLowerCase().includes("diffie") ||
        selectedConcept.toLowerCase().includes("key exchange")
      ) {
        setAlgorithm("rsa") // Using RSA as placeholder
        setMessage(
          "Diffie-Hellman Key Exchange: A method of securely exchanging cryptographic keys over a public channel.",
        )
      } else if (selectedConcept.toLowerCase().includes("elliptic")) {
        setAlgorithm("rsa") // Using RSA as placeholder
        setMessage(
          "Elliptic Curve Cryptography: An approach to public-key cryptography based on the algebraic structure of elliptic curves over finite fields.",
        )
      } else if (
        selectedConcept.toLowerCase().includes("hash") ||
        selectedConcept.toLowerCase().includes("digital signature")
      ) {
        setAlgorithm("rsa") // Using RSA as placeholder

        if (selectedConcept.toLowerCase().includes("hash")) {
          setMessage(
            "Hash Functions: Functions that map data of arbitrary size to fixed-size values, used for data integrity verification.",
          )
        } else {
          setMessage(
            "Digital Signatures: A mathematical scheme for verifying the authenticity of digital messages or documents.",
          )
        }
      } else {
        // Default to Caesar for other concepts
        setAlgorithm("caesar")
        setKey("3")
        setMessage(
          "Cryptography: The practice and study of techniques for secure communication in the presence of adversaries.",
        )
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Cryptography Visualizer`
    }
  }, [selectedConcept])

  // Reset visualization
  const resetVisualization = () => {
    setStep(0)
    setIsPlaying(false)
    setCiphertext("")

    // Set message based on algorithm
    if (algorithm === "caesar") {
      setMessage("Caesar Cipher: Shift each letter by a fixed number of positions")
    } else if (algorithm === "vigenere") {
      setMessage("Vigenère Cipher: Use a keyword to determine shift for each letter")
    } else if (algorithm === "rsa") {
      setMessage("RSA: Public-key cryptography using modular exponentiation")
    }
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Animation step
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          if (step < plaintext.length) {
            setStep((prevStep) => prevStep + 1)

            // Update ciphertext
            if (algorithm === "caesar") {
              const shift = Number.parseInt(key) || 3
              const encrypted = encryptCaesar(plaintext.substring(0, step + 1), shift)
              setCiphertext(encrypted)
              setMessage(`Encrypting character: ${plaintext[step]} → ${encrypted[step]}`)
            } else if (algorithm === "vigenere") {
              const encrypted = encryptVigenere(plaintext.substring(0, step + 1), key)
              setCiphertext(encrypted)
              const keyChar = key[step % key.length]
              setMessage(
                `Encrypting with key character: ${keyChar} (shift ${keyChar.charCodeAt(0) - 65}), ${plaintext[step]} → ${encrypted[step]}`,
              )
            } else if (algorithm === "rsa") {
              // Simplified RSA for visualization
              const encrypted = encryptRSA(plaintext.substring(0, step + 1))
              setCiphertext(encrypted)
              setMessage(`Encrypting character: ${plaintext[step]} → ${encrypted[step]}`)
            }
          } else {
            setIsPlaying(false)
            setMessage("Encryption complete!")
          }
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, step, plaintext, key, algorithm, speed])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (algorithm === "caesar") {
      drawCaesarCipher(ctx)
    } else if (algorithm === "vigenere") {
      drawVigenereCipher(ctx)
    } else if (algorithm === "rsa") {
      drawRSA(ctx)
    }
  }, [algorithm, step, plaintext, key, ciphertext, canvasSize])

  // Draw Caesar Cipher
  const drawCaesarCipher = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw alphabet wheel
    const centerX = width / 2
    const centerY = height / 2
    const outerRadius = Math.min(width, height) * 0.35
    const innerRadius = outerRadius - 30

    // Draw outer wheel (plaintext)
    ctx.beginPath()
    ctx.arc(centerX, centerY, outerRadius, 0, Math.PI * 2)
    ctx.fillStyle = "#1a202c"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw inner wheel (ciphertext)
    ctx.beginPath()
    ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2)
    ctx.fillStyle = "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#9f7aea"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw alphabet letters
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const shift = Number.parseInt(key) || 3

    for (let i = 0; i < 26; i++) {
      const angle = (i / 26) * Math.PI * 2

      // Outer wheel letter (plaintext)
      const outerX = centerX + Math.cos(angle) * (outerRadius - 15)
      const outerY = centerY + Math.sin(angle) * (outerRadius - 15)

      ctx.fillStyle = "#ffffff"
      ctx.font = "14px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(alphabet[i], outerX, outerY)

      // Inner wheel letter (ciphertext)
      const shiftedIndex = (i + shift) % 26
      const innerX = centerX + Math.cos(angle) * (innerRadius - 15)
      const innerY = centerY + Math.sin(angle) * (innerRadius - 15)

      ctx.fillStyle = "#ffffff"
      ctx.fillText(alphabet[shiftedIndex], innerX, innerY)
    }

    // Draw current character being encrypted
    if (step < plaintext.length) {
      const char = plaintext[step].toUpperCase()

      if (char >= "A" && char <= "Z") {
        const charIndex = char.charCodeAt(0) - 65
        const angle = (charIndex / 26) * Math.PI * 2

        // Highlight plaintext character
        const outerX = centerX + Math.cos(angle) * (outerRadius - 15)
        const outerY = centerY + Math.sin(angle) * (outerRadius - 15)

        ctx.beginPath()
        ctx.arc(outerX, outerY, 15, 0, Math.PI * 2)
        ctx.fillStyle = "#4fd1c5"
        ctx.fill()

        ctx.fillStyle = "#000000"
        ctx.fillText(char, outerX, outerY)

        // Highlight ciphertext character
        const shiftedIndex = (charIndex + shift) % 26
        const shiftedChar = String.fromCharCode(65 + shiftedIndex)
        const innerX = centerX + Math.cos(angle) * (innerRadius - 15)
        const innerY = centerY + Math.sin(angle) * (innerRadius - 15)

        ctx.beginPath()
        ctx.arc(innerX, innerY, 15, 0, Math.PI * 2)
        ctx.fillStyle = "#9f7aea"
        ctx.fill()

        ctx.fillStyle = "#000000"
        ctx.fillText(shiftedChar, innerX, innerY)

        // Draw arrow
        ctx.beginPath()
        ctx.moveTo(outerX, outerY)
        ctx.lineTo(innerX, innerY)
        ctx.strokeStyle = "#f6ad55"
        ctx.lineWidth = 2
        ctx.stroke()
      }
    }

    // Draw text boxes
    drawTextBoxes(ctx)
  }

  // Draw Vigenere Cipher
  const drawVigenereCipher = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw Vigenère table
    const cellSize = Math.min(15, width / 30)
    const tableX = (width - 26 * cellSize) / 2
    const tableY = height * 0.2

    // Draw table header
    ctx.fillStyle = "#4fd1c5"
    ctx.fillRect(tableX, tableY, cellSize, cellSize)

    for (let i = 0; i < 26; i++) {
      // Column headers
      ctx.fillStyle = "#4fd1c5"
      ctx.fillRect(tableX + (i + 1) * cellSize, tableY, cellSize, cellSize)

      ctx.fillStyle = "#000000"
      ctx.font = "10px monospace"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(String.fromCharCode(65 + i), tableX + (i + 1) * cellSize + cellSize / 2, tableY + cellSize / 2)

      // Row headers
      ctx.fillStyle = "#4fd1c5"
      ctx.fillRect(tableX, tableY + (i + 1) * cellSize, cellSize, cellSize)

      ctx.fillStyle = "#000000"
      ctx.fillText(String.fromCharCode(65 + i), tableX + cellSize / 2, tableY + (i + 1) * cellSize + cellSize / 2)
    }

    // Draw table cells
    for (let i = 0; i < 26; i++) {
      for (let j = 0; j < 26; j++) {
        const cellX = tableX + (j + 1) * cellSize
        const cellY = tableY + (i + 1) * cellSize
        const cellChar = String.fromCharCode(65 + ((i + j) % 26))

        ctx.fillStyle = "#2d3748"
        ctx.fillRect(cellX, cellY, cellSize, cellSize)

        ctx.fillStyle = "#ffffff"
        ctx.font = "8px monospace"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(cellChar, cellX + cellSize / 2, cellY + cellSize / 2)
      }
    }

    // Highlight current encryption
    if (step < plaintext.length) {
      const char = plaintext[step].toUpperCase()

      if (char >= "A" && char <= "Z") {
        const keyChar = key[step % key.length].toUpperCase()

        if (keyChar >= "A" && keyChar <= "Z") {
          const rowIndex = keyChar.charCodeAt(0) - 65
          const colIndex = char.charCodeAt(0) - 65

          // Highlight row header
          ctx.fillStyle = "#9f7aea"
          ctx.fillRect(tableX, tableY + (rowIndex + 1) * cellSize, cellSize, cellSize)

          ctx.fillStyle = "#000000"
          ctx.font = "10px monospace"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(keyChar, tableX + cellSize / 2, tableY + (rowIndex + 1) * cellSize + cellSize / 2)

          // Highlight column header
          ctx.fillStyle = "#4fd1c5"
          ctx.fillRect(tableX + (colIndex + 1) * cellSize, tableY, cellSize, cellSize)

          ctx.fillStyle = "#000000"
          ctx.fillText(char, tableX + (colIndex + 1) * cellSize + cellSize / 2, tableY + cellSize / 2)

          // Highlight cell
          const cellX = tableX + (colIndex + 1) * cellSize
          const cellY = tableY + (rowIndex + 1) * cellSize

          ctx.fillStyle = "#f6ad55"
          ctx.fillRect(cellX, cellY, cellSize, cellSize)

          ctx.fillStyle = "#000000"
          ctx.font = "8px monospace"
          ctx.fillText(
            String.fromCharCode(65 + ((rowIndex + colIndex) % 26)),
            cellX + cellSize / 2,
            cellY + cellSize / 2,
          )
        }
      }
    }

    // Draw text boxes
    drawTextBoxes(ctx)

    // Draw key visualization
    const keyY = tableY + 27 * cellSize + 20

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Key:", width / 2 - 100, keyY)

    for (let i = 0; i < key.length; i++) {
      const isActive = step % key.length === i
      const keyX = width / 2 - 50 + i * 25

      ctx.beginPath()
      ctx.arc(keyX, keyY, 12, 0, Math.PI * 2)
      ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      ctx.fillStyle = "#ffffff"
      ctx.font = "12px monospace"
      ctx.fillText(key[i].toUpperCase(), keyX, keyY)
    }
  }

  // Draw RSA
  const drawRSA = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw RSA components

    // Draw sender
    drawComponent(ctx, width * 0.2, height * 0.3, 80, 80, "Sender", "#2d3748")

    // Draw receiver
    drawComponent(ctx, width * 0.8, height * 0.3, 80, 80, "Receiver", "#2d3748")

    // Draw keys
    drawComponent(ctx, width * 0.8, height * 0.15, 60, 40, "Public Key", "#9f7aea")
    drawComponent(ctx, width * 0.8, height * 0.45, 60, 40, "Private Key", "#4fd1c5")

    // Draw arrows
    // Public key to sender
    drawArrow(ctx, width * 0.8 - 30, height * 0.15, width * 0.2 + 40, height * 0.3 - 20, "#9f7aea")

    // Message from sender to receiver
    if (step > 0) {
      drawArrow(ctx, width * 0.2 + 40, height * 0.3, width * 0.8 - 40, height * 0.3, "#f6ad55")
    }

    // Draw text boxes
    drawTextBoxes(ctx)

    // Draw encryption process
    if (step > 0) {
      // Draw encryption formula
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      const char = step <= plaintext.length ? plaintext[step - 1].toUpperCase() : ""
      const charCode = char.charCodeAt(0)

      ctx.fillText(`Encryption: ${char} (${charCode}) → ${charCode}^e mod n`, width / 2, height * 0.6)

      // Draw lock icon
      ctx.beginPath()
      ctx.rect(width * 0.45, height * 0.3 - 15, 30, 30)
      ctx.fillStyle = "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#9f7aea"
      ctx.lineWidth = 2
      ctx.stroke()

      ctx.beginPath()
      ctx.arc(width * 0.45 + 15, height * 0.3 - 5, 5, 0, Math.PI * 2)
      ctx.fillStyle = "#9f7aea"
      ctx.fill()

      ctx.beginPath()
      ctx.moveTo(width * 0.45 + 15, height * 0.3 - 5)
      ctx.lineTo(width * 0.45 + 15, height * 0.3 + 5)
      ctx.strokeStyle = "#9f7aea"
      ctx.lineWidth = 2
      ctx.stroke()
    }
  }

  // Draw text boxes
  const drawTextBoxes = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw plaintext box
    ctx.fillStyle = "#1a202c"
    ctx.fillRect(width * 0.1, height * 0.7, width * 0.8, 40)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.1, height * 0.7, width * 0.8, 40)

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("Plaintext: " + plaintext, width * 0.15, height * 0.7 + 20)

    // Draw ciphertext box
    ctx.fillStyle = "#1a202c"
    ctx.fillRect(width * 0.1, height * 0.8, width * 0.8, 40)
    ctx.strokeStyle = "#9f7aea"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.1, height * 0.8, width * 0.8, 40)

    ctx.fillStyle = "#ffffff"
    ctx.font = "16px monospace"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("Ciphertext: " + ciphertext, width * 0.15, height * 0.8 + 20)

    // Highlight current character
    if (step > 0 && step <= plaintext.length) {
      const charWidth = ctx.measureText("M").width // Monospace font

      // Highlight plaintext character
      const plainX = width * 0.15 + ctx.measureText("Plaintext: ").width + (step - 1) * charWidth

      ctx.fillStyle = "#4fd1c5"
      ctx.fillRect(plainX, height * 0.7 + 5, charWidth, 30)

      ctx.fillStyle = "#000000"
      ctx.fillText(plaintext[step - 1], plainX, height * 0.7 + 20)

      // Highlight ciphertext character
      if (ciphertext.length >= step) {
        const cipherX = width * 0.15 + ctx.measureText("Ciphertext: ").width + (step - 1) * charWidth

        ctx.fillStyle = "#9f7aea"
        ctx.fillRect(cipherX, height * 0.8 + 5, charWidth, 30)

        ctx.fillStyle = "#000000"
        ctx.fillText(ciphertext[step - 1], cipherX, height * 0.8 + 20)
      }
    }
  }

  // Helper function to draw a component
  const drawComponent = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    label: string,
    color: string,
  ) => {
    ctx.beginPath()
    ctx.rect(x - width / 2, y - height / 2, width, height)
    ctx.fillStyle = color
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(label, x, y)
  }

  // Helper function to draw an arrow
  const drawArrow = (ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, color: string) => {
    const headLength = 10
    const angle = Math.atan2(y2 - y1, x2 - x1)

    ctx.beginPath()
    ctx.moveTo(x1, y1)
    ctx.lineTo(x2, y2)

    // Draw arrowhead
    ctx.lineTo(x2 - headLength * Math.cos(angle - Math.PI / 6), y2 - headLength * Math.sin(angle - Math.PI / 6))
    ctx.moveTo(x2, y2)
    ctx.lineTo(x2 - headLength * Math.cos(angle + Math.PI / 6), y2 - headLength * Math.sin(angle + Math.PI / 6))

    ctx.strokeStyle = color
    ctx.lineWidth = 2
    ctx.stroke()
  }

  // Caesar cipher encryption
  const encryptCaesar = (text: string, shift: number): string => {
    return text
      .split("")
      .map((char) => {
        if (char.match(/[A-Z]/i)) {
          const code = char.charCodeAt(0)
          const isUpperCase = code >= 65 && code <= 90
          const base = isUpperCase ? 65 : 97

          return String.fromCharCode(((code - base + shift) % 26) + base)
        }
        return char
      })
      .join("")
  }

  // Vigenère cipher encryption
  const encryptVigenere = (text: string, key: string): string => {
    if (!key) return text

    return text
      .split("")
      .map((char, i) => {
        if (char.match(/[A-Z]/i)) {
          const code = char.charCodeAt(0)
          const isUpperCase = code >= 65 && code <= 90
          const base = isUpperCase ? 65 : 97

          const keyChar = key[i % key.length]
          const keyCode = keyChar.toUpperCase().charCodeAt(0)
          const shift = keyCode - 65

          return String.fromCharCode(((code - base + shift) % 26) + base)
        }
        return char
      })
      .join("")
  }

  // Simplified RSA encryption for visualization
  const encryptRSA = (text: string): string => {
    return text
      .split("")
      .map((char) => {
        if (char.match(/[A-Z]/i)) {
          const code = char.charCodeAt(0)
          // Just a visual representation, not actual RSA
          return String.fromCharCode(((code * 7) % 26) + 65)
        }
        return char
      })
      .join("")
  }

  // Handle algorithm change
  const handleAlgorithmChange = (value: string) => {
    setAlgorithm(value)
    resetVisualization()

    // Set default key based on algorithm
    if (value === "caesar") {
      setKey("3")
    } else if (value === "vigenere") {
      setKey("KEY")
    } else if (value === "rsa") {
      setKey("65537")
    }
  }

  // Generate random key
  const generateRandomKey = () => {
    if (algorithm === "caesar") {
      setKey(Math.floor(Math.random() * 25 + 1).toString())
    } else if (algorithm === "vigenere") {
      const length = Math.floor(Math.random() * 5) + 3
      let randomKey = ""

      for (let i = 0; i < length; i++) {
        randomKey += String.fromCharCode(65 + Math.floor(Math.random() * 26))
      }

      setKey(randomKey)
    } else if (algorithm === "rsa") {
      // Simplified for visualization
      setKey("65537")
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Cryptography Visualizer
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Explore encryption algorithms through interactive visualization
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Encryption Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetVisualization}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Encryption Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Encryption Algorithm</h3>
                    <Tabs
                      defaultValue="caesar"
                      value={algorithm}
                      onValueChange={handleAlgorithmChange}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="caesar">Caesar</TabsTrigger>
                        <TabsTrigger value="vigenere">Vigenère</TabsTrigger>
                        <TabsTrigger value="rsa">RSA</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Input Text</h3>
                    <Input
                      value={plaintext}
                      onChange={(e) => setPlaintext(e.target.value.toUpperCase())}
                      placeholder="Enter text to encrypt"
                      className="bg-gray-800/50 border-gray-700 text-white"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-sm font-medium text-gray-400">Encryption Key</h3>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={generateRandomKey}
                        className="h-7 border-gray-700 text-gray-300 hover:text-white"
                      >
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Random
                      </Button>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input
                        value={key}
                        onChange={(e) => setKey(e.target.value.toUpperCase())}
                        placeholder="Enter key"
                        className="bg-gray-800/50 border-gray-700 text-white"
                      />
                      <div className="flex-shrink-0">
                        <Key className="h-5 w-5 text-cyan-400" />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Algorithm Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {algorithm === "caesar" ? (
                        <>
                          <p>The Caesar Cipher is one of the simplest encryption techniques:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>
                              Each letter in the plaintext is shifted a fixed number of positions down the alphabet
                            </li>
                            <li>The key is a single integer representing the shift value</li>
                            <li>For example, with a shift of 3: A → D, B → E, etc.</li>
                            <li>Named after Julius Caesar, who used it to communicate with his generals</li>
                          </ul>
                        </>
                      ) : algorithm === "vigenere" ? (
                        <>
                          <p>
                            The Vigenère Cipher is a method of encrypting text using a series of interwoven Caesar
                            ciphers:
                          </p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Uses a keyword to determine the shift for each letter of the plaintext</li>
                            <li>
                              Each letter of the keyword specifies how many positions to shift the corresponding
                              plaintext letter
                            </li>
                            <li>The keyword is repeated to match the length of the plaintext</li>
                            <li>More secure than Caesar cipher as it's resistant to simple frequency analysis</li>
                          </ul>
                        </>
                      ) : (
                        <>
                          <p>RSA is an asymmetric cryptographic algorithm used for secure data transmission:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Uses a pair of keys: public key for encryption and private key for decryption</li>
                            <li>Based on the mathematical difficulty of factoring large prime numbers</li>
                            <li>Widely used for secure communications and digital signatures</li>
                            <li>Named after its inventors: Rivest, Shamir, and Adleman</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

