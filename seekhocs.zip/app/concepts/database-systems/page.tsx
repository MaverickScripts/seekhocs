"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Node class for B-tree visualization
class BTreeNode {
  keys: number[]
  children: BTreeNode[]
  isLeaf: boolean
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(isLeaf = true) {
    this.keys = []
    this.children = []
    this.isLeaf = isLeaf
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Document class for NoSQL visualization
class Document {
  id: string
  data: Record<string, any>
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(id: string, data: Record<string, any>) {
    this.id = id
    this.data = data
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

export default function DatabaseSystemsPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [databaseTopic, setDatabaseTopic] = useState("sql")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [sqlQuery, setSqlQuery] = useState("SELECT * FROM users WHERE age > 25 ORDER BY name")
  const [queryPlan, setQueryPlan] = useState<string[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [btreeRoot, setBtreeRoot] = useState<BTreeNode | null>(null)
  const [currentBtreeNode, setCurrentBtreeNode] = useState<BTreeNode | null>(null)
  const [documents, setDocuments] = useState<Document[]>([])
  const [currentDocument, setCurrentDocument] = useState<Document | null>(null)
  const [message, setMessage] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Database Systems Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore database concepts and operations through interactive visualizations",
  )

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Initialize based on selected concept
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)
      setCurrentStep(0)
      setCurrentBtreeNode(null)
      setCurrentDocument(null)

      // Set database topic based on selected concept
      if (selectedConcept.toLowerCase().includes("sql")) {
        setDatabaseTopic("sql")
        setConceptTitle("SQL Query Execution")
        setConceptDescription(
          "The process of parsing, optimizing, and executing SQL queries to retrieve or modify data in a relational database.",
        )
        setMessage("SQL Query Execution: How databases process and optimize SQL queries.")
        initializeSqlVisualization()
      } else if (selectedConcept.toLowerCase().includes("nosql")) {
        setDatabaseTopic("nosql")
        setConceptTitle("NoSQL Data Models")
        setConceptDescription(
          "Non-relational database models that provide flexible schemas for storage and retrieval of data, including document, key-value, column-family, and graph databases.",
        )
        setMessage("NoSQL Data Models: Flexible schema designs for various data storage needs.")
        initializeNoSqlVisualization()
      } else if (selectedConcept.toLowerCase().includes("index")) {
        setDatabaseTopic("indexing")
        setConceptTitle("Database Indexing")
        setConceptDescription(
          "A data structure technique to efficiently retrieve records from a database by improving the speed of data retrieval operations.",
        )
        setMessage("Database Indexing: Using B-trees and other structures to speed up data retrieval.")
        initializeIndexingVisualization()
      } else if (selectedConcept.toLowerCase().includes("cache")) {
        setDatabaseTopic("indexing") // Using indexing visualization for caching
        setConceptTitle("Database Caching")
        setConceptDescription(
          "A technique to store frequently accessed data in memory to reduce database load and improve application performance.",
        )
        setMessage("Database Caching: Storing frequently accessed data in memory for faster retrieval.")
        initializeIndexingVisualization()
      } else {
        // Default to SQL
        setDatabaseTopic("sql")
        setConceptTitle("Database Systems Visualizer")
        setConceptDescription("Explore database concepts and operations through interactive visualizations")
        setMessage("Select a database concept to visualize its operation.")
        initializeSqlVisualization()
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Database Systems Visualizer`
    }
  }, [selectedConcept])

  // Initialize SQL query execution visualization
  const initializeSqlVisualization = () => {
    // Parse the SQL query and create a query plan
    const queryPlan = [
      "1. Parse SQL query",
      "2. Validate syntax and semantics",
      "3. Generate query plan",
      "4. Optimize query plan",
      "5. Execute query plan",
      "6. Return results",
    ]

    setQueryPlan(queryPlan)
    setCurrentStep(0)
    setMessage("SQL Query Execution: Parsing and executing the query.")
  }

  // Initialize NoSQL data model visualization
  const initializeNoSqlVisualization = () => {
    // Create sample documents
    const documents = [
      new Document("user1", { name: "John Doe", age: 30, email: "john@example.com" }),
      new Document("user2", { name: "Jane Smith", age: 25, email: "jane@example.com" }),
      new Document("user3", { name: "Bob Johnson", age: 40, email: "bob@example.com" }),
    ]

    // Calculate positions
    const startX = 100
    const startY = 100
    const spacing = 150

    documents.forEach((doc, index) => {
      doc.x = startX + (index % 2) * spacing
      doc.y = startY + Math.floor(index / 2) * spacing
      doc.width = 120
      doc.height = 120
    })

    setDocuments(documents)
    setCurrentDocument(null)
    setCurrentStep(0)
    setMessage("NoSQL Data Models: Document-based storage with flexible schemas.")
  }

  // Initialize indexing visualization
  const initializeIndexingVisualization = () => {
    // Create a sample B-tree
    const root = new BTreeNode(false)
    root.keys = [50]

    const leftChild = new BTreeNode(true)
    leftChild.keys = [10, 20, 30, 40]

    const rightChild = new BTreeNode(true)
    rightChild.keys = [60, 70, 80, 90]

    root.children = [leftChild, rightChild]

    // Calculate positions
    calculateBTreeLayout(root, canvasSize.width / 2, 50, canvasSize.width - 100)

    setBtreeRoot(root)
    setCurrentBtreeNode(null)
    setCurrentStep(0)
    setMessage("Database Indexing: B-tree structure for efficient data retrieval.")
  }

  // Calculate layout for B-tree visualization
  const calculateBTreeLayout = (node: BTreeNode, x: number, y: number, availableWidth: number) => {
    const nodeWidth = 30 * (node.keys.length + 1)
    const nodeHeight = 40
    const levelHeight = 80

    node.x = x
    node.y = y
    node.width = nodeWidth
    node.height = nodeHeight

    if (node.children.length > 0) {
      const childWidth = availableWidth / node.children.length

      for (let i = 0; i < node.children.length; i++) {
        const childX = x - availableWidth / 2 + childWidth * i + childWidth / 2
        calculateBTreeLayout(node.children[i], childX, y + levelHeight, childWidth)
      }
    }
  }

  // Animation loop
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          if (databaseTopic === "sql") {
            if (currentStep < queryPlan.length) {
              setCurrentStep(currentStep + 1)
              setMessage(`SQL Query Execution: ${queryPlan[currentStep]}`)
            } else {
              setIsPlaying(false)
              setMessage("SQL Query Execution complete.")
            }
          } else if (databaseTopic === "nosql") {
            if (currentStep < documents.length) {
              setCurrentDocument(documents[currentStep])
              setMessage(`NoSQL Document: Examining document ${documents[currentStep].id}`)
              setCurrentStep(currentStep + 1)
            } else {
              setIsPlaying(false)
              setMessage("NoSQL Data Model visualization complete.")
            }
          } else if (databaseTopic === "indexing") {
            if (!currentBtreeNode) {
              // Start with the root
              setCurrentBtreeNode(btreeRoot)
              setMessage("B-tree Traversal: Starting at the root node.")
            } else if (currentBtreeNode.isLeaf) {
              // If at a leaf, we're done
              setIsPlaying(false)
              setMessage("B-tree Traversal complete. Found target in leaf node.")
            } else {
              // Move to a child node
              const childIndex = Math.floor(Math.random() * currentBtreeNode.children.length)
              setCurrentBtreeNode(currentBtreeNode.children[childIndex])
              setMessage(`B-tree Traversal: Moving to child node ${childIndex + 1}.`)
            }
          }
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, databaseTopic, currentStep, queryPlan, documents, currentDocument, btreeRoot, currentBtreeNode, speed])

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (databaseTopic === "sql") {
      drawSqlVisualization(ctx)
    } else if (databaseTopic === "nosql") {
      drawNoSqlVisualization(ctx)
    } else if (databaseTopic === "indexing") {
      drawIndexingVisualization(ctx)
    }
  }, [
    databaseTopic,
    currentStep,
    queryPlan,
    documents,
    currentDocument,
    btreeRoot,
    currentBtreeNode,
    canvasSize,
    sqlQuery,
  ])

  // Draw SQL query execution visualization
  const drawSqlVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw SQL query
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(sqlQuery, width / 2, 20)

    // Draw query execution flow
    const boxWidth = 160
    const boxHeight = 60
    const startX = width / 2 - boxWidth / 2
    const startY = 60
    const boxSpacing = 50

    // Draw database server
    ctx.beginPath()
    ctx.rect(startX - 200, startY + 100, 120, 160)
    ctx.fillStyle = "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw server details
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Database Server", startX - 140, startY + 80)

    // Draw server icon
    ctx.beginPath()
    ctx.rect(startX - 170, startY + 120, 60, 10)
    ctx.rect(startX - 170, startY + 140, 60, 10)
    ctx.rect(startX - 170, startY + 160, 60, 10)
    ctx.rect(startX - 170, startY + 180, 60, 10)
    ctx.fillStyle = "#1a202c"
    ctx.fill()

    // Draw query execution steps
    for (let i = 0; i < queryPlan.length; i++) {
      const boxY = startY + i * (boxHeight + boxSpacing / 2)

      // Draw connection to database for relevant steps
      if (i >= 4 && i <= 5) {
        ctx.beginPath()
        ctx.moveTo(startX, boxY + boxHeight / 2)
        ctx.lineTo(startX - 80, boxY + boxHeight / 2)
        ctx.lineTo(startX - 80, startY + 180)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw box
      ctx.beginPath()
      ctx.rect(startX, boxY, boxWidth, boxHeight)

      // Highlight current step
      if (i < currentStep) {
        ctx.fillStyle = "#4fd1c5"
      } else if (i === currentStep) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw step text
      ctx.fillStyle = "#000000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(queryPlan[i], startX + boxWidth / 2, boxY + boxHeight / 2)

      // Draw arrow to next step
      if (i < queryPlan.length - 1) {
        ctx.beginPath()
        ctx.moveTo(startX + boxWidth / 2, boxY + boxHeight)
        ctx.lineTo(startX + boxWidth / 2, boxY + boxHeight + boxSpacing / 2)
        ctx.strokeStyle = i < currentStep ? "#4fd1c5" : "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(startX + boxWidth / 2, boxY + boxHeight + boxSpacing / 2)
        ctx.lineTo(startX + boxWidth / 2 - 5, boxY + boxHeight + boxSpacing / 2 - 5)
        ctx.lineTo(startX + boxWidth / 2 + 5, boxY + boxHeight + boxSpacing / 2 - 5)
        ctx.closePath()
        ctx.fillStyle = i < currentStep ? "#4fd1c5" : "#4fd1c5"
        ctx.fill()
      }
    }

    // Draw query result
    if (currentStep >= queryPlan.length) {
      const resultY = startY + queryPlan.length * (boxHeight + boxSpacing / 2) + 20

      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText("Query Result:", width / 2, resultY)

      // Draw result table
      const tableWidth = 300
      const tableHeight = 100
      const tableX = width / 2 - tableWidth / 2
      const tableY = resultY + 30

      ctx.beginPath()
      ctx.rect(tableX, tableY, tableWidth, tableHeight)
      ctx.fillStyle = "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw table header
      ctx.beginPath()
      ctx.rect(tableX, tableY, tableWidth, 25)
      ctx.fillStyle = "#4fd1c5"
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.stroke()

      // Draw header text
      ctx.fillStyle = "#000000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("id", tableX + 50, tableY + 12.5)
      ctx.fillText("name", tableX + 150, tableY + 12.5)
      ctx.fillText("age", tableX + 250, tableY + 12.5)

      // Draw rows
      const rowHeight = 25
      for (let i = 0; i < 3; i++) {
        const rowY = tableY + 25 + i * rowHeight

        // Draw row
        ctx.beginPath()
        ctx.rect(tableX, rowY, tableWidth, rowHeight)
        ctx.fillStyle = i % 2 === 0 ? "#1a202c" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.stroke()

        // Draw row data
        ctx.fillStyle = "#ffffff"
        ctx.font = "12px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"

        if (i === 0) {
          ctx.fillText("1", tableX + 50, rowY + rowHeight / 2)
          ctx.fillText("Bob Johnson", tableX + 150, rowY + rowHeight / 2)
          ctx.fillText("40", tableX + 250, rowY + rowHeight / 2)
        } else if (i === 1) {
          ctx.fillText("3", tableX + 50, rowY + rowHeight / 2)
          ctx.fillText("Mike Smith", tableX + 150, rowY + rowHeight / 2)
          ctx.fillText("35", tableX + 250, rowY + rowHeight / 2)
        } else {
          ctx.fillText("5", tableX + 50, rowY + rowHeight / 2)
          ctx.fillText("Sarah Jones", tableX + 150, rowY + rowHeight / 2)
          ctx.fillText("28", tableX + 250, rowY + rowHeight / 2)
        }
      }
    }
  }

  // Draw NoSQL data model visualization
  const drawNoSqlVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw NoSQL database
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Document Database", width / 2, 20)

    // Draw documents
    documents.forEach((doc) => {
      // Draw document
      ctx.beginPath()
      ctx.rect(doc.x, doc.y, doc.width, doc.height)

      if (doc === currentDocument) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw document ID
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText(doc.id, doc.x + doc.width / 2, doc.y + 10)

      // Draw document data
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      let y = doc.y + 35
      for (const [key, value] of Object.entries(doc.data)) {
        ctx.fillText(`${key}: ${value}`, doc.x + 10, y)
        y += 20
      }
    })

    // Draw connections between documents
    ctx.beginPath()
    ctx.moveTo(documents[0].x + documents[0].width, documents[0].y + documents[0].height / 2)
    ctx.lineTo(documents[1].x, documents[1].y + documents[1].height / 2)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(documents[1].x + documents[1].width / 2, documents[1].y + documents[1].height)
    ctx.lineTo(documents[2].x + documents[2].width / 2, documents[2].y)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw NoSQL query
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText('db.users.find({ "age": { "$gt": 25 } })', width / 2, height - 40)
  }

  // Draw indexing visualization
  const drawIndexingVisualization = (ctx: CanvasRenderingContext2D) => {
    if (!btreeRoot) return

    const width = canvasSize.width
    const height = canvasSize.height

    // Draw B-tree title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("B-tree Index", width / 2, 20)

    // Draw the B-tree recursively
    const drawNode = (node: BTreeNode) => {
      // Draw node
      ctx.beginPath()
      ctx.rect(node.x - node.width / 2, node.y, node.width, node.height)

      // Highlight current node
      if (node === currentBtreeNode) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw keys
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      const keyWidth = node.width / (node.keys.length + 1)
      for (let i = 0; i < node.keys.length; i++) {
        const keyX = node.x - node.width / 2 + (i + 1) * keyWidth
        ctx.fillText(node.keys[i].toString(), keyX, node.y + node.height / 2)

        // Draw key separators
        if (i < node.keys.length - 1) {
          ctx.beginPath()
          ctx.moveTo(keyX + keyWidth / 2, node.y)
          ctx.lineTo(keyX + keyWidth / 2, node.y + node.height)
          ctx.strokeStyle = "#4fd1c5"
          ctx.lineWidth = 1
          ctx.stroke()
        }
      }

      // Draw connections to children
      for (let i = 0; i < node.children.length; i++) {
        const child = node.children[i]

        ctx.beginPath()
        ctx.moveTo(
          node.x - node.width / 2 + i * (node.width / node.children.length) + node.width / node.children.length / 2,
          node.y + node.height,
        )
        ctx.lineTo(child.x, child.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw child node
        drawNode(child)
      }
    }

    drawNode(btreeRoot)

    // Reset shadow
    ctx.shadowBlur = 0

    // Draw search value
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Searching for value: 75", width / 2, height - 40)

    // Draw search path
    if (currentBtreeNode) {
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(`Current Node Keys: [${currentBtreeNode.keys.join(", ")}]`, 20, 20)

      if (currentBtreeNode.isLeaf) {
        ctx.fillText("This is a leaf node. Search complete.", 20, 40)
      } else {
        ctx.fillText("This is an internal node. Continuing search...", 20, 40)
      }
    }
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setIsPlaying(false)
    setCurrentStep(0)
    setCurrentBtreeNode(null)
    setCurrentDocument(null)

    if (databaseTopic === "sql") {
      initializeSqlVisualization()
    } else if (databaseTopic === "nosql") {
      initializeNoSqlVisualization()
    } else if (databaseTopic === "indexing") {
      initializeIndexingVisualization()
    }
  }

  // Step forward one step
  const stepForward = () => {
    if (databaseTopic === "sql") {
      if (currentStep < queryPlan.length) {
        setCurrentStep(currentStep + 1)
        setMessage(`SQL Query Execution: ${queryPlan[currentStep]}`)
      }
    } else if (databaseTopic === "nosql") {
      if (currentStep < documents.length) {
        setCurrentDocument(documents[currentStep])
        setMessage(`NoSQL Document: Examining document ${documents[currentStep].id}`)
        setCurrentStep(currentStep + 1)
      }
    } else if (databaseTopic === "indexing") {
      if (!currentBtreeNode) {
        // Start with the root
        setCurrentBtreeNode(btreeRoot)
        setMessage("B-tree Traversal: Starting at the root node.")
      } else if (currentBtreeNode.isLeaf) {
        // If at a leaf, we're done
        setMessage("B-tree Traversal complete. Found target in leaf node.")
      } else {
        // Move to a child node
        const childIndex = Math.floor(Math.random() * currentBtreeNode.children.length)
        setCurrentBtreeNode(currentBtreeNode.children[childIndex])
        setMessage(`B-tree Traversal: Moving to child node ${childIndex + 1}.`)
      }
    }
  }

  // Handle SQL query change
  const handleSqlQueryChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSqlQuery(e.target.value)
    resetAnimation()
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={stepForward}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Database Topic</h3>
                    <Tabs
                      defaultValue="sql"
                      value={databaseTopic}
                      onValueChange={(value) => {
                        setDatabaseTopic(value)
                        resetAnimation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="sql">SQL</TabsTrigger>
                        <TabsTrigger value="nosql">NoSQL</TabsTrigger>
                        <TabsTrigger value="indexing">Indexing</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {databaseTopic === "sql" && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-400 mb-3">SQL Query</h3>
                      <Textarea
                        value={sqlQuery}
                        onChange={handleSqlQueryChange}
                        placeholder="Enter SQL query"
                        className="bg-gray-800/50 border-gray-700 text-white font-mono h-24"
                      />
                    </div>
                  )}

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Database Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {databaseTopic === "sql" ? (
                        <>
                          <p>SQL Query Execution Process:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Parsing: Converting SQL text to a parse tree</li>
                            <li>Validation: Checking syntax and semantics</li>
                            <li>Optimization: Finding the most efficient execution plan</li>
                            <li>Execution: Running the query and retrieving results</li>
                            <li>The query optimizer considers indexes, table statistics, and join methods</li>
                          </ul>
                        </>
                      ) : databaseTopic === "nosql" ? (
                        <>
                          <p>NoSQL Database Types:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Document Stores: MongoDB, CouchDB (JSON-like documents)</li>
                            <li>Key-Value Stores: Redis, DynamoDB (simple key-value pairs)</li>
                            <li>Column-Family: Cassandra, HBase (column-oriented storage)</li>
                            <li>Graph Databases: Neo4j, ArangoDB (nodes and relationships)</li>
                            <li>
                              Benefits: Schema flexibility, horizontal scalability, specialized query capabilities
                            </li>
                          </ul>
                        </>
                      ) : (
                        <>
                          <p>Database Indexing:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>B-trees: Balanced tree structure for efficient lookups, inserts, and deletes</li>
                            <li>Hash Indexes: Fast exact-match lookups using hash functions</li>
                            <li>Bitmap Indexes: Efficient for columns with low cardinality</li>
                            <li>Full-text Indexes: Specialized for text search operations</li>
                            <li>Trade-offs: Indexes speed up reads but slow down writes and require storage space</li>
                          </ul>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="database-systems" title="Database Systems" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

