"use client"

import type React from "react"

import { useState, useRef, useEffect, useMemo } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw, ChevronRight } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

// Node class for B-tree visualization
class BTreeNode {
  keys: number[]
  children: BTreeNode[]
  isLeaf: boolean
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(isLeaf = true) {
    this.keys = []
    this.children = []
    this.isLeaf = isLeaf
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Document class for NoSQL visualization
class Document {
  id: string
  data: Record<string, any>
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(id: string, data: Record<string, any>) {
    this.id = id
    this.data = data
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Transaction class for transaction processing
class Transaction {
  id: string
  operations: string[]
  status: string
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(id: string, operations: string[]) {
    this.id = id
    this.operations = operations
    this.status = "pending"
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Table class for normalization
class Table {
  name: string
  columns: string[]
  rows: any[][]
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(name: string, columns: string[], rows: any[][]) {
    this.name = name
    this.columns = columns
    this.rows = rows
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Node class for query plan
class QueryPlanNode {
  id: number
  type: string
  description: string
  cost: number
  rows: number
  children: QueryPlanNode[]
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(id: number, type: string, description: string, cost: number, rows: number) {
    this.id = id
    this.type = type
    this.description = description
    this.cost = cost
    this.rows = rows
    this.children = []
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Database node for distributed databases
class DatabaseNode {
  id: number
  type: string
  location: string
  tables: string[]
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(id: number, type: string, location: string, tables: string[]) {
    this.id = id
    this.type = type
    this.location = location
    this.tables = tables
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Data warehouse component
class WarehouseComponent {
  id: number
  type: string
  name: string
  description: string
  x: number
  y: number
  width: number
  height: number
  isActive: boolean

  constructor(id: number, type: string, name: string, description: string) {
    this.id = id
    this.type = type
    this.name = name
    this.description = description
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
    this.isActive = false
  }
}

// Cache entry
class CacheEntry {
  key: string
  value: string
  isHit: boolean
  x: number
  y: number
  width: number
  height: number

  constructor(key: string, value: string) {
    this.key = key
    this.value = value
    this.isHit = false
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
  }
}

// Concurrency operation
class ConcurrencyOperation {
  id: number
  transaction: string
  operation: string
  time: number
  status: string
  x: number
  y: number
  width: number
  height: number

  constructor(id: number, transaction: string, operation: string, time: number) {
    this.id = id
    this.transaction = transaction
    this.operation = operation
    this.time = time
    this.status = "waiting"
    this.x = 0
    this.y = 0
    this.width = 0
    this.height = 0
  }
}

export default function DatabaseSystemsPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [databaseTopic, setDatabaseTopic] = useState("sql")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [sqlQuery, setSqlQuery] = useState("SELECT * FROM users WHERE age > 25 ORDER BY name")
  const [queryPlan, setQueryPlan] = useState<string[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [message, setMessage] = useState("")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [conceptTitle, setConceptTitle] = useState<string>("Database Systems Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Explore database concepts and operations through interactive visualizations",
  )
  const [codeSnippet, setCodeSnippet] = useState<string>("")

  // State for SQL Query Execution
  const [sqlSteps, setSqlSteps] = useState<string[]>([])
  const [currentSqlStep, setCurrentSqlStep] = useState(0)
  const [nodes, setNodes] = useState<any[]>([])

  // State for NoSQL Data Models
  const [documents, setDocuments] = useState<Document[]>([])
  const [currentDocument, setCurrentDocument] = useState<Document | null>(null)

  // State for Database Indexing
  const [btreeRoot, setBtreeRoot] = useState<BTreeNode | null>(null)
  const [currentBtreeNode, setCurrentBtreeNode] = useState<BTreeNode | null>(null)

  // State for Database Caching
  const [cacheEntries, setCacheEntries] = useState<CacheEntry[]>([])
  const [currentCacheEntry, setCurrentCacheEntry] = useState<CacheEntry | null>(null)
  const [cacheHitRate, setCacheHitRate] = useState(0)
  const [cacheAccesses, setCacheAccesses] = useState(0)
  const [cacheHits, setCacheHits] = useState(0)
  const [cacheMisses, setCacheMisses] = useState(0)

  // State for Transaction Processing
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null)
  const [transactionSteps, setTransactionSteps] = useState<string[]>([])
  const [currentTransactionStep, setCurrentTransactionStep] = useState(0)

  // State for Concurrency Control
  const [concurrencyOperations, setConcurrencyOperations] = useState<ConcurrencyOperation[]>([])
  const [currentConcurrencyOperation, setCurrentConcurrencyOperation] = useState<ConcurrencyOperation | null>(null)
  const [lockTable, setLockTable] = useState<Record<string, string>>({})

  // State for Database Normalization
  const [normalizedTables, setNormalizedTables] = useState<Table[]>([])
  const [currentNormalizedTable, setCurrentNormalizedTable] = useState<Table | null>(null)

  // State for Query Optimization
  const [queryPlanRoot, setQueryPlanRoot] = useState<QueryPlanNode | null>(null)
  const [currentQueryPlanNode, setCurrentQueryPlanNode] = useState<QueryPlanNode | null>(null)
  const [optimizationSteps, setOptimizationSteps] = useState<string[]>([])
  const [currentOptimizationStep, setCurrentOptimizationStep] = useState(0)

  // State for Distributed Databases
  const [databaseNodes, setDatabaseNodes] = useState<DatabaseNode[]>([])
  const [currentDatabaseNode, setCurrentDatabaseNode] = useState<DatabaseNode | null>(null)
  const [dataPackets, setDataPackets] = useState<any[]>([])
  const [currentDataPacket, setCurrentDataPacket] = useState<any | null>(null)

  // State for Data Warehousing
  const [warehouseComponents, setWarehouseComponents] = useState<WarehouseComponent[]>([])
  const [currentWarehouseComponent, setCurrentWarehouseComponent] = useState<WarehouseComponent | null>(null)
  const [dataFlows, setDataFlows] = useState<any[]>([])
  const [currentDataFlow, setCurrentDataFlow] = useState<any | null>(null)

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Initialize based on selected concept
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setIsPlaying(false)
      setCurrentStep(0)
      resetAllState()

      // Set database topic and initialize visualization based on selected concept
      if (selectedConcept.toLowerCase().includes("sql") && !selectedConcept.toLowerCase().includes("nosql")) {
        setDatabaseTopic("sql")
        setConceptTitle("SQL Query Execution")
        setConceptDescription(
          "The process of parsing, optimizing, and executing SQL queries to retrieve or modify data in a relational database.",
        )
        setMessage("SQL Query Execution: How databases process and optimize SQL queries.")
        setCodeSnippet(`-- Example SQL Query
SELECT users.name, orders.order_date
FROM users
JOIN orders ON users.id = orders.user_id
WHERE users.country = 'USA'
ORDER BY orders.order_date DESC
LIMIT 10;`)
        initializeSqlVisualization()
      } else if (selectedConcept.toLowerCase().includes("nosql")) {
        setDatabaseTopic("nosql")
        setConceptTitle("NoSQL Data Models")
        setConceptDescription(
          "Non-relational database models that provide flexible schemas for storage and retrieval of data, including document, key-value, column-family, and graph databases.",
        )
        setMessage("NoSQL Data Models: Flexible schema designs for various data storage needs.")
        setCodeSnippet(`// MongoDB Document Example
db.users.insertOne({
  name: "John Doe",
  age: 30,
  email: "john@example.com",
  interests: ["programming", "music", "hiking"],
  address: {
    street: "123 Main St",
    city: "San Francisco",
    state: "CA",
    zip: "94105"
  }
});`)
        initializeNoSqlVisualization()
      } else if (selectedConcept.toLowerCase().includes("index")) {
        setDatabaseTopic("indexing")
        setConceptTitle("Database Indexing")
        setConceptDescription(
          "A data structure technique to efficiently retrieve records from a database by improving the speed of data retrieval operations.",
        )
        setMessage("Database Indexing: Using B-trees and other structures to speed up data retrieval.")
        setCodeSnippet(`-- Create an index on the users table
CREATE INDEX idx_users_email ON users(email);

-- Create a composite index
CREATE INDEX idx_users_country_city ON users(country, city);

-- Create a unique index
CREATE UNIQUE INDEX idx_users_username ON users(username);`)
        initializeIndexingVisualization()
      } else if (selectedConcept.toLowerCase().includes("cache")) {
        setDatabaseTopic("caching")
        setConceptTitle("Database Caching")
        setConceptDescription(
          "A technique to store frequently accessed data in memory to reduce database load and improve application performance.",
        )
        setMessage("Database Caching: Storing frequently accessed data in memory for faster retrieval.")
        setCodeSnippet(`// Redis caching example
// Store user data in cache
await redis.set('user:1001', JSON.stringify({
  id: 1001,
  name: 'Alice Smith',
  email: 'alice@example.com'
}), 'EX', 3600); // Expire in 1 hour

// Retrieve from cache first, then database if not found
async function getUser(id) {
  const cachedUser = await redis.get(\`user:\${id}\`);
  if (cachedUser) {
    return JSON.parse(cachedUser); // Cache hit
  }
  
  // Cache miss - fetch from database
  const user = await db.users.findOne({ id });
  if (user) {
    // Store in cache for future requests
    await redis.set(\`user:\${id}\`, JSON.stringify(user), 'EX', 3600);
  }
  return user;
}`)
        initializeCachingVisualization()
      } else if (selectedConcept.toLowerCase().includes("transaction")) {
        setDatabaseTopic("transaction")
        setConceptTitle("Transaction Processing")
        setConceptDescription(
          "A sequence of database operations that are executed as a single unit of work, ensuring data integrity through ACID properties.",
        )
        setMessage("Transaction Processing: Ensuring data consistency through ACID properties.")
        setCodeSnippet(`-- SQL Transaction Example (Bank Transfer)
BEGIN TRANSACTION;

-- Check if account has sufficient funds
SELECT balance FROM accounts WHERE id = 101;

-- Deduct amount from sender
UPDATE accounts SET balance = balance - 500 WHERE id = 101;

-- Add amount to recipient
UPDATE accounts SET balance = balance + 500 WHERE id = 202;

-- If everything is successful, commit the transaction
COMMIT;

-- If there's an error, roll back the transaction
-- ROLLBACK;`)
        initializeTransactionVisualization()
      } else if (selectedConcept.toLowerCase().includes("concurrency")) {
        setDatabaseTopic("concurrency")
        setConceptTitle("Concurrency Control")
        setConceptDescription(
          "Techniques to manage simultaneous access to a database by multiple users or processes without causing data inconsistency.",
        )
        setMessage("Concurrency Control: Managing simultaneous database access.")
        setCodeSnippet(`-- Isolation Levels in SQL
-- Read Uncommitted (lowest isolation)
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
BEGIN TRANSACTION;
SELECT * FROM accounts WHERE id = 101;
COMMIT;

-- Read Committed
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
BEGIN TRANSACTION;
SELECT * FROM accounts WHERE id = 101;
COMMIT;

-- Repeatable Read
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
BEGIN TRANSACTION;
SELECT * FROM accounts WHERE id = 101;
COMMIT;

-- Serializable (highest isolation)
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
BEGIN TRANSACTION;
SELECT * FROM accounts WHERE id = 101;
COMMIT;`)
        initializeConcurrencyVisualization()
      } else if (selectedConcept.toLowerCase().includes("normalization")) {
        setDatabaseTopic("normalization")
        setConceptTitle("Database Normalization")
        setConceptDescription(
          "The process of structuring a relational database to reduce data redundancy and improve data integrity.",
        )
        setMessage("Database Normalization: Organizing data to minimize redundancy.")
        setCodeSnippet(`-- Unnormalized Table
CREATE TABLE orders_unnormalized (
  order_id INT,
  customer_name VARCHAR(100),
  customer_email VARCHAR(100),
  customer_address VARCHAR(200),
  product_id INT,
  product_name VARCHAR(100),
  product_price DECIMAL(10,2),
  quantity INT
);

-- After 3NF Normalization
CREATE TABLE customers (
  customer_id INT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  address VARCHAR(200)
);

CREATE TABLE products (
  product_id INT PRIMARY KEY,
  name VARCHAR(100),
  price DECIMAL(10,2)
);

CREATE TABLE orders (
  order_id INT PRIMARY KEY,
  customer_id INT REFERENCES customers(customer_id),
  order_date DATE
);

CREATE TABLE order_items (
  order_id INT REFERENCES orders(order_id),
  product_id INT REFERENCES products(product_id),
  quantity INT,
  PRIMARY KEY (order_id, product_id)
);`)
        initializeNormalizationVisualization()
      } else if (selectedConcept.toLowerCase().includes("optimization")) {
        setDatabaseTopic("optimization")
        setConceptTitle("Query Optimization")
        setConceptDescription("The process of selecting the most efficient way to execute a database query.")
        setMessage("Query Optimization: Finding the most efficient execution plan.")
        setCodeSnippet(`-- Original Query
SELECT customers.name, orders.order_date
FROM customers
JOIN orders ON customers.id = orders.customer_id
WHERE customers.country = 'USA'
ORDER BY orders.order_date DESC;

-- Optimized with Index Hints
SELECT customers.name, orders.order_date
FROM customers USE INDEX (idx_country)
JOIN orders USE INDEX (idx_customer_date) 
  ON customers.id = orders.customer_id
WHERE customers.country = 'USA'
ORDER BY orders.order_date DESC;

-- Execution Plan Analysis
EXPLAIN ANALYZE
SELECT customers.name, orders.order_date
FROM customers
JOIN orders ON customers.id = orders.customer_id
WHERE customers.country = 'USA'
ORDER BY orders.order_date DESC;`)
        initializeQueryOptimizationVisualization()
      } else if (selectedConcept.toLowerCase().includes("distributed")) {
        setDatabaseTopic("distributed")
        setConceptTitle("Distributed Databases")
        setConceptDescription(
          "A database system where data is stored across multiple physical locations, connected by a network.",
        )
        setMessage("Distributed Databases: Managing data across multiple locations.")
        setCodeSnippet(`-- PostgreSQL Sharding Example
-- Create shards on different servers
-- Shard 1 (Server 1): Customers A-M
CREATE TABLE customers_a_m (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  CHECK (LEFT(LOWER(name), 1) BETWEEN 'a' AND 'm')
);

-- Shard 2 (Server 2): Customers N-Z
CREATE TABLE customers_n_z (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  CHECK (LEFT(LOWER(name), 1) BETWEEN 'n' AND 'z')
);

-- Application logic to route queries
function getCustomer(name) {
  const firstLetter = name.toLowerCase().charAt(0);
  if (firstLetter >= 'a' && firstLetter <= 'm') {
    return db1.query('SELECT * FROM customers_a_m WHERE name = $1', [name]);
  } else {
    return db2.query('SELECT * FROM customers_n_z WHERE name = $1', [name]);
  }
}`)
        initializeDistributedDatabaseVisualization()
      } else if (selectedConcept.toLowerCase().includes("warehouse")) {
        setDatabaseTopic("warehouse")
        setConceptTitle("Data Warehousing")
        setConceptDescription(
          "A system used for reporting and data analysis, storing current and historical data from various sources.",
        )
        setMessage("Data Warehousing: Storing and analyzing large volumes of data.")
        setCodeSnippet(`-- Star Schema Example for Sales Data Warehouse
-- Fact Table
CREATE TABLE fact_sales (
  sale_id INT PRIMARY KEY,
  date_id INT REFERENCES dim_date(date_id),
  product_id INT REFERENCES dim_product(product_id),
  store_id INT REFERENCES dim_store(store_id),
  customer_id INT REFERENCES dim_customer(customer_id),
  promotion_id INT REFERENCES dim_promotion(promotion_id),
  quantity INT,
  amount DECIMAL(10,2)
);

-- Dimension Tables
CREATE TABLE dim_date (
  date_id INT PRIMARY KEY,
  date DATE,
  day INT,
  month INT,
  quarter INT,
  year INT,
  is_holiday BOOLEAN
);

CREATE TABLE dim_product (
  product_id INT PRIMARY KEY,
  name VARCHAR(100),
  category VARCHAR(50),
  brand VARCHAR(50),
  cost DECIMAL(10,2),
  price DECIMAL(10,2)
);

-- OLAP Query Example
SELECT 
  dp.category,
  dd.year,
  dd.quarter,
  SUM(fs.amount) as total_sales
FROM fact_sales fs
JOIN dim_product dp ON fs.product_id = dp.product_id
JOIN dim_date dd ON fs.date_id = dd.date_id
GROUP BY dp.category, dd.year, dd.quarter
ORDER BY dp.category, dd.year, dd.quarter;`)
        initializeDataWarehouseVisualization()
      } else {
        // Default to SQL
        setDatabaseTopic("sql")
        setConceptTitle("Database Systems Visualizer")
        setConceptDescription("Explore database concepts and operations through interactive visualizations")
        setMessage("Select a database concept to visualize its operation.")
        setCodeSnippet(`-- Example SQL Query
SELECT * FROM users WHERE age > 25 ORDER BY name;`)
        initializeSqlVisualization()
      }
    }
  }, [selectedConcept])

  // Reset all state variables
  const resetAllState = () => {
    // Reset SQL state
    setSqlSteps([])
    setCurrentSqlStep(0)

    // Reset NoSQL state
    setDocuments([])
    setCurrentDocument(null)

    // Reset Indexing state
    setBtreeRoot(null)
    setCurrentBtreeNode(null)

    // Reset Caching state
    setCacheEntries([])
    setCurrentCacheEntry(null)
    setCacheHitRate(0)
    setCacheAccesses(0)
    setCacheHits(0)
    setCacheMisses(0)

    // Reset Transaction state
    setTransactions([])
    setCurrentTransaction(null)
    setTransactionSteps([])
    setCurrentTransactionStep(0)

    // Reset Concurrency state
    setConcurrencyOperations([])
    setCurrentConcurrencyOperation(null)
    setLockTable({})

    // Reset Normalization state
    setNormalizedTables([])
    setCurrentNormalizedTable(null)

    // Reset Query Optimization state
    setQueryPlanRoot(null)
    setCurrentQueryPlanNode(null)
    setOptimizationSteps([])
    setCurrentOptimizationStep(0)

    // Reset Distributed Database state
    setDatabaseNodes([])
    setCurrentDatabaseNode(null)
    setDataPackets([])
    setCurrentDataPacket(null)

    // Reset Data Warehouse state
    setWarehouseComponents([])
    setCurrentWarehouseComponent(null)
    setDataFlows([])
    setCurrentDataFlow(null)
  }

  // Initialize SQL query execution visualization
  const initializeSqlVisualization = () => {
    // Parse the SQL query and create a query plan
    const steps = [
      "1. Parse SQL query into syntax tree",
      "2. Validate syntax and semantics",
      "3. Generate logical query plan",
      "4. Optimize query plan using statistics",
      "5. Generate physical execution plan",
      "6. Execute query operations",
      "7. Return result set to client",
    ]

    setSqlSteps(steps)
    setCurrentSqlStep(0)
    setCurrentStep(0)
    setMessage("SQL Query Execution: Parsing and executing the query.")

    // Initialize database server node
    const serverNode = {
      id: 1,
      type: "Database Server",
      x: canvasSize.width / 4,
      y: canvasSize.height / 2,
      width: 120,
      height: 160,
      isActive: false,
    }

    setNodes([serverNode])
  }

  // Initialize NoSQL data model visualization
  const initializeNoSqlVisualization = () => {
    // Create sample documents for different NoSQL types
    const documentStore = new Document("user:1001", {
      name: "John Doe",
      age: 30,
      email: "john@example.com",
      interests: ["programming", "music"],
    })

    const keyValueStore = new Document("key-value", {
      "user:1001": "John Doe",
      "user:1001:email": "john@example.com",
      "user:1001:lastLogin": "2023-04-10T15:30:00Z",
    })

    const columnFamily = new Document("column-family", {
      "user:1001": {
        name: { value: "John Doe", timestamp: "2023-01-15T10:00:00Z" },
        email: { value: "john@example.com", timestamp: "2023-02-20T14:30:00Z" },
      },
    })

    const graphDb = new Document("graph", {
      nodes: [
        { id: "user:1001", label: "User", properties: { name: "John" } },
        { id: "post:2001", label: "Post", properties: { title: "Hello" } },
      ],
      edges: [{ from: "user:1001", to: "post:2001", label: "CREATED" }],
    })

    // Calculate positions
    documentStore.x = 100
    documentStore.y = 80
    documentStore.width = 180
    documentStore.height = 140

    keyValueStore.x = 500
    keyValueStore.y = 80
    keyValueStore.width = 180
    keyValueStore.height = 140

    columnFamily.x = 100
    columnFamily.y = 250
    columnFamily.width = 180
    columnFamily.height = 140

    graphDb.x = 500
    graphDb.y = 250
    graphDb.width = 180
    graphDb.height = 140

    setDocuments([documentStore, keyValueStore, columnFamily, graphDb])
    setCurrentDocument(null)
    setCurrentStep(0)
    setMessage("NoSQL Data Models: Different types of non-relational databases.")
  }

  // Initialize indexing visualization
  const initializeIndexingVisualization = () => {
    // Create a sample B-tree
    const root = new BTreeNode(false)
    root.keys = [50]

    const leftChild = new BTreeNode(true)
    leftChild.keys = [10, 20, 30, 40]

    const rightChild = new BTreeNode(true)
    rightChild.keys = [60, 70, 80, 90]

    root.children = [leftChild, rightChild]

    // Calculate positions
    const calculateBTreeLayout = (node: BTreeNode, x: number, y: number, availableWidth: number) => {
      const nodeWidth = 30 * (node.keys.length + 1)
      const nodeHeight = 40
      const levelHeight = 80

      node.x = x
      node.y = y
      node.width = nodeWidth
      node.height = nodeHeight

      if (node.children.length > 0) {
        const childWidth = availableWidth / node.children.length

        for (let i = 0; i < node.children.length; i++) {
          const childX = x - availableWidth / 2 + childWidth * i + childWidth / 2
          calculateBTreeLayout(node.children[i], childX, y + levelHeight, childWidth)
        }
      }
    }

    calculateBTreeLayout(root, canvasSize.width / 2, 50, canvasSize.width - 100)

    setBtreeRoot(root)
    setCurrentBtreeNode(null)
    setCurrentStep(0)
    setMessage("Database Indexing: B-tree structure for efficient data retrieval.")
  }

  // Initialize caching visualization
  const initializeCachingVisualization = () => {
    // Create cache entries
    const entries = [
      new CacheEntry("user:1001", "{ name: 'John', age: 30 }"),
      new CacheEntry("user:1002", "{ name: 'Jane', age: 28 }"),
      new CacheEntry("product:5001", "{ name: 'Laptop', price: 999 }"),
      new CacheEntry("product:5002", "{ name: 'Phone', price: 699 }"),
      new CacheEntry("order:3001", "{ id: 3001, total: 1299 }"),
    ]

    // Calculate positions
    const cacheWidth = 160
    const cacheHeight = 60
    const startX = 100
    const startY = 80
    const spacing = 20

    entries.forEach((entry, index) => {
      entry.x = startX
      entry.y = startY + index * (cacheHeight + spacing)
      entry.width = cacheWidth
      entry.height = cacheHeight
    })

    setCacheEntries(entries)
    setCurrentCacheEntry(null)
    setCacheHitRate(0.75)
    setCacheAccesses(0)
    setCacheHits(0)
    setCacheMisses(0)
    setCurrentStep(0)
    setMessage("Database Caching: In-memory storage for frequently accessed data.")
  }

  // Initialize transaction processing visualization
  const initializeTransactionVisualization = () => {
    // Create transaction steps
    const steps = [
      "1. Begin Transaction",
      "2. Read Account Balance (Account #101)",
      "3. Validate Sufficient Funds",
      "4. Deduct Amount from Account #101",
      "5. Add Amount to Account #202",
      "6. Commit Transaction",
    ]

    // Create transactions
    const transaction = new Transaction("T1", [
      "BEGIN TRANSACTION",
      "SELECT balance FROM accounts WHERE id = 101",
      "UPDATE accounts SET balance = balance - 500 WHERE id = 101",
      "UPDATE accounts SET balance = balance + 500 WHERE id = 202",
      "COMMIT",
    ])

    transaction.x = 300
    transaction.y = 100
    transaction.width = 200
    transaction.height = 200

    setTransactions([transaction])
    setCurrentTransaction(null)
    setTransactionSteps(steps)
    setCurrentTransactionStep(0)
    setCurrentStep(0)
    setMessage("Transaction Processing: Ensuring ACID properties in database operations.")
  }

  // Initialize concurrency control visualization
  const initializeConcurrencyVisualization = () => {
    // Create concurrency operations
    const operations = [
      new ConcurrencyOperation(1, "T1", "Read(A)", 0),
      new ConcurrencyOperation(2, "T2", "Read(B)", 0),
      new ConcurrencyOperation(3, "T1", "Write(B)", 1),
      new ConcurrencyOperation(4, "T2", "Write(A)", 1),
      new ConcurrencyOperation(5, "T1", "Commit", 2),
      new ConcurrencyOperation(6, "T2", "Commit", 2),
    ]

    // Calculate positions
    const opWidth = 120
    const opHeight = 40
    const startX = 100
    const startY = 80
    const spacing = 20

    operations.forEach((op, index) => {
      op.x = startX + (op.transaction === "T1" ? 0 : 200)
      op.y = startY + op.time * (opHeight + spacing)
      op.width = opWidth
      op.height = opHeight
    })

    setConcurrencyOperations(operations)
    setCurrentConcurrencyOperation(null)
    setLockTable({})
    setCurrentStep(0)
    setMessage("Concurrency Control: Detecting and preventing deadlocks in transactions.")
  }

  // Initialize database normalization visualization
  const initializeNormalizationVisualization = () => {
    // Original unnormalized table
    const unnormalizedTable = new Table(
      "Orders (Unnormalized)",
      ["OrderID", "CustomerName", "CustomerAddress", "ProductID", "ProductName", "ProductPrice", "Quantity"],
      [
        [1, "John Smith", "123 Main St", 101, "Laptop", 1200, 1],
        [2, "Jane Doe", "456 Oak Ave", 102, "Mouse", 25, 2],
        [3, "John Smith", "123 Main St", 103, "Keyboard", 50, 1],
      ],
    )

    // First normal form (1NF)
    const firstNF = new Table(
      "Orders (1NF)",
      ["OrderID", "CustomerName", "CustomerAddress", "ProductID", "ProductName", "ProductPrice", "Quantity"],
      [
        [1, "John Smith", "123 Main St", 101, "Laptop", 1200, 1],
        [2, "Jane Doe", "456 Oak Ave", 102, "Mouse", 25, 2],
        [3, "John Smith", "123 Main St", 103, "Keyboard", 50, 1],
      ],
    )

    // Second normal form (2NF) - Orders table
    const secondNF1 = new Table(
      "Orders (2NF)",
      ["OrderID", "CustomerName", "CustomerAddress", "ProductID", "Quantity"],
      [
        [1, "John Smith", "123 Main St", 101, 1],
        [2, "Jane Doe", "456 Oak Ave", 102, 2],
        [3, "John Smith", "123 Main St", 103, 1],
      ],
    )

    // Second normal form (2NF) - Products table
    const secondNF2 = new Table(
      "Products (2NF)",
      ["ProductID", "ProductName", "ProductPrice"],
      [
        [101, "Laptop", 1200],
        [102, "Mouse", 25],
        [103, "Keyboard", 50],
      ],
    )

    // Third normal form (3NF) - Orders table
    const thirdNF1 = new Table(
      "Orders (3NF)",
      ["OrderID", "CustomerID", "ProductID", "Quantity"],
      [
        [1, 1, 101, 1],
        [2, 2, 102, 2],
        [3, 1, 103, 1],
      ],
    )

    // Third normal form (3NF) - Customers table
    const thirdNF2 = new Table(
      "Customers (3NF)",
      ["CustomerID", "CustomerName", "CustomerAddress"],
      [
        [1, "John Smith", "123 Main St"],
        [2, "Jane Doe", "456 Oak Ave"],
      ],
    )

    // Third normal form (3NF) - Products table
    const thirdNF3 = new Table(
      "Products (3NF)",
      ["ProductID", "ProductName", "ProductPrice"],
      [
        [101, "Laptop", 1200],
        [102, "Mouse", 25],
        [103, "Keyboard", 50],
      ],
    )

    // Calculate positions
    unnormalizedTable.x = 300
    unnormalizedTable.y = 100
    unnormalizedTable.width = 600
    unnormalizedTable.height = 150

    firstNF.x = 300
    firstNF.y = 100
    firstNF.width = 600
    firstNF.height = 150

    secondNF1.x = 200
    secondNF1.y = 100
    secondNF1.width = 400
    secondNF1.height = 150

    secondNF2.x = 200
    secondNF2.y = 280
    secondNF2.width = 400
    secondNF2.height = 100

    thirdNF1.x = 150
    thirdNF1.y = 80
    thirdNF1.width = 300
    thirdNF1.height = 100

    thirdNF2.x = 500
    thirdNF2.y = 80
    thirdNF2.width = 300
    thirdNF2.height = 80

    thirdNF3.x = 300
    thirdNF3.y = 200
    thirdNF3.width = 300
    thirdNF3.height = 100

    setNormalizedTables([unnormalizedTable, firstNF, secondNF1, secondNF2, thirdNF1, thirdNF2, thirdNF3])
    setCurrentNormalizedTable(null)
    setCurrentStep(0)
    setMessage("Database Normalization: Reducing data redundancy through normal forms.")
  }

  // Initialize query optimization visualization
  const initializeQueryOptimizationVisualization = () => {
    // Create query plan nodes
    const sortNode = new QueryPlanNode(1, "Sort", "Sort results by order_date", 50, 800)
    const joinNode = new QueryPlanNode(2, "Hash Join", "Join customers with orders", 150, 800)
    const filterNode = new QueryPlanNode(3, "Filter", "Filter customers by country", 20, 300)
    const scanCustomersNode = new QueryPlanNode(4, "Table Scan", "Scan customers table", 100, 1000)
    const scanOrdersNode = new QueryPlanNode(5, "Table Scan", "Scan orders table", 200, 5000)

    // Build the query plan tree
    sortNode.children = [joinNode]
    joinNode.children = [filterNode, scanOrdersNode]
    filterNode.children = [scanCustomersNode]

    // Calculate positions
    const nodeWidth = 120
    const nodeHeight = 60
    const levelHeight = 100

    sortNode.x = canvasSize.width / 2
    sortNode.y = 50
    sortNode.width = nodeWidth
    sortNode.height = nodeHeight

    joinNode.x = canvasSize.width / 2
    joinNode.y = 50 + levelHeight
    joinNode.width = nodeWidth
    joinNode.height = nodeHeight

    filterNode.x = canvasSize.width / 2 - 150
    filterNode.y = 50 + 2 * levelHeight
    filterNode.width = nodeWidth
    filterNode.height = nodeHeight

    scanCustomersNode.x = canvasSize.width / 2 - 150
    scanCustomersNode.y = 50 + 3 * levelHeight
    scanCustomersNode.width = nodeWidth
    scanCustomersNode.height = nodeHeight

    scanOrdersNode.x = canvasSize.width / 2 + 150
    scanOrdersNode.y = 50 + 2 * levelHeight
    scanOrdersNode.width = nodeWidth
    scanOrdersNode.height = nodeHeight

    // Create optimization steps
    const steps = [
      "1. Initial query plan generation",
      "2. Estimate cost of each operation",
      "3. Consider available indexes",
      "4. Evaluate join order alternatives",
      "5. Choose optimal join algorithm",
      "6. Finalize execution plan",
    ]

    setQueryPlanRoot(sortNode)
    setCurrentQueryPlanNode(null)
    setOptimizationSteps(steps)
    setCurrentOptimizationStep(0)
    setCurrentStep(0)
    setMessage("Query Optimization: Finding the most efficient execution plan.")
  }

  // Initialize distributed database visualization
  const initializeDistributedDatabaseVisualization = () => {
    // Create database nodes
    const nodes = [
      new DatabaseNode(1, "Master", "US East", ["Users", "Products"]),
      new DatabaseNode(2, "Replica", "US West", ["Users", "Products"]),
      new DatabaseNode(3, "Replica", "Europe", ["Users", "Products"]),
      new DatabaseNode(4, "Shard", "Asia", ["Orders (2020-2022)"]),
      new DatabaseNode(5, "Shard", "Australia", ["Orders (2023-present)"]),
    ]

    // Calculate positions
    const nodeWidth = 100
    const nodeHeight = 100

    nodes[0].x = canvasSize.width / 2
    nodes[0].y = 50
    nodes[0].width = nodeWidth
    nodes[0].height = nodeHeight

    nodes[1].x = canvasSize.width / 2 - 200
    nodes[1].y = 200
    nodes[1].width = nodeWidth
    nodes[1].height = nodeHeight

    nodes[2].x = canvasSize.width / 2 + 200
    nodes[2].y = 200
    nodes[2].width = nodeWidth
    nodes[2].height = nodeHeight

    nodes[3].x = canvasSize.width / 2 - 100
    nodes[3].y = 350
    nodes[3].width = nodeWidth
    nodes[3].height = nodeHeight

    nodes[4].x = canvasSize.width / 2 + 100
    nodes[4].y = 350
    nodes[4].width = nodeWidth
    nodes[4].height = nodeHeight

    // Create data packets for animation
    const packets = [
      { from: 0, to: 1, x: nodes[0].x, y: nodes[0].y, progress: 0 },
      { from: 0, to: 2, x: nodes[0].x, y: nodes[0].y, progress: 0 },
      { from: 1, to: 3, x: nodes[1].x, y: nodes[1].y, progress: 0 },
      { from: 2, to: 4, x: nodes[2].x, y: nodes[2].y, progress: 0 },
    ]

    setDatabaseNodes(nodes)
    setCurrentDatabaseNode(null)
    setDataPackets(packets)
    setCurrentDataPacket(null)
    setCurrentStep(0)
    setMessage("Distributed Databases: Managing data across multiple locations.")
  }

  // Initialize data warehouse visualization
  const initializeDataWarehouseVisualization = () => {
    // Create data warehouse components
    const components = [
      new WarehouseComponent(1, "Source", "OLTP Database", "Operational database with transaction data"),
      new WarehouseComponent(2, "Source", "CRM System", "Customer relationship management data"),
      new WarehouseComponent(3, "ETL", "ETL Process", "Extract, Transform, Load pipeline"),
      new WarehouseComponent(4, "Warehouse", "Data Warehouse", "Central repository for integrated data"),
      new WarehouseComponent(5, "Mart", "Sales Mart", "Subject-oriented data for sales analysis"),
      new WarehouseComponent(6, "Mart", "Marketing Mart", "Subject-oriented data for marketing analysis"),
    ]

    // Calculate positions
    const compWidth = 120
    const compHeight = 80

    components[0].x = 100
    components[0].y = 100
    components[0].width = compWidth
    components[0].height = compHeight

    components[1].x = 100
    components[1].y = 220
    components[1].width = compWidth
    components[1].height = compHeight

    components[2].x = 300
    components[2].y = 160
    components[2].width = compWidth
    components[2].height = compHeight

    components[3].x = 500
    components[3].y = 160
    components[3].width = compWidth
    components[3].height = compHeight

    components[4].x = 700
    components[4].y = 100
    components[4].width = compWidth
    components[4].height = compHeight

    components[5].x = 700
    components[5].y = 220
    components[5].width = compWidth
    components[5].height = compHeight

    // Create data flows for animation
    const flows = [
      { from: 0, to: 2, x: components[0].x + compWidth, y: components[0].y + compHeight / 2, progress: 0 },
      { from: 1, to: 2, x: components[1].x + compWidth, y: components[1].y + compHeight / 2, progress: 0 },
      { from: 2, to: 3, x: components[2].x + compWidth, y: components[2].y + compHeight / 2, progress: 0 },
      { from: 3, to: 4, x: components[3].x + compWidth, y: components[3].y + compHeight / 2 - 30, progress: 0 },
      { from: 3, to: 5, x: components[3].x + compWidth, y: components[3].y + compHeight / 2 + 30, progress: 0 },
    ]

    setWarehouseComponents(components)
    setCurrentWarehouseComponent(null)
    setDataFlows(flows)
    setCurrentDataFlow(null)
    setCurrentStep(0)
    setMessage("Data Warehousing: Storing and analyzing large volumes of data.")
  }

  // Animate SQL query execution step
  const animateSqlStep = () => {
    if (currentStep < sqlSteps.length) {
      setCurrentSqlStep(currentStep)
      setMessage(`SQL Query Execution: ${sqlSteps[currentStep]}`)

      // Highlight different parts of the visualization based on the step
      const updatedNodes = [...nodes]
      updatedNodes.forEach((node) => (node.isActive = false))

      if (currentStep === 0) {
        // Parsing step - no active nodes
      } else if (currentStep === 1) {
        // Validation step - no active nodes
      } else if (currentStep === 2) {
        // Logical plan - no active nodes
      } else if (currentStep === 3) {
        // Optimization - no active nodes
      } else if (currentStep === 4 || currentStep === 5) {
        // Execution - database server is active
        updatedNodes[0].isActive = true
      } else if (currentStep === 6) {
        // Return results - no active nodes
      }

      setNodes(updatedNodes)
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("SQL Query Execution complete.")
    }
  }

  // Animate NoSQL data model step
  const animateNoSqlStep = () => {
    if (currentStep < documents.length) {
      setCurrentDocument(documents[currentStep])
      let modelType = "Document Store"
      if (currentStep === 1) modelType = "Key-Value Store"
      if (currentStep === 2) modelType = "Column-Family Store"
      if (currentStep === 3) modelType = "Graph Database"

      setMessage(`NoSQL Data Model: ${modelType} - ${documents[currentStep].id}`)
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("NoSQL Data Models visualization complete.")
    }
  }

  // Animate indexing step
  const animateIndexingStep = () => {
    if (!btreeRoot) return

    if (!currentBtreeNode) {
      // Start with the root
      setCurrentBtreeNode(btreeRoot)
      setMessage("B-tree Traversal: Starting at the root node.")
    } else if (currentBtreeNode.isLeaf) {
      // If at a leaf, we're done
      setIsPlaying(false)
      setMessage("B-tree Traversal complete. Found target in leaf node.")
    } else {
      // Move to a child node
      const childIndex = Math.floor(Math.random() * currentBtreeNode.children.length)
      setCurrentBtreeNode(currentBtreeNode.children[childIndex])
      setMessage(`B-tree Traversal: Moving to child node ${childIndex + 1}.`)
    }
  }

  // Animate caching step
  const animateCachingStep = () => {
    if (currentStep < 10 && cacheEntries.length > 0) {
      // Simulate cache access
      const entryIndex = Math.floor(Math.random() * cacheEntries.length)
      const entry = cacheEntries[entryIndex]

      // Determine if it's a hit or miss
      const isHit = Math.random() < cacheHitRate
      entry.isHit = isHit

      setCacheAccesses((prev) => prev + 1)
      if (isHit) {
        setCacheHits((prev) => prev + 1)
        setMessage(`Cache Hit: Data for key "${entry.key}" found in cache.`)
      } else {
        setCacheMisses((prev) => prev + 1)
        setMessage(`Cache Miss: Data for key "${entry.key}" not found in cache, retrieving from database.`)
      }

      setCurrentCacheEntry(entry)
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Database Caching simulation complete.")
    }
  }

  // Animate transaction step
  const animateTransactionStep = () => {
    if (currentTransactionStep < transactionSteps.length) {
      if (transactions.length > 0) {
        setCurrentTransaction(transactions[0])
      }
      setMessage(`Transaction: ${transactionSteps[currentTransactionStep]}`)
      setCurrentTransactionStep(currentTransactionStep + 1)
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Transaction Processing complete.")
    }
  }

  // Animate concurrency step
  const animateConcurrencyStep = () => {
    if (currentStep < concurrencyOperations.length) {
      const operation = concurrencyOperations[currentStep]
      setCurrentConcurrencyOperation(operation)

      // Update operation status
      const updatedOperations = [...concurrencyOperations]
      updatedOperations[currentStep].status = "executing"
      if (currentStep > 0) {
        updatedOperations[currentStep - 1].status = "completed"
      }

      // Update lock table
      let lockMessage = ""
      if (operation.operation.startsWith("Read")) {
        const resource = operation.operation.match(/$$([^)]+)$$/)?.[1]
        if (resource) {
          setLockTable((prev) => ({
            ...prev,
            [resource]: `${prev[resource] ? prev[resource] + "," : ""}${operation.transaction}(S)`,
          }))
          lockMessage = ` - Shared lock on ${resource}`
        }
      } else if (operation.operation.startsWith("Write")) {
        const resource = operation.operation.match(/$$([^)]+)$$/)?.[1]
        if (resource) {
          setLockTable((prev) => ({ ...prev, [resource]: `${operation.transaction}(X)` }))
          lockMessage = ` - Exclusive lock on ${resource}`
        }
      } else if (operation.operation === "Commit") {
        // Release all locks held by this transaction
        setLockTable((prev) => {
          const newLockTable = { ...prev }
          Object.keys(newLockTable).forEach((resource) => {
            if (newLockTable[resource].includes(operation.transaction)) {
              if (newLockTable[resource].includes(",")) {
                newLockTable[resource] = newLockTable[resource]
                  .replace(`${operation.transaction}(S),`, "")
                  .replace(`,${operation.transaction}(S)`, "")
              } else {
                delete newLockTable[resource]
              }
            }
          })
          return newLockTable
        })
        lockMessage = " - Releasing all locks"
      }

      setConcurrencyOperations(updatedOperations)
      setMessage(`Concurrency: ${operation.transaction} executing ${operation.operation}${lockMessage}`)
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Concurrency Control visualization complete.")
    }
  }

  // Animate normalization step
  const animateNormalizationStep = () => {
    if (currentStep < normalizedTables.length) {
      setCurrentNormalizedTable(normalizedTables[currentStep])

      if (currentStep === 0) {
        setMessage("Unnormalized table with redundant data.")
      } else if (currentStep === 1) {
        setMessage("First Normal Form (1NF): Atomic values in each column.")
      } else if (currentStep === 2 || currentStep === 3) {
        setMessage("Second Normal Form (2NF): Removed partial dependencies.")
      } else {
        setMessage("Third Normal Form (3NF): Removed transitive dependencies.")
      }

      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Database Normalization visualization complete.")
    }
  }

  // Animate query optimization step
  const animateOptimizationStep = () => {
    if (!queryPlanRoot) return

    if (currentStep < optimizationSteps.length) {
      setCurrentOptimizationStep(currentStep)
      setMessage(`Query Optimization: ${optimizationSteps[currentStep]}`)

      // Highlight different nodes based on the step
      if (currentStep === 0) {
        // Initial plan - highlight root
        setCurrentQueryPlanNode(queryPlanRoot)
      } else if (currentStep === 1) {
        // Cost estimation - highlight all nodes
        const allNodes = getAllNodes(queryPlanRoot)
        const randomIndex = Math.floor(Math.random() * allNodes.length)
        setCurrentQueryPlanNode(allNodes[randomIndex])
      } else if (currentStep === 2) {
        // Consider indexes - highlight scan nodes
        const scanNodes = getAllNodes(queryPlanRoot).filter((node) => node.type.includes("Scan"))
        const randomIndex = Math.floor(Math.random() * scanNodes.length)
        setCurrentQueryPlanNode(scanNodes[randomIndex])
      } else if (currentStep === 3 || currentStep === 4) {
        // Join order and algorithm - highlight join node
        const joinNodes = getAllNodes(queryPlanRoot).filter((node) => node.type.includes("Join"))
        if (joinNodes.length > 0) {
          setCurrentQueryPlanNode(joinNodes[0])
        }
      } else {
        // Final plan - highlight root again
        setCurrentQueryPlanNode(queryPlanRoot)
      }

      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Query Optimization visualization complete.")
    }
  }

  // Helper function to get all nodes in the query plan tree
  const getAllNodes = (root: QueryPlanNode): QueryPlanNode[] => {
    const nodes: QueryPlanNode[] = [root]
    for (const child of root.children) {
      nodes.push(...getAllNodes(child))
    }
    return nodes
  }

  // Animate distributed database step
  const animateDistributedStep = () => {
    if (currentStep < databaseNodes.length) {
      setCurrentDatabaseNode(databaseNodes[currentStep])
      setMessage(
        `Distributed Database: ${databaseNodes[currentStep].type} node in ${databaseNodes[currentStep].location}`,
      )
      setCurrentStep(currentStep + 1)
    } else if (currentStep < databaseNodes.length + dataPackets.length) {
      const packetIndex = currentStep - databaseNodes.length
      setCurrentDataPacket(dataPackets[packetIndex])

      const fromNode = databaseNodes[dataPackets[packetIndex].from]
      const toNode = databaseNodes[dataPackets[packetIndex].to]

      setMessage(
        `Data Replication: Sending data from ${fromNode.type} (${fromNode.location}) to ${toNode.type} (${toNode.location})`,
      )
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Distributed Database visualization complete.")
    }
  }

  // Animate data warehouse step
  const animateWarehouseStep = () => {
    if (currentStep < warehouseComponents.length) {
      setCurrentWarehouseComponent(warehouseComponents[currentStep])
      setMessage(
        `Data Warehouse: ${warehouseComponents[currentStep].name} - ${warehouseComponents[currentStep].description}`,
      )
      setCurrentStep(currentStep + 1)
    } else if (currentStep < warehouseComponents.length + dataFlows.length) {
      const flowIndex = currentStep - warehouseComponents.length
      setCurrentDataFlow(dataFlows[flowIndex])

      const fromComponent = warehouseComponents[dataFlows[flowIndex].from]
      const toComponent = warehouseComponents[dataFlows[flowIndex].to]

      setMessage(`Data Flow: Moving data from ${fromComponent.name} to ${toComponent.name}`)
      setCurrentStep(currentStep + 1)
    } else {
      setIsPlaying(false)
      setMessage("Data Warehousing visualization complete.")
    }
  }

  // Draw the visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (databaseTopic === "sql") {
      drawSqlVisualization(ctx)
    } else if (databaseTopic === "nosql") {
      drawNoSqlVisualization(ctx)
    } else if (databaseTopic === "indexing") {
      drawIndexingVisualization(ctx)
    } else if (databaseTopic === "caching") {
      drawCachingVisualization(ctx)
    } else if (databaseTopic === "transaction") {
      drawTransactionVisualization(ctx)
    } else if (databaseTopic === "concurrency") {
      drawConcurrencyVisualization(ctx)
    } else if (databaseTopic === "normalization") {
      drawNormalizationVisualization(ctx)
    } else if (databaseTopic === "optimization") {
      drawQueryOptimizationVisualization(ctx)
    } else if (databaseTopic === "distributed") {
      drawDistributedDatabaseVisualization(ctx)
    } else if (databaseTopic === "warehouse") {
      drawDataWarehouseVisualization(ctx)
    }
  }, [
    databaseTopic,
    currentStep,
    canvasSize,
    sqlQuery,
    currentSqlStep,
    documents,
    currentDocument,
    btreeRoot,
    currentBtreeNode,
    cacheEntries,
    currentCacheEntry,
    cacheHitRate,
    cacheAccesses,
    cacheHits,
    cacheMisses,
    transactions,
    currentTransaction,
    transactionSteps,
    currentTransactionStep,
    concurrencyOperations,
    currentConcurrencyOperation,
    lockTable,
    normalizedTables,
    currentNormalizedTable,
    queryPlanRoot,
    currentQueryPlanNode,
    optimizationSteps,
    currentOptimizationStep,
    databaseNodes,
    currentDatabaseNode,
    dataPackets,
    currentDataPacket,
    warehouseComponents,
    currentWarehouseComponent,
    dataFlows,
    currentDataFlow,
    nodes,
  ])

  // Draw SQL query execution visualization
  const drawSqlVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw SQL query
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px monospace"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(sqlQuery, width / 2, 20)

    // Draw query execution flow
    const boxWidth = 160
    const boxHeight = 60
    const startX = width / 2 - boxWidth / 2
    const startY = 60
    const boxSpacing = 40

    // Draw database server
    ctx.beginPath()
    ctx.rect(startX - 200, startY + 100, 120, 160)
    ctx.fillStyle = nodes.length > 0 && nodes[0].isActive ? "#9f7aea" : "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw server details
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Database Server", startX - 140, startY + 80)

    // Draw server icon
    ctx.beginPath()
    ctx.rect(startX - 170, startY + 120, 60, 10)
    ctx.rect(startX - 170, startY + 140, 60, 10)
    ctx.rect(startX - 170, startY + 160, 60, 10)
    ctx.rect(startX - 170, startY + 180, 60, 10)
    ctx.fillStyle = "#1a202c"
    ctx.fill()

    // Draw query execution steps
    for (let i = 0; i < sqlSteps.length; i++) {
      const boxY = startY + i * (boxHeight + boxSpacing / 2)

      // Draw connection to database for relevant steps
      if (i >= 4 && i <= 5) {
        ctx.beginPath()
        ctx.moveTo(startX, boxY + boxHeight / 2)
        ctx.lineTo(startX - 80, boxY + boxHeight / 2)
        ctx.lineTo(startX - 80, startY + 180)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw box
      ctx.beginPath()
      ctx.rect(startX, boxY, boxWidth, boxHeight)

      // Highlight current step
      if (i < currentSqlStep) {
        ctx.fillStyle = "#4fd1c5"
      } else if (i === currentSqlStep) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw step text
      ctx.fillStyle = "#000000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(sqlSteps[i], startX + boxWidth / 2, boxY + boxHeight / 2)

      // Draw arrow to next step
      if (i < sqlSteps.length - 1) {
        ctx.beginPath()
        ctx.moveTo(startX + boxWidth / 2, boxY + boxHeight)
        ctx.lineTo(startX + boxWidth / 2, boxY + boxHeight + boxSpacing / 2)
        ctx.strokeStyle = i < currentSqlStep ? "#4fd1c5" : "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(startX + boxWidth / 2, boxY + boxHeight + boxSpacing / 2)
        ctx.lineTo(startX + boxWidth / 2 - 5, boxY + boxHeight + boxSpacing / 2 - 5)
        ctx.lineTo(startX + boxWidth / 2 + 5, boxY + boxHeight + boxSpacing / 2 - 5)
        ctx.closePath()
        ctx.fillStyle = i < currentSqlStep ? "#4fd1c5" : "#4fd1c5"
        ctx.fill()
      }
    }

    // Draw query result
    if (currentSqlStep >= sqlSteps.length) {
      const resultY = startY + sqlSteps.length * (boxHeight + boxSpacing / 2) + 20

      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText("Query Result:", width / 2, resultY)

      // Draw result table
      const tableWidth = 300
      const tableHeight = 100
      const tableX = width / 2 - tableWidth / 2
      const tableY = resultY + 30

      ctx.beginPath()
      ctx.rect(tableX, tableY, tableWidth, tableHeight)
      ctx.fillStyle = "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw table header
      ctx.beginPath()
      ctx.rect(tableX, tableY, tableWidth, 25)
      ctx.fillStyle = "#4fd1c5"
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.stroke()

      // Draw header text
      ctx.fillStyle = "#000000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("name", tableX + 100, tableY + 12.5)
      ctx.fillText("order_date", tableX + 200, tableY + 12.5)

      // Draw rows
      const rowHeight = 25
      for (let i = 0; i < 3; i++) {
        const rowY = tableY + 25 + i * rowHeight

        // Draw row
        ctx.beginPath()
        ctx.rect(tableX, rowY, tableWidth, rowHeight)
        ctx.fillStyle = i % 2 === 0 ? "#1a202c" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.stroke()

        // Draw row data
        ctx.fillStyle = "#ffffff"
        ctx.font = "12px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"

        if (i === 0) {
          ctx.fillText("John Smith", tableX + 100, rowY + rowHeight / 2)
          ctx.fillText("2023-04-10", tableX + 200, rowY + rowHeight / 2)
        } else if (i === 1) {
          ctx.fillText("Alice Johnson", tableX + 100, rowY + rowHeight / 2)
          ctx.fillText("2023-04-05", tableX + 200, rowY + rowHeight / 2)
        } else {
          ctx.fillText("Bob Brown", tableX + 100, rowY + rowHeight / 2)
          ctx.fillText("2023-04-01", tableX + 200, rowY + rowHeight / 2)
        }
      }
    }
  }

  // Draw NoSQL data model visualization
  const drawNoSqlVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw NoSQL database title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("NoSQL Data Models", width / 2, 20)

    // Draw documents
    documents.forEach((doc) => {
      // Draw document
      ctx.beginPath()
      ctx.rect(doc.x, doc.y, doc.width, doc.height)

      if (doc === currentDocument) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw document type
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"

      let modelType = "Document Store"
      if (doc.id === "key-value") modelType = "Key-Value Store"
      if (doc.id === "column-family") modelType = "Column-Family Store"
      if (doc.id === "graph") modelType = "Graph Database"

      ctx.fillText(modelType, doc.x + doc.width / 2, doc.y + 10)

      // Draw document data
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      let y = doc.y + 35

      if (doc.id === "user:1001") {
        // Document store example
        ctx.fillText("{ name: 'John Doe',", doc.x + 10, y)
        y += 20
        ctx.fillText("  age: 30,", doc.x + 10, y)
        y += 20
        ctx.fillText("  email: 'john@example.com',", doc.x + 10, y)
        y += 20
        ctx.fillText("  interests: [...] }", doc.x + 10, y)
      } else if (doc.id === "key-value") {
        // Key-value store example
        ctx.fillText("user:1001 → 'John Doe'", doc.x + 10, y)
        y += 20
        ctx.fillText("user:1001:email →", doc.x + 10, y)
        y += 20
        ctx.fillText("  'john@example.com'", doc.x + 10, y)
        y += 20
        ctx.fillText("user:1001:lastLogin → ...", doc.x + 10, y)
      } else if (doc.id === "column-family") {
        // Column-family store example
        ctx.fillText("Row: user:1001", doc.x + 10, y)
        y += 20
        ctx.fillText("Columns:", doc.x + 10, y)
        y += 20
        ctx.fillText("  name: 'John Doe'", doc.x + 10, y)
        y += 20
        ctx.fillText("  email: 'john@example.com'", doc.x + 10, y)
      } else if (doc.id === "graph") {
        // Graph database example
        ctx.fillText("Nodes:", doc.x + 10, y)
        y += 20
        ctx.fillText("  (User {name: 'John'})", doc.x + 10, y)
        y += 20
        ctx.fillText("  (Post {title: 'Hello'})", doc.x + 10, y)
        y += 20
        ctx.fillText("Edges:", doc.x + 10, y)
        y += 20
        ctx.fillText("  (User)-[CREATED]->(Post)", doc.x + 10, y)
      }
    })

    // Draw connections between NoSQL types
    if (documents.length >= 4) {
      // Draw arrows connecting the different NoSQL types
      drawArrow(
        ctx,
        documents[0].x + documents[0].width,
        documents[0].y + documents[0].height / 2,
        documents[1].x,
        documents[1].y + documents[1].height / 2,
        "#4fd1c5",
      )

      drawArrow(
        ctx,
        documents[0].x + documents[0].width / 2,
        documents[0].y + documents[0].height,
        documents[2].x + documents[2].width / 2,
        documents[2].y,
        "#4fd1c5",
      )

      drawArrow(
        ctx,
        documents[2].x + documents[2].width,
        documents[2].y + documents[2].height / 2,
        documents[3].x,
        documents[3].y + documents[3].height / 2,
        "#4fd1c5",
      )
    }
  }

  // Helper function to draw an arrow
  const drawArrow = (
    ctx: CanvasRenderingContext2D,
    fromX: number,
    fromY: number,
    toX: number,
    toY: number,
    color: string,
    arrowSize = 5,
  ) => {
    // Calculate the angle of the line
    const angle = Math.atan2(toY - fromY, toX - fromX)

    // Draw the line
    ctx.beginPath()
    ctx.moveTo(fromX, fromY)
    ctx.lineTo(toX, toY)
    ctx.strokeStyle = color
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw the arrowhead
    ctx.beginPath()
    ctx.moveTo(toX, toY)
    ctx.lineTo(toX - arrowSize * Math.cos(angle - Math.PI / 6), toY - arrowSize * Math.sin(angle - Math.PI / 6))
    ctx.lineTo(toX - arrowSize * Math.cos(angle + Math.PI / 6), toY - arrowSize * Math.sin(angle + Math.PI / 6))
    ctx.closePath()
    ctx.fillStyle = color
    ctx.fill()
  }

  // Draw indexing visualization
  const drawIndexingVisualization = (ctx: CanvasRenderingContext2D) => {
    if (!btreeRoot) return

    const width = canvasSize.width
    const height = canvasSize.height

    // Draw B-tree title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("B-tree Index", width / 2, 20)

    // Draw the B-tree recursively
    const drawNode = (node: BTreeNode) => {
      // Draw node
      ctx.beginPath()
      ctx.rect(node.x - node.width / 2, node.y, node.width, node.height)

      // Highlight current node
      if (node === currentBtreeNode) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw keys
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      const keyWidth = node.width / (node.keys.length + 1)
      for (let i = 0; i < node.keys.length; i++) {
        const keyX = node.x - node.width / 2 + (i + 1) * keyWidth
        ctx.fillText(node.keys[i].toString(), keyX, node.y + node.height / 2)

        // Draw key separators
        if (i < node.keys.length - 1) {
          ctx.beginPath()
          ctx.moveTo(keyX + keyWidth / 2, node.y)
          ctx.lineTo(keyX + keyWidth / 2, node.y + node.height)
          ctx.strokeStyle = "#4fd1c5"
          ctx.lineWidth = 1
          ctx.stroke()
        }
      }

      // Draw connections to children
      for (let i = 0; i < node.children.length; i++) {
        const child = node.children[i]

        ctx.beginPath()
        ctx.moveTo(
          node.x - node.width / 2 + i * (node.width / node.children.length) + node.width / node.children.length / 2,
          node.y + node.height,
        )
        ctx.lineTo(child.x, child.y)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw child node
        drawNode(child)
      }
    }

    drawNode(btreeRoot)

    // Reset shadow
    ctx.shadowBlur = 0

    // Draw search value
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Searching for value: 75", width / 2, height - 40)

    // Draw search path
    if (currentBtreeNode) {
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(`Current Node Keys: [${currentBtreeNode.keys.join(", ")}]`, 20, 20)

      if (currentBtreeNode.isLeaf) {
        ctx.fillText("This is a leaf node. Search complete.", 20, 40)
      } else {
        ctx.fillText("This is an internal node. Continuing search...", 20, 40)
      }
    }

    // Draw index explanation
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("B-tree Properties:", 20, height - 80)
    ctx.fillText("• All leaf nodes are at the same level", 20, height - 60)
    ctx.fillText("• Keys in each node are sorted", 20, height - 40)
    ctx.fillText("• Efficient for range queries and exact matches", 20, height - 20)
  }

  // Draw caching visualization
  const drawCachingVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw cache title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Database Caching", width / 2, 20)

    // Draw cache memory box
    ctx.beginPath()
    ctx.rect(100, 80, 200, 250)
    ctx.fillStyle = "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw cache label
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Cache Memory", 200, 60)

    // Draw database box
    ctx.beginPath()
    ctx.rect(500, 150, 150, 100)
    ctx.fillStyle = "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#9f7aea"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw database label
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Database", 575, 130)

    // Draw cache entries
    cacheEntries.forEach((entry, index) => {
      // Draw entry box
      ctx.beginPath()
      ctx.rect(entry.x, entry.y, entry.width, entry.height)

      if (entry === currentCacheEntry) {
        ctx.fillStyle = entry.isHit ? "#4fd1c5" : "#f56565"
        ctx.shadowColor = entry.isHit ? "#4fd1c5" : "#f56565"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#1a202c"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw entry text
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(`${entry.key}`, entry.x + 10, entry.y + 20)
      ctx.fillText(`${entry.value.substring(0, 15)}${entry.value.length > 15 ? "..." : ""}`, entry.x + 10, entry.y + 40)
    })

    // Draw cache statistics
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Cache Statistics:", 400, 280)
    ctx.fillText(`Accesses: ${cacheAccesses}`, 400, 300)
    ctx.fillText(`Hits: ${cacheHits}`, 400, 320)
    ctx.fillText(`Misses: ${cacheMisses}`, 400, 340)
    ctx.fillText(`Hit Rate: ${cacheHits > 0 ? ((cacheHits / cacheAccesses) * 100).toFixed(1) : 0}%`, 400, 360)

    // Draw arrows for cache hit/miss
    if (currentCacheEntry) {
      if (currentCacheEntry.isHit) {
        // Cache hit - draw arrow from request to cache
        drawArrow(ctx, 350, 200, 300, 200, "#4fd1c5")

        // Draw "HIT" label
        ctx.fillStyle = "#4fd1c5"
        ctx.font = "bold 14px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText("HIT", 350, 180)
      } else {
        // Cache miss - draw arrow from cache to database
        drawArrow(ctx, 300, 200, 500, 200, "#f56565")

        // Draw "MISS" label
        ctx.fillStyle = "#f56565"
        ctx.font = "bold 14px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText("MISS", 400, 180)
      }
    }
  }

  // Draw transaction visualization
  const drawTransactionVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw transaction title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Transaction Processing", width / 2, 20)

    // Draw transaction steps
    const boxWidth = 200
    const boxHeight = 40
    const startX = width / 2 - boxWidth / 2
    const startY = 60
    const boxSpacing = 30

    for (let i = 0; i < transactionSteps.length; i++) {
      const boxY = startY + i * (boxHeight + boxSpacing)

      // Draw box
      ctx.beginPath()
      ctx.rect(startX, boxY, boxWidth, boxHeight)

      // Highlight current step
      if (i < currentTransactionStep) {
        ctx.fillStyle = "#4fd1c5"
      } else if (i === currentTransactionStep) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw step text
      ctx.fillStyle = "#000000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(transactionSteps[i], startX + boxWidth / 2, boxY + boxHeight / 2)

      // Draw arrow to next step
      if (i < transactionSteps.length - 1) {
        ctx.beginPath()
        ctx.moveTo(startX + boxWidth / 2, boxY + boxHeight)
        ctx.lineTo(startX + boxWidth / 2, boxY + boxHeight + boxSpacing)
        ctx.strokeStyle = i < currentTransactionStep ? "#4fd1c5" : "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw arrowhead
        ctx.beginPath()
        ctx.moveTo(startX + boxWidth / 2, boxY + boxHeight + boxSpacing)
        ctx.lineTo(startX + boxWidth / 2 - 5, boxY + boxHeight + boxSpacing - 5)
        ctx.lineTo(startX + boxWidth / 2 + 5, boxY + boxHeight + boxSpacing - 5)
        ctx.closePath()
        ctx.fillStyle = i < currentTransactionStep ? "#4fd1c5" : "#4fd1c5"
        ctx.fill()
      }
    }

    // Draw ACID properties
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("ACID Properties:", 50, 320)
    ctx.fillText("• Atomicity: All operations succeed or none do", 50, 340)
    ctx.fillText("• Consistency: Database remains in valid state", 50, 360)
    ctx.fillText("• Isolation: Transactions execute as if sequential", 50, 380)
    ctx.fillText("• Durability: Committed changes are permanent", 50, 400)
  }

  // Draw concurrency visualization
  const drawConcurrencyVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw concurrency title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Concurrency Control", width / 2, 20)

    // Draw transaction timelines
    const timelineY1 = 80
    const timelineY2 = 180
    const timelineX = 100
    const timelineWidth = 600

    // Draw T1 timeline
    ctx.beginPath()
    ctx.moveTo(timelineX, timelineY1)
    ctx.lineTo(timelineX + timelineWidth, timelineY1)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw T1 label
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"
    ctx.fillText("Transaction 1:", timelineX - 10, timelineY1)

    // Draw T2 timeline
    ctx.beginPath()
    ctx.moveTo(timelineX, timelineY2)
    ctx.lineTo(timelineX + timelineWidth, timelineY2)
    ctx.strokeStyle = "#9f7aea"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw T2 label
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "right"
    ctx.textBaseline = "middle"
    ctx.fillText("Transaction 2:", timelineX - 10, timelineY2)

    // Draw operations
    concurrencyOperations.forEach((op) => {
      const timelineY = op.transaction === "T1" ? timelineY1 : timelineY2
      const opX = timelineX + 150 * op.time

      // Draw operation box
      ctx.beginPath()
      ctx.rect(opX - op.width / 2, timelineY - op.height / 2, op.width, op.height)

      if (op === currentConcurrencyOperation) {
        ctx.fillStyle = "#f56565"
        ctx.shadowColor = "#f56565"
        ctx.shadowBlur = 15
      } else if (op.status === "completed") {
        ctx.fillStyle = "#4fd1c5"
      } else if (op.status === "executing") {
        ctx.fillStyle = "#9f7aea"
      } else {
        ctx.fillStyle = "#2d3748"
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw operation text
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(op.operation, opX, timelineY)
    })

    // Draw lock table
    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Lock Table:", 100, 250)

    // Draw lock table headers
    ctx.beginPath()
    ctx.rect(100, 270, 100, 30)
    ctx.rect(200, 270, 150, 30)
    ctx.fillStyle = "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.stroke()

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Resource", 150, 285)
    ctx.fillText("Lock Holder(s)", 275, 285)

    // Draw lock table rows
    let rowIndex = 0
    for (const [resource, holder] of Object.entries(lockTable)) {
      const rowY = 300 + rowIndex * 30

      ctx.beginPath()
      ctx.rect(100, rowY, 100, 30)
      ctx.rect(200, rowY, 150, 30)
      ctx.fillStyle = rowIndex % 2 === 0 ? "#1a202c" : "#2d3748"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(resource, 150, rowY + 15)
      ctx.fillText(holder, 275, rowY + 15)

      rowIndex++
    }

    // Draw deadlock explanation if T1 and T2 are both waiting
    if (currentStep >= 4 && currentStep < 6) {
      ctx.fillStyle = "#f56565"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText("Deadlock Detected!", width / 2, 350)
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.fillText("T1 holds lock on A, waiting for B", width / 2, 370)
      ctx.fillText("T2 holds lock on B, waiting for A", width / 2, 390)
    }
  }

  // Draw normalization visualization
  const drawNormalizationVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw normalization title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Database Normalization", width / 2, 20)

    // Draw current table
    if (currentNormalizedTable) {
      const table = currentNormalizedTable

      // Draw table name
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText(table.name, table.x + table.width / 2, table.y - 25)

      // Draw table
      const headerHeight = 30
      const rowHeight = 25
      const colWidth = table.width / table.columns.length

      // Draw header
      ctx.beginPath()
      ctx.rect(table.x, table.y, table.width, headerHeight)
      ctx.fillStyle = "#4fd1c5"
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw header text
      ctx.fillStyle = "#000000"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      table.columns.forEach((col, colIndex) => {
        const colX = table.x + colIndex * colWidth
        ctx.fillText(col, colX + colWidth / 2, table.y + headerHeight / 2)

        // Draw column separators
        if (colIndex > 0) {
          ctx.beginPath()
          ctx.moveTo(colX, table.y)
          ctx.lineTo(colX, table.y + headerHeight + rowHeight * table.rows.length)
          ctx.strokeStyle = "#4fd1c5"
          ctx.lineWidth = 1
          ctx.stroke()
        }
      })

      // Draw rows
      table.rows.forEach((row, rowIndex) => {
        const rowY = table.y + headerHeight + rowIndex * rowHeight

        // Draw row background
        ctx.beginPath()
        ctx.rect(table.x, rowY, table.width, rowHeight)
        ctx.fillStyle = rowIndex % 2 === 0 ? "#1a202c" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw row data
        ctx.fillStyle = "#ffffff"
        ctx.font = "12px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"

        row.forEach((cell, colIndex) => {
          const colX = table.x + colIndex * colWidth
          ctx.fillText(cell.toString(), colX + colWidth / 2, rowY + rowHeight / 2)
        })
      })

      // Draw normal form explanation
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"

      if (table.name.includes("Unnormalized")) {
        ctx.fillText("Unnormalized Table:", 50, 320)
        ctx.font = "12px Arial"
        ctx.fillText("• Contains redundant data", 50, 340)
        ctx.fillText("• Susceptible to update anomalies", 50, 360)
        ctx.fillText("• Inefficient storage", 50, 380)
      } else if (table.name.includes("1NF")) {
        ctx.fillText("First Normal Form (1NF):", 50, 320)
        ctx.font = "12px Arial"
        ctx.fillText("• Atomic values in each column", 50, 340)
        ctx.fillText("• No repeating groups", 50, 360)
        ctx.fillText("• Each row uniquely identifiable", 50, 380)
      } else if (table.name.includes("2NF")) {
        ctx.fillText("Second Normal Form (2NF):", 50, 320)
        ctx.font = "12px Arial"
        ctx.fillText("• Meets all 1NF requirements", 50, 340)
        ctx.fillText("• No partial dependencies", 50, 360)
        ctx.fillText("• Non-key attributes depend on the entire primary key", 50, 380)
      } else if (table.name.includes("3NF")) {
        ctx.fillText("Third Normal Form (3NF):", 50, 320)
        ctx.font = "12px Arial"
        ctx.fillText("• Meets all 2NF requirements", 50, 340)
        ctx.fillText("• No transitive dependencies", 50, 360)
        ctx.fillText("• Non-key attributes depend only on the primary key", 50, 380)
      }
    }
  }

  // Draw query optimization visualization
  const drawQueryOptimizationVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw query optimization title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Query Optimization", width / 2, 20)

    // Draw query plan tree
    if (queryPlanRoot) {
      drawQueryPlanNode(ctx, queryPlanRoot)
    }

    // Draw optimization step
    if (currentOptimizationStep < optimizationSteps.length) {
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText(`Step: ${optimizationSteps[currentOptimizationStep]}`, 50, 320)
    }

    // Draw optimization explanation
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Query Optimization Process:", 50, 350)
    ctx.fillText("1. Generate initial query plan", 50, 370)
    ctx.fillText("2. Estimate cost using statistics", 50, 390)
    ctx.fillText("3. Consider alternative plans", 50, 410)
    ctx.fillText("4. Choose plan with lowest cost", 50, 430)
  }

  // Helper function to draw a query plan node
  const drawQueryPlanNode = (ctx: CanvasRenderingContext2D, node: QueryPlanNode) => {
    // Draw node
    ctx.beginPath()
    ctx.rect(node.x - node.width / 2, node.y, node.width, node.height)

    if (node === currentQueryPlanNode) {
      ctx.fillStyle = "#9f7aea"
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 15
    } else {
      ctx.fillStyle = "#2d3748"
      ctx.shadowBlur = 0
    }

    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Reset shadow
    ctx.shadowBlur = 0

    // Draw node text
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(node.type, node.x, node.y + 15)
    ctx.fillText(`Cost: ${node.cost}`, node.x, node.y + 35)

    // Draw connections to children
    for (const child of node.children) {
      ctx.beginPath()
      ctx.moveTo(node.x, node.y + node.height)
      ctx.lineTo(child.x, child.y)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw arrowhead
      ctx.beginPath()
      ctx.moveTo(child.x, child.y)
      ctx.lineTo(child.x - 5, child.y - 5)
      ctx.lineTo(child.x + 5, child.y - 5)
      ctx.closePath()
      ctx.fillStyle = "#4fd1c5"
      ctx.fill()

      // Draw child node
      drawQueryPlanNode(ctx, child)
    }
  }

  // Draw distributed database visualization
  const drawDistributedDatabaseVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw distributed database title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Distributed Databases", width / 2, 20)

    // Draw database nodes
    databaseNodes.forEach((node) => {
      // Draw node
      ctx.beginPath()
      ctx.rect(node.x - node.width / 2, node.y, node.width, node.height)

      if (node === currentDatabaseNode) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        ctx.fillStyle = "#2d3748"
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw node text
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText(node.type, node.x, node.y + 10)
      ctx.fillText(node.location, node.x, node.y + 30)

      // Draw tables
      let y = node.y + 50
      ctx.font = "10px Arial"
      node.tables.forEach((table) => {
        ctx.fillText(table, node.x, y)
        y += 15
      })
    })

    // Draw connections between nodes
    if (databaseNodes.length >= 2) {
      // Master to replicas
      drawArrow(
        ctx,
        databaseNodes[0].x,
        databaseNodes[0].y + databaseNodes[0].height,
        databaseNodes[1].x,
        databaseNodes[1].y,
        "#4fd1c5",
      )

      drawArrow(
        ctx,
        databaseNodes[0].x,
        databaseNodes[0].y + databaseNodes[0].height,
        databaseNodes[2].x,
        databaseNodes[2].y,
        "#4fd1c5",
      )

      // Replicas to shards
      if (databaseNodes.length >= 4) {
        drawArrow(
          ctx,
          databaseNodes[1].x,
          databaseNodes[1].y + databaseNodes[1].height,
          databaseNodes[3].x,
          databaseNodes[3].y,
          "#4fd1c5",
        )

        drawArrow(
          ctx,
          databaseNodes[2].x,
          databaseNodes[2].y + databaseNodes[2].height,
          databaseNodes[4].x,
          databaseNodes[4].y,
          "#4fd1c5",
        )
      }
    }

    // Draw data packets
    if (currentDataPacket) {
      const packet = currentDataPacket
      const fromNode = databaseNodes[packet.from]
      const toNode = databaseNodes[packet.to]

      // Calculate packet position along the path
      const progress = (currentStep - databaseNodes.length) / 10
      const packetX = fromNode.x + (toNode.x - fromNode.x) * progress
      const packetY =
        fromNode.y +
        fromNode.height / 2 +
        (toNode.y - fromNode.height / 2 - (fromNode.y + fromNode.height / 2)) * progress

      // Draw packet
      ctx.beginPath()
      ctx.arc(packetX, packetY, 5, 0, Math.PI * 2)
      ctx.fillStyle = "#f56565"
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw distributed database explanation
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Distributed Database Concepts:", 50, 350)
    ctx.fillText("• Replication: Copies of data across multiple nodes", 50, 370)
    ctx.fillText("• Sharding: Partitioning data across multiple nodes", 50, 390)
    ctx.fillText("• Consistency: Ensuring all nodes have same data", 50, 410)
    ctx.fillText("• Availability: System remains operational despite failures", 50, 430)
  }

  // Draw data warehouse visualization
  const drawDataWarehouseVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw data warehouse title
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Data Warehousing", width / 2, 20)

    // Draw warehouse components
    warehouseComponents.forEach((component) => {
      // Draw component
      ctx.beginPath()
      ctx.rect(component.x, component.y, component.width, component.height)

      if (component === currentWarehouseComponent) {
        ctx.fillStyle = "#9f7aea"
        ctx.shadowColor = "#9f7aea"
        ctx.shadowBlur = 15
      } else {
        let fillColor = "#2d3748"
        if (component.type === "Source") fillColor = "#3182ce"
        if (component.type === "ETL") fillColor = "#805ad5"
        if (component.type === "Warehouse") fillColor = "#38a169"
        if (component.type === "Mart") fillColor = "#dd6b20"

        ctx.fillStyle = fillColor
        ctx.shadowBlur = 0
      }

      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 2
      ctx.stroke()

      // Reset shadow
      ctx.shadowBlur = 0

      // Draw component text
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(component.name, component.x + component.width / 2, component.y + component.height / 2)
    })

    // Draw connections between components
    if (warehouseComponents.length >= 3) {
      // Sources to ETL
      drawArrow(
        ctx,
        warehouseComponents[0].x + warehouseComponents[0].width,
        warehouseComponents[0].y + warehouseComponents[0].height / 2,
        warehouseComponents[2].x,
        warehouseComponents[2].y + warehouseComponents[2].height / 2,
        "#4fd1c5",
      )

      drawArrow(
        ctx,
        warehouseComponents[1].x + warehouseComponents[1].width,
        warehouseComponents[1].y + warehouseComponents[1].height / 2,
        warehouseComponents[2].x,
        warehouseComponents[2].y + warehouseComponents[2].height / 2,
        "#4fd1c5",
      )

      // ETL to Warehouse
      if (warehouseComponents.length >= 4) {
        drawArrow(
          ctx,
          warehouseComponents[2].x + warehouseComponents[2].width,
          warehouseComponents[2].y + warehouseComponents[2].height / 2,
          warehouseComponents[3].x,
          warehouseComponents[3].y + warehouseComponents[3].height / 2,
          "#4fd1c5",
        )

        // Warehouse to Data Marts
        if (warehouseComponents.length >= 6) {
          drawArrow(
            ctx,
            warehouseComponents[3].x + warehouseComponents[3].width,
            warehouseComponents[3].y + warehouseComponents[3].height / 3,
            warehouseComponents[4].x,
            warehouseComponents[4].y + warehouseComponents[4].height / 2,
            "#4fd1c5",
          )

          drawArrow(
            ctx,
            warehouseComponents[3].x + warehouseComponents[3].width,
            warehouseComponents[3].y + (warehouseComponents[3].height * 2) / 3,
            warehouseComponents[5].x,
            warehouseComponents[5].y + warehouseComponents[5].height / 2,
            "#4fd1c5",
          )
        }
      }
    }

    // Draw data flow
    if (currentDataFlow) {
      const flow = currentDataFlow
      const fromComponent = warehouseComponents[flow.from]
      const toComponent = warehouseComponents[flow.to]

      // Calculate flow position along the path
      const progress = (currentStep - warehouseComponents.length) / 10
      const flowX = flow.x + (toComponent.x - flow.x) * progress
      const flowY = flow.y + (toComponent.y + toComponent.height / 2 - flow.y) * progress

      // Draw flow
      ctx.beginPath()
      ctx.arc(flowX, flowY, 5, 0, Math.PI * 2)
      ctx.fillStyle = "#f56565"
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()
    }

    // Draw data warehouse explanation
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    ctx.fillText("Data Warehouse Concepts:", 50, 350)
    ctx.fillText("• ETL: Extract, Transform, Load process", 50, 370)
    ctx.fillText("• Star Schema: Fact tables surrounded by dimension tables", 50, 390)
    ctx.fillText("• OLAP: Online Analytical Processing for complex queries", 50, 410)
    ctx.fillText("• Data Marts: Subject-oriented subsets of the warehouse", 50, 430)
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setIsPlaying(false)
    setCurrentStep(0)

    if (databaseTopic === "sql") {
      setCurrentSqlStep(0)
    } else if (databaseTopic === "nosql") {
      setCurrentDocument(null)
    } else if (databaseTopic === "indexing") {
      setCurrentBtreeNode(null)
    } else if (databaseTopic === "caching") {
      setCurrentCacheEntry(null)
      setCacheAccesses(0)
      setCacheHits(0)
      setCacheMisses(0)
    } else if (databaseTopic === "transaction") {
      setCurrentTransaction(null)
      setCurrentTransactionStep(0)
    } else if (databaseTopic === "concurrency") {
      setCurrentConcurrencyOperation(null)
      setLockTable({})
    } else if (databaseTopic === "normalization") {
      setCurrentNormalizedTable(null)
    } else if (databaseTopic === "optimization") {
      setCurrentQueryPlanNode(null)
      setCurrentOptimizationStep(0)
    } else if (databaseTopic === "distributed") {
      setCurrentDatabaseNode(null)
      setCurrentDataPacket(null)
    } else if (databaseTopic === "warehouse") {
      setCurrentWarehouseComponent(null)
      setCurrentDataFlow(null)
    }
  }

  // Step forward one step
  const stepForward = () => {
    if (databaseTopic === "sql") {
      animateSqlStep()
    } else if (databaseTopic === "nosql") {
      animateNoSqlStep()
    } else if (databaseTopic === "indexing") {
      animateIndexingStep()
    } else if (databaseTopic === "caching") {
      animateCachingStep()
    } else if (databaseTopic === "transaction") {
      animateTransactionStep()
    } else if (databaseTopic === "concurrency") {
      animateConcurrencyStep()
    } else if (databaseTopic === "normalization") {
      animateNormalizationStep()
    } else if (databaseTopic === "optimization") {
      animateOptimizationStep()
    } else if (databaseTopic === "distributed") {
      animateDistributedStep()
    } else if (databaseTopic === "warehouse") {
      animateWarehouseStep()
    }
  }

  // Handle SQL query change
  const handleSqlQueryChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setSqlQuery(e.target.value)
    resetAnimation()
  }

  // Memoize the database topic tabs to prevent unnecessary re-renders
  const databaseTopicTabs = useMemo(
    () => (
      <Tabs
        defaultValue="sql"
        value={databaseTopic}
        onValueChange={(value) => {
          setDatabaseTopic(value)
          resetAnimation()

          if (value === "sql") {
            initializeSqlVisualization()
          } else if (value === "nosql") {
            initializeNoSqlVisualization()
          } else if (value === "indexing") {
            initializeIndexingVisualization()
          } else if (value === "caching") {
            initializeCachingVisualization()
          } else if (value === "transaction") {
            initializeTransactionVisualization()
          } else if (value === "concurrency") {
            initializeConcurrencyVisualization()
          } else if (value === "normalization") {
            initializeNormalizationVisualization()
          } else if (value === "optimization") {
            initializeQueryOptimizationVisualization()
          } else if (value === "distributed") {
            initializeDistributedDatabaseVisualization()
          } else if (value === "warehouse") {
            initializeDataWarehouseVisualization()
          }
        }}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-5 bg-gray-800/50">
          <TabsTrigger value="sql">SQL</TabsTrigger>
          <TabsTrigger value="nosql">NoSQL</TabsTrigger>
          <TabsTrigger value="indexing">Indexing</TabsTrigger>
          <TabsTrigger value="transaction">Transactions</TabsTrigger>
          <TabsTrigger value="normalization">Normalization</TabsTrigger>
        </TabsList>
      </Tabs>
    ),
    [databaseTopic],
  )

  // Animation loop
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          if (databaseTopic === "sql") {
            animateSqlStep()
          } else if (databaseTopic === "nosql") {
            animateNoSqlStep()
          } else if (databaseTopic === "indexing") {
            animateIndexingStep()
          } else if (databaseTopic === "caching") {
            animateCachingStep()
          } else if (databaseTopic === "transaction") {
            animateTransactionStep()
          } else if (databaseTopic === "concurrency") {
            animateConcurrencyStep()
          } else if (databaseTopic === "normalization") {
            animateNormalizationStep()
          } else if (databaseTopic === "optimization") {
            animateOptimizationStep()
          } else if (databaseTopic === "distributed") {
            animateDistributedStep()
          } else if (databaseTopic === "warehouse") {
            animateWarehouseStep()
          }
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [
    isPlaying,
    databaseTopic,
    currentStep,
    speed,
    sqlSteps,
    currentSqlStep,
    documents,
    currentDocument,
    btreeRoot,
    currentBtreeNode,
    cacheEntries,
    currentCacheEntry,
    cacheHitRate,
    cacheAccesses,
    cacheHits,
    cacheMisses,
    transactions,
    currentTransaction,
    transactionSteps,
    currentTransactionStep,
    concurrencyOperations,
    currentConcurrencyOperation,
    lockTable,
    normalizedTables,
    currentNormalizedTable,
    queryPlanRoot,
    currentQueryPlanNode,
    optimizationSteps,
    currentOptimizationStep,
    databaseNodes,
    currentDatabaseNode,
    dataPackets,
    currentDataPacket,
    warehouseComponents,
    currentWarehouseComponent,
    dataFlows,
    currentDataFlow,
    nodes,
  ])

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={stepForward}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Controls</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Database Topic</h3>
                    {databaseTopicTabs}
                  </div>

                  {databaseTopic === "sql" && (
                    <div>
                      <h3 className="text-sm font-medium text-gray-400 mb-3">SQL Query</h3>
                      <Textarea
                        value={sqlQuery}
                        onChange={handleSqlQueryChange}
                        placeholder="Enter SQL query"
                        className="bg-gray-800/50 border-gray-700 text-white font-mono h-24"
                      />
                    </div>
                  )}

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Code Example</h3>
                    <div className="bg-gray-800/50 rounded-md p-3 font-mono text-xs text-gray-300 overflow-auto max-h-48">
                      <pre>{codeSnippet}</pre>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="database-systems" title="Database Systems" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
