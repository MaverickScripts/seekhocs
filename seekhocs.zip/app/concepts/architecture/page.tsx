"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

export default function ArchitecturePage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(50)
  const [component, setComponent] = useState("cpu")
  const [step, setStep] = useState(0)
  const [message, setMessage] = useState("CPU is idle")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })

  // Add new visualization components for all architecture concepts

  // Add these new state variables at the top of the component
  const [pipelineStages, setPipelineStages] = useState<string[]>(["Fetch", "Decode", "Execute", "Memory", "Writeback"])
  const [instructions, setInstructions] = useState<string[]>([
    "ADD R1, R2, R3",
    "SUB R4, R5, R6",
    "MUL R7, R8, R9",
    "DIV R10, R11, R12",
    "LOAD R13, [R14]",
  ])
  const [branchHistory, setBranchHistory] = useState<boolean[]>([true, false, true, true, false, true, false, false])
  const [prediction, setPrediction] = useState<boolean>(true)
  const [riscInstructions, setRiscInstructions] = useState<string[]>([
    "ADD R1, R2, R3",
    "SUB R4, R5, R6",
    "LW R7, 0(R8)",
    "SW R9, 4(R10)",
    "BEQ R11, R12, label",
  ])
  const [ciscInstructions, setCiscInstructions] = useState<string[]>([
    "MOV EAX, [EBX+ECX*4+20h]",
    "PUSH [ESP+4]",
    "CMPSB",
    "LODSW",
    "REP MOVSB",
  ])
  const [virtualPages, setVirtualPages] = useState<number[]>([0, 1, 2, 3, 4, 5, 6, 7])
  const [physicalFrames, setPhysicalFrames] = useState<number[]>([3, 1, 4, 0, 2])
  const [pageTable, setPageTable] = useState<{ [key: number]: number }>({
    0: 3,
    1: 1,
    2: 4,
    3: 0,
    4: 2,
    5: -1,
    6: -1,
    7: -1,
  })
  const [ramBlocks, setRamBlocks] = useState<{ [key: number]: string }>({
    0: "Program Code",
    1: "Stack",
    2: "Heap",
    3: "Static Data",
    4: "OS Kernel",
  })

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Update the useEffect that handles animation to properly update messages for all concepts

  // Replace the existing useEffect that handles animation with this enhanced version:
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          setStep((prevStep) => {
            const nextStep = (prevStep + 1) % 5

            // Update message based on component and step
            switch (component) {
              case "cpu":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU is fetching instruction from memory")
                    break
                  case 1:
                    setMessage("CPU is decoding the instruction")
                    break
                  case 2:
                    setMessage("CPU is executing the instruction")
                    break
                  case 3:
                    setMessage("CPU is accessing memory")
                    break
                  case 4:
                    setMessage("CPU is writing back results")
                    break
                }
                break
              case "pipeline":
                switch (nextStep) {
                  case 0:
                    setMessage("Instruction 1 is in Fetch stage")
                    break
                  case 1:
                    setMessage("Instruction 1 moves to Decode, Instruction 2 enters Fetch")
                    break
                  case 2:
                    setMessage("Pipeline is filling, multiple instructions in different stages")
                    break
                  case 3:
                    setMessage("Full pipeline throughput achieved")
                    break
                  case 4:
                    setMessage("Data hazard detected between instructions")
                    break
                }
                break
              case "branch":
                switch (nextStep) {
                  case 0:
                    setMessage("Branch instruction detected")
                    break
                  case 1:
                    setMessage("Predictor checks branch history table")
                    break
                  case 2:
                    setMessage("Prediction made: branch will be " + (prediction ? "taken" : "not taken"))
                    break
                  case 3:
                    setMessage("Executing instructions speculatively")
                    break
                  case 4:
                    setMessage(
                      "Branch resolution: prediction was " +
                        (branchHistory[nextStep % branchHistory.length] === prediction ? "correct" : "incorrect"),
                    )
                    break
                }
                break
              case "risc":
                switch (nextStep) {
                  case 0:
                    setMessage("RISC CPU loads values from registers")
                    break
                  case 1:
                    setMessage("Simple ALU performs operation in a single cycle")
                    break
                  case 2:
                    setMessage("Result stored back to register file")
                    break
                  case 3:
                    setMessage("Memory access only through load/store instructions")
                    break
                  case 4:
                    setMessage("Fixed-length instruction format simplifies decoding")
                    break
                }
                break
              case "cisc":
                switch (nextStep) {
                  case 0:
                    setMessage("CISC CPU decodes complex instruction")
                    break
                  case 1:
                    setMessage("Microcode ROM translates to multiple micro-operations")
                    break
                  case 2:
                    setMessage("Complex addressing mode calculation")
                    break
                  case 3:
                    setMessage("Memory-to-memory operation in progress")
                    break
                  case 4:
                    setMessage("Single instruction completes multiple operations")
                    break
                }
                break
              case "memory":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU accesses registers (fastest memory)")
                    break
                  case 1:
                    setMessage("L1 Cache access (very fast, small capacity)")
                    break
                  case 2:
                    setMessage("L2 Cache access (fast, medium capacity)")
                    break
                  case 3:
                    setMessage("L3 Cache access (slower, larger capacity)")
                    break
                  case 4:
                    setMessage("Main Memory/RAM access (slowest, largest capacity)")
                    break
                }
                break
              case "virtual":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU requests memory access with virtual address")
                    break
                  case 1:
                    setMessage("MMU receives virtual address")
                    break
                  case 2:
                    setMessage("MMU consults page table")
                    break
                  case 3:
                    setMessage("Virtual page mapped to physical frame")
                    break
                  case 4:
                    setMessage("Physical memory accessed with translated address")
                    break
                }
                break
              case "ram":
                switch (nextStep) {
                  case 0:
                    setMessage("Memory controller receives read/write request")
                    break
                  case 1:
                    setMessage("Row address strobe (RAS) selects memory row")
                    break
                  case 2:
                    setMessage("Column address strobe (CAS) selects memory column")
                    break
                  case 3:
                    setMessage("Data read from or written to selected memory cell")
                    break
                  case 4:
                    setMessage("Memory refresh cycle to maintain data integrity")
                    break
                }
                break
              case "cache":
              case "l1":
              case "l2":
              case "l3":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU requests data from cache")
                    break
                  case 1:
                    setMessage("Cache controller checks for data in cache lines")
                    break
                  case 2:
                    setMessage("Cache hit: data found in cache, sent to CPU")
                    break
                  case 3:
                    setMessage("Cache miss: data fetched from main memory")
                    break
                  case 4:
                    setMessage("Data stored in cache line for future access")
                    break
                }
                break
              case "von":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU fetches instruction or data from memory")
                    break
                  case 1:
                    setMessage("Single address space accessed for both")
                    break
                  case 2:
                    setMessage("Instruction decoded and executed")
                    break
                  case 3:
                    setMessage("Data processed and results stored back in memory")
                    break
                  case 4:
                    setMessage("Von Neumann bottleneck: shared bus limits performance")
                    break
                }
                break
              case "harvard":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU fetches instruction from instruction memory")
                    break
                  case 1:
                    setMessage("CPU fetches data from data memory")
                    break
                  case 2:
                    setMessage("Simultaneous access to instructions and data")
                    break
                  case 3:
                    setMessage("Instruction decoded and executed")
                    break
                  case 4:
                    setMessage("Data processed and results stored in data memory")
                    break
                }
                break
              case "bus":
                switch (nextStep) {
                  case 0:
                    setMessage("CPU initiates data transfer")
                    break
                  case 1:
                    setMessage("Address bus carries memory address")
                    break
                  case 2:
                    setMessage("Data bus carries data between components")
                    break
                  case 3:
                    setMessage("Control bus manages read/write operations")
                    break
                  case 4:
                    setMessage("Data transfer complete")
                    break
                }
                break
            }

            return nextStep
          })
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, step, speed, component, prediction, branchHistory])

  // Update the useEffect that draws the canvas to handle all architecture concepts

  // Replace the existing useEffect that draws the canvas with this enhanced version:
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw based on selected component
    switch (component) {
      case "cpu":
        drawCPU(ctx, step)
        break
      case "pipeline":
        drawPipeline(ctx, step)
        break
      case "branch":
        drawBranchPrediction(ctx, step)
        break
      case "risc":
        drawRISC(ctx, step)
        break
      case "cisc":
        drawCISC(ctx, step)
        break
      case "memory":
        drawMemoryHierarchy(ctx, step)
        break
      case "virtual":
        drawVirtualMemory(ctx, step)
        break
      case "ram":
        drawRAM(ctx, step)
        break
      case "cache":
      case "l1":
      case "l2":
      case "l3":
        drawCacheMemory(ctx, step)
        break
      case "von":
        drawVonNeumann(ctx, step)
        break
      case "harvard":
        drawHarvard(ctx, step)
        break
      case "bus":
        drawBusArchitecture(ctx, step)
        break
      default:
        drawCPU(ctx, step)
    }
  }, [
    component,
    step,
    canvasSize,
    pipelineStages,
    instructions,
    branchHistory,
    prediction,
    riscInstructions,
    ciscInstructions,
    virtualPages,
    physicalFrames,
    pageTable,
    ramBlocks,
  ])

  // Draw CPU architecture
  const drawCPU = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw CPU outline
    ctx.beginPath()
    ctx.rect(width * 0.1, height * 0.1, width * 0.8, height * 0.8)
    ctx.fillStyle = "#1a202c"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw CPU components

    // Control Unit
    const controlUnitActive = currentStep === 1
    drawComponent(
      ctx,
      width * 0.2,
      height * 0.2,
      width * 0.25,
      height * 0.25,
      "Control Unit",
      controlUnitActive ? "#9f7aea" : "#2d3748",
      controlUnitActive,
    )

    // ALU
    const aluActive = currentStep === 2
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.2,
      width * 0.25,
      height * 0.25,
      "ALU",
      aluActive ? "#9f7aea" : "#2d3748",
      aluActive,
    )

    // Registers
    const registersActive = currentStep === 4
    drawComponent(
      ctx,
      width * 0.2,
      height * 0.55,
      width * 0.25,
      height * 0.25,
      "Registers",
      registersActive ? "#9f7aea" : "#2d3748",
      registersActive,
    )

    // Cache
    const cacheActive = currentStep === 3
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.55,
      width * 0.25,
      height * 0.25,
      "Cache",
      cacheActive ? "#9f7aea" : "#2d3748",
      cacheActive,
    )

    // Draw connections
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1

    // Control Unit to ALU
    drawConnection(
      ctx,
      width * 0.45,
      height * 0.325,
      width * 0.55,
      height * 0.325,
      currentStep === 1 || currentStep === 2,
    )

    // Control Unit to Registers
    drawConnection(
      ctx,
      width * 0.325,
      height * 0.45,
      width * 0.325,
      height * 0.55,
      currentStep === 1 || currentStep === 4,
    )

    // ALU to Registers
    drawConnection(
      ctx,
      width * 0.55,
      height * 0.325,
      width * 0.45,
      height * 0.55,
      currentStep === 2 || currentStep === 4,
    )

    // Cache to ALU
    drawConnection(
      ctx,
      width * 0.675,
      height * 0.45,
      width * 0.675,
      height * 0.55,
      currentStep === 2 || currentStep === 3,
    )

    // Draw data bus
    ctx.beginPath()
    ctx.rect(width * 0.1, height * 0.9, width * 0.8, height * 0.05)
    ctx.fillStyle = currentStep === 0 ? "#9f7aea" : "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("System Bus", width * 0.5, height * 0.925)

    // Draw connection from bus to CPU
    drawConnection(ctx, width * 0.5, height * 0.9, width * 0.5, height * 0.8, currentStep === 0)
  }

  // Draw Memory Hierarchy
  const drawMemoryHierarchy = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw pyramid of memory hierarchy

    // Registers (top)
    const registersActive = currentStep === 0
    drawPyramidLevel(
      ctx,
      width * 0.4,
      height * 0.1,
      width * 0.2,
      height * 0.1,
      "Registers",
      "< 1 KB",
      "< 1 ns",
      registersActive ? "#9f7aea" : "#2d3748",
      registersActive,
    )

    // L1 Cache
    const l1Active = currentStep === 1
    drawPyramidLevel(
      ctx,
      width * 0.35,
      height * 0.2,
      width * 0.3,
      height * 0.1,
      "L1 Cache",
      "64 KB",
      "1 ns",
      l1Active ? "#9f7aea" : "#2d3748",
      l1Active,
    )

    // L2 Cache
    const l2Active = currentStep === 2
    drawPyramidLevel(
      ctx,
      width * 0.3,
      height * 0.3,
      width * 0.4,
      height * 0.1,
      "L2 Cache",
      "256 KB",
      "4 ns",
      l2Active ? "#9f7aea" : "#2d3748",
      l2Active,
    )

    // L3 Cache
    const l3Active = currentStep === 3
    drawPyramidLevel(
      ctx,
      width * 0.25,
      height * 0.4,
      width * 0.5,
      height * 0.1,
      "L3 Cache",
      "8 MB",
      "10 ns",
      l3Active ? "#9f7aea" : "#2d3748",
      l3Active,
    )

    // RAM
    const ramActive = currentStep === 4
    drawPyramidLevel(
      ctx,
      width * 0.2,
      height * 0.5,
      width * 0.6,
      height * 0.1,
      "RAM",
      "16 GB",
      "100 ns",
      ramActive ? "#9f7aea" : "#2d3748",
      ramActive,
    )

    // SSD
    const ssdActive = false
    drawPyramidLevel(
      ctx,
      width * 0.15,
      height * 0.6,
      width * 0.7,
      height * 0.1,
      "SSD",
      "1 TB",
      "10 μs",
      ssdActive ? "#9f7aea" : "#2d3748",
      ssdActive,
    )

    // HDD
    const hddActive = false
    drawPyramidLevel(
      ctx,
      width * 0.1,
      height * 0.7,
      width * 0.8,
      height * 0.1,
      "HDD",
      "4 TB",
      "10 ms",
      hddActive ? "#9f7aea" : "#2d3748",
      hddActive,
    )

    // Draw arrows between levels
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2

    // Draw arrows between levels
    for (let i = 0; i < 6; i++) {
      const isActive = i === currentStep || i === currentStep - 1

      // Left arrow (up)
      drawArrow(
        ctx,
        width * (0.4 - i * 0.05),
        height * (0.2 + i * 0.1),
        width * (0.45 - i * 0.05),
        height * (0.15 + i * 0.1),
        isActive,
      )

      // Right arrow (down)
      drawArrow(
        ctx,
        width * (0.6 + i * 0.05),
        height * (0.15 + i * 0.1),
        width * (0.55 + i * 0.05),
        height * (0.2 + i * 0.1),
        isActive,
      )
    }
  }

  // Draw Cache Memory
  const drawCacheMemory = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw cache components

    // CPU
    const cpuActive = currentStep === 0
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "CPU",
      cpuActive ? "#9f7aea" : "#2d3748",
      cpuActive,
    )

    // Cache Controller
    const controllerActive = currentStep === 1
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "Cache Controller",
      controllerActive ? "#9f7aea" : "#2d3748",
      controllerActive,
    )

    // Cache Memory
    const cacheActive = currentStep === 2
    drawComponent(
      ctx,
      width * 0.7,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "Cache Memory",
      cacheActive ? "#9f7aea" : "#2d3748",
      cacheActive,
    )

    // Main Memory
    const memoryActive = currentStep === 3 || currentStep === 4
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.6,
      width * 0.2,
      height * 0.2,
      "Main Memory",
      memoryActive ? "#9f7aea" : "#2d3748",
      memoryActive,
    )

    // Draw connections

    // CPU to Cache Controller
    drawConnection(ctx, width * 0.3, height * 0.3, width * 0.4, height * 0.3, currentStep === 0 || currentStep === 1)

    // Cache Controller to Cache Memory
    drawConnection(ctx, width * 0.6, height * 0.3, width * 0.7, height * 0.3, currentStep === 1 || currentStep === 2)

    // Cache Controller to Main Memory
    drawConnection(ctx, width * 0.5, height * 0.4, width * 0.5, height * 0.6, currentStep === 3 || currentStep === 4)

    // Draw cache lines
    if (cacheActive || memoryActive) {
      const cacheX = width * 0.7
      const cacheY = height * 0.45
      const cacheWidth = width * 0.2
      const cacheHeight = height * 0.3

      ctx.beginPath()
      ctx.rect(cacheX, cacheY, cacheWidth, cacheHeight)
      ctx.fillStyle = "#1a202c"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw cache lines
      const lineHeight = cacheHeight / 8

      for (let i = 0; i < 8; i++) {
        const isActive = i === currentStep % 8

        ctx.beginPath()
        ctx.rect(cacheX, cacheY + i * lineHeight, cacheWidth, lineHeight)
        ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw line content
        ctx.fillStyle = "#ffffff"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(`Cache Line ${i}`, cacheX + cacheWidth / 2, cacheY + i * lineHeight + lineHeight / 2)
      }
    }
  }

  // Add new drawing functions for all architecture concepts

  // Add these new drawing functions after the existing drawCPU, drawMemoryHierarchy, and drawCacheMemory functions:

  // Draw Instruction Pipeline
  const drawPipeline = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw pipeline stages
    const stageWidth = width * 0.15
    const stageHeight = height * 0.15
    const stageGap = width * 0.02
    const startX = width * 0.1
    const startY = height * 0.2

    // Draw stages
    for (let i = 0; i < pipelineStages.length; i++) {
      const x = startX + i * (stageWidth + stageGap)
      const isActive = i === currentStep % pipelineStages.length

      drawComponent(
        ctx,
        x,
        startY,
        stageWidth,
        stageHeight,
        pipelineStages[i],
        isActive ? "#9f7aea" : "#2d3748",
        isActive,
      )

      // Draw arrow to next stage
      if (i < pipelineStages.length - 1) {
        drawArrow(
          ctx,
          x + stageWidth,
          startY + stageHeight / 2,
          x + stageWidth + stageGap,
          startY + stageHeight / 2,
          isActive,
        )
      }
    }

    // Draw instructions in pipeline
    const instructionHeight = height * 0.08
    const instructionGap = height * 0.02

    for (let i = 0; i < Math.min(5, instructions.length); i++) {
      const y = startY + stageHeight + instructionGap + i * (instructionHeight + instructionGap)

      // Draw instruction row
      ctx.fillStyle = i === 0 ? "#4fd1c5" : "#2d3748"
      ctx.fillRect(startX, y, width * 0.8, instructionHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(startX, y, width * 0.8, instructionHeight)

      // Draw instruction text
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(instructions[i], startX + 10, y + instructionHeight / 2)

      // Draw instruction progress
      const maxProgress = Math.min(pipelineStages.length, currentStep + 1)
      for (let j = 0; j < maxProgress - i; j++) {
        if (j >= 0 && j < pipelineStages.length) {
          const x = startX + j * (stageWidth + stageGap)
          const stageProgress = x + stageWidth / 2

          ctx.beginPath()
          ctx.arc(stageProgress, y + instructionHeight / 2, 5, 0, Math.PI * 2)
          ctx.fillStyle = j === maxProgress - i - 1 ? "#9f7aea" : "#4fd1c5"
          ctx.fill()
        }
      }
    }

    // Draw pipeline hazards if applicable
    if (currentStep > 2 && currentStep < 6) {
      ctx.fillStyle = "rgba(239, 68, 68, 0.7)"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.fillText("Data Hazard", width * 0.5, height * 0.8)

      // Draw hazard indicator
      const hazardX = startX + 2 * (stageWidth + stageGap)
      const hazardY = startY + stageHeight + instructionGap + (instructionHeight + instructionGap)

      ctx.beginPath()
      ctx.moveTo(hazardX, hazardY)
      ctx.lineTo(hazardX - 20, hazardY + 20)
      ctx.lineTo(hazardX + 20, hazardY + 20)
      ctx.closePath()
      ctx.fillStyle = "rgba(239, 68, 68, 0.7)"
      ctx.fill()
      ctx.strokeStyle = "#ef4444"
      ctx.lineWidth = 2
      ctx.stroke()
    }
  }

  // Draw Branch Prediction
  const drawBranchPrediction = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw branch predictor
    drawComponent(ctx, width * 0.35, height * 0.15, width * 0.3, height * 0.15, "Branch Predictor", "#2d3748", true)

    // Draw branch history table
    const tableX = width * 0.25
    const tableY = height * 0.4
    const cellWidth = width * 0.1
    const cellHeight = height * 0.08

    // Table header
    ctx.fillStyle = "#4fd1c5"
    ctx.fillRect(tableX, tableY, cellWidth * 2, cellHeight)
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 1
    ctx.strokeRect(tableX, tableY, cellWidth * 2, cellHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Branch Address", tableX + cellWidth * 0.5, tableY + cellHeight * 0.5)
    ctx.fillText("Prediction", tableX + cellWidth * 1.5, tableY + cellHeight * 0.5)

    // Table rows
    for (let i = 0; i < 5; i++) {
      const rowY = tableY + cellHeight * (i + 1)
      const isActive = i === currentStep % 5

      // Address column
      ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
      ctx.fillRect(tableX, rowY, cellWidth, cellHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(tableX, rowY, cellWidth, cellHeight)

      ctx.fillStyle = "#ffffff"
      ctx.fillText(
        `0x${(0x1000 + i * 0x100).toString(16).toUpperCase()}`,
        tableX + cellWidth * 0.5,
        rowY + cellHeight * 0.5,
      )

      // Prediction column
      ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
      ctx.fillRect(tableX + cellWidth, rowY, cellWidth, cellHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(tableX + cellWidth, rowY, cellWidth, cellHeight)

      const branchTaken = branchHistory[i % branchHistory.length]
      ctx.fillStyle = "#ffffff"
      ctx.fillText(branchTaken ? "Taken" : "Not Taken", tableX + cellWidth * 1.5, rowY + cellHeight * 0.5)
    }

    // Draw current prediction
    drawComponent(
      ctx,
      width * 0.6,
      height * 0.4,
      width * 0.2,
      height * 0.15,
      `Prediction: ${prediction ? "Taken" : "Not Taken"}`,
      prediction ? "#4fd1c5" : "#ef4444",
      true,
    )

    // Draw branch outcome
    const outcomeY = height * 0.65
    const branchTaken = branchHistory[currentStep % branchHistory.length]
    const correct = branchTaken === prediction

    drawComponent(
      ctx,
      width * 0.35,
      outcomeY,
      width * 0.3,
      height * 0.15,
      `Actual: ${branchTaken ? "Taken" : "Not Taken"}`,
      branchTaken ? "#4fd1c5" : "#ef4444",
      true,
    )

    // Draw prediction result
    drawComponent(
      ctx,
      width * 0.35,
      outcomeY + height * 0.2,
      width * 0.3,
      height * 0.1,
      `Prediction ${correct ? "Correct" : "Incorrect"}`,
      correct ? "#10b981" : "#ef4444",
      true,
    )
  }

  // Draw RISC Architecture
  const drawRISC = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw RISC CPU
    drawComponent(ctx, width * 0.3, height * 0.1, width * 0.4, height * 0.2, "RISC CPU", "#2d3748", true)

    // Draw register file
    drawComponent(
      ctx,
      width * 0.15,
      height * 0.4,
      width * 0.3,
      height * 0.2,
      "Register File (32 registers)",
      currentStep % 3 === 0 ? "#9f7aea" : "#2d3748",
      currentStep % 3 === 0,
    )

    // Draw ALU
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.4,
      width * 0.3,
      height * 0.2,
      "Simple ALU",
      currentStep % 3 === 1 ? "#9f7aea" : "#2d3748",
      currentStep % 3 === 1,
    )

    // Draw connections
    drawConnection(
      ctx,
      width * 0.45,
      height * 0.5,
      width * 0.55,
      height * 0.5,
      currentStep % 3 === 0 || currentStep % 3 === 1,
    )

    // Draw memory
    drawComponent(
      ctx,
      width * 0.3,
      height * 0.7,
      width * 0.4,
      height * 0.2,
      "Memory",
      currentStep % 3 === 2 ? "#9f7aea" : "#2d3748",
      currentStep % 3 === 2,
    )

    // Draw connections to memory
    drawConnection(
      ctx,
      width * 0.3,
      height * 0.5,
      width * 0.3,
      height * 0.7,
      currentStep % 3 === 0 || currentStep % 3 === 2,
    )
    drawConnection(
      ctx,
      width * 0.7,
      height * 0.5,
      width * 0.7,
      height * 0.7,
      currentStep % 3 === 1 || currentStep % 3 === 2,
    )

    // Draw instruction list
    const instructionX = width * 0.05
    const instructionY = height * 0.1
    const instructionWidth = width * 0.2
    const instructionHeight = height * 0.05

    ctx.fillStyle = "#2d3748"
    ctx.fillRect(instructionX, instructionY, instructionWidth, instructionHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(instructionX, instructionY, instructionWidth, instructionHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("RISC Instructions", instructionX + instructionWidth / 2, instructionY + instructionHeight / 2)

    // Draw instructions
    for (let i = 0; i < riscInstructions.length; i++) {
      const y = instructionY + instructionHeight * (i + 1)
      const isActive = i === currentStep % riscInstructions.length

      ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
      ctx.fillRect(instructionX, y, instructionWidth, instructionHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(instructionX, y, instructionWidth, instructionHeight)

      ctx.fillStyle = "#ffffff"
      ctx.fillText(riscInstructions[i], instructionX + instructionWidth / 2, y + instructionHeight / 2)
    }

    // Draw RISC characteristics
    const charX = width * 0.75
    const charY = height * 0.1
    const charWidth = width * 0.2
    const charHeight = height * 0.05

    const characteristics = [
      "Fixed instruction length",
      "Load-store architecture",
      "Many registers",
      "Simple addressing modes",
      "Few instruction formats",
    ]

    ctx.fillStyle = "#2d3748"
    ctx.fillRect(charX, charY, charWidth, charHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(charX, charY, charWidth, charHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("RISC Characteristics", charX + charWidth / 2, charY + charHeight / 2)

    for (let i = 0; i < characteristics.length; i++) {
      const y = charY + charHeight * (i + 1)

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(charX, y, charWidth, charHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(charX, y, charWidth, charHeight)

      ctx.fillStyle = "#ffffff"
      ctx.fillText(characteristics[i], charX + charWidth / 2, y + charHeight / 2)
    }
  }

  // Draw CISC Architecture
  const drawCISC = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw CISC CPU
    drawComponent(ctx, width * 0.3, height * 0.1, width * 0.4, height * 0.2, "CISC CPU", "#2d3748", true)

    // Draw register file (fewer registers)
    drawComponent(
      ctx,
      width * 0.15,
      height * 0.4,
      width * 0.3,
      height * 0.2,
      "Register File (8-16 registers)",
      currentStep % 4 === 0 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 0,
    )

    // Draw complex ALU
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.4,
      width * 0.3,
      height * 0.2,
      "Complex ALU",
      currentStep % 4 === 1 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 1,
    )

    // Draw microcode ROM
    drawComponent(
      ctx,
      width * 0.15,
      height * 0.7,
      width * 0.3,
      height * 0.2,
      "Microcode ROM",
      currentStep % 4 === 2 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 2,
    )

    // Draw memory
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.7,
      width * 0.3,
      height * 0.2,
      "Memory",
      currentStep % 4 === 3 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 3,
    )

    // Draw connections
    drawConnection(
      ctx,
      width * 0.45,
      height * 0.5,
      width * 0.55,
      height * 0.5,
      currentStep % 4 === 0 || currentStep % 4 === 1,
    )
    drawConnection(
      ctx,
      width * 0.3,
      height * 0.6,
      width * 0.3,
      height * 0.7,
      currentStep % 4 === 0 || currentStep % 4 === 2,
    )
    drawConnection(
      ctx,
      width * 0.45,
      height * 0.8,
      width * 0.55,
      height * 0.8,
      currentStep % 4 === 2 || currentStep % 4 === 3,
    )
    drawConnection(
      ctx,
      width * 0.7,
      height * 0.6,
      width * 0.7,
      height * 0.7,
      currentStep % 4 === 1 || currentStep % 4 === 3,
    )

    // Draw instruction list
    const instructionX = width * 0.05
    const instructionY = height * 0.1
    const instructionWidth = width * 0.2
    const instructionHeight = height * 0.05

    ctx.fillStyle = "#2d3748"
    ctx.fillRect(instructionX, instructionY, instructionWidth, instructionHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(instructionX, instructionY, instructionWidth, instructionHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("CISC Instructions", instructionX + instructionWidth / 2, instructionY + instructionHeight / 2)

    // Draw instructions
    for (let i = 0; i < ciscInstructions.length; i++) {
      const y = instructionY + instructionHeight * (i + 1)
      const isActive = i === currentStep % ciscInstructions.length

      ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
      ctx.fillRect(instructionX, y, instructionWidth, instructionHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(instructionX, y, instructionWidth, instructionHeight)

      ctx.fillStyle = "#ffffff"
      ctx.fillText(ciscInstructions[i], instructionX + instructionWidth / 2, y + instructionHeight / 2)
    }

    // Draw CISC characteristics
    const charX = width * 0.75
    const charY = height * 0.1
    const charWidth = width * 0.2
    const charHeight = height * 0.05

    const characteristics = [
      "Variable instruction length",
      "Memory-to-memory ops",
      "Few registers",
      "Complex addressing modes",
      "Many instruction formats",
    ]

    ctx.fillStyle = "#2d3748"
    ctx.fillRect(charX, charY, charWidth, charHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(charX, charY, charWidth, charHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("CISC Characteristics", charX + charWidth / 2, charY + charHeight / 2)

    for (let i = 0; i < characteristics.length; i++) {
      const y = charY + charHeight * (i + 1)

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(charX, y, charWidth, charHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(charX, y, charWidth, charHeight)

      ctx.fillStyle = "#ffffff"
      ctx.fillText(characteristics[i], charX + charWidth / 2, y + charHeight / 2)
    }
  }

  // Draw Virtual Memory
  const drawVirtualMemory = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw CPU
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "CPU",
      currentStep === 0 ? "#9f7aea" : "#2d3748",
      currentStep === 0,
    )

    // Draw MMU (Memory Management Unit)
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "MMU",
      currentStep === 1 ? "#9f7aea" : "#2d3748",
      currentStep === 1,
    )

    // Draw Page Table
    drawComponent(
      ctx,
      width * 0.7,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "Page Table",
      currentStep === 2 ? "#9f7aea" : "#2d3748",
      currentStep === 2,
    )

    // Draw Physical Memory
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.6,
      width * 0.2,
      height * 0.3,
      "Physical Memory",
      currentStep === 4 ? "#9f7aea" : "#2d3748",
      currentStep === 4,
    )

    // Draw Virtual Memory
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.6,
      width * 0.2,
      height * 0.3,
      "Virtual Memory",
      currentStep === 3 ? "#9f7aea" : "#2d3748",
      currentStep === 3,
    )

    // Draw Disk Storage
    drawComponent(
      ctx,
      width * 0.7,
      height * 0.6,
      width * 0.2,
      height * 0.3,
      "Disk Storage",
      currentStep === 5 ? "#9f7aea" : "#2d3748",
      currentStep === 5,
    )

    // Draw connections
    drawConnection(ctx, width * 0.3, height * 0.3, width * 0.4, height * 0.3, currentStep === 0 || currentStep === 1)
    drawConnection(ctx, width * 0.6, height * 0.3, width * 0.7, height * 0.3, currentStep === 1 || currentStep === 2)
    drawConnection(ctx, width * 0.2, height * 0.4, width * 0.2, height * 0.6, currentStep === 0 || currentStep === 3)
    drawConnection(ctx, width * 0.5, height * 0.4, width * 0.5, height * 0.6, currentStep === 1 || currentStep === 4)
    drawConnection(ctx, width * 0.8, height * 0.4, width * 0.8, height * 0.6, currentStep === 2 || currentStep === 5)
    drawConnection(ctx, width * 0.3, height * 0.75, width * 0.4, height * 0.75, currentStep === 3 || currentStep === 4)
    drawConnection(ctx, width * 0.6, height * 0.75, width * 0.7, height * 0.75, currentStep === 4 || currentStep === 5)

    // Draw page mapping
    if (currentStep > 1) {
      const pageX = width * 0.3
      const pageY = height * 0.45
      const pageWidth = width * 0.4
      const pageHeight = height * 0.1

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(pageX, pageY, pageWidth, pageHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(pageX, pageY, pageWidth, pageHeight)

      const virtualPage = virtualPages[currentStep % virtualPages.length]
      const physicalFrame = pageTable[virtualPage] >= 0 ? pageTable[virtualPage] : "Disk"

      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(
        `Virtual Page ${virtualPage} → ${physicalFrame === "Disk" ? "Disk (Page Fault)" : "Physical Frame " + physicalFrame}`,
        pageX + pageWidth / 2,
        pageY + pageHeight / 2,
      )

      // Highlight the mapping with an arrow
      if (physicalFrame !== "Disk") {
        drawArrow(
          ctx,
          width * 0.2,
          height * 0.6 + virtualPage * 0.03,
          width * 0.4,
          height * 0.6 + physicalFrame * 0.05,
          true,
        )
      } else {
        drawArrow(ctx, width * 0.2, height * 0.6 + virtualPage * 0.03, width * 0.7, height * 0.7, true)
      }
    }
  }

  // Draw RAM
  const drawRAM = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw RAM module
    drawComponent(ctx, width * 0.3, height * 0.1, width * 0.4, height * 0.2, "RAM Module", "#2d3748", true)

    // Draw memory controller
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.4,
      width * 0.2,
      height * 0.2,
      "Memory Controller",
      currentStep % 4 === 0 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 0,
    )

    // Draw memory cells
    const cellX = width * 0.4
    const cellY = height * 0.4
    const cellWidth = width * 0.4
    const cellHeight = height * 0.5

    ctx.fillStyle = "#2d3748"
    ctx.fillRect(cellX, cellY, cellWidth, cellHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.strokeRect(cellX, cellY, cellWidth, cellHeight)

    // Draw memory blocks
    const blockHeight = cellHeight / 5

    for (let i = 0; i < 5; i++) {
      const y = cellY + i * blockHeight
      const isActive = i === currentStep % 5

      ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
      ctx.fillRect(cellX, y, cellWidth, blockHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(cellX, y, cellWidth, blockHeight)

      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(ramBlocks[i], cellX + cellWidth / 2, y + blockHeight / 2)
    }

    // Draw connection from controller to active block
    const activeBlock = currentStep % 5
    drawConnection(
      ctx,
      width * 0.3,
      height * 0.5,
      width * 0.4,
      cellY + activeBlock * blockHeight + blockHeight / 2,
      true,
    )

    // Draw RAM characteristics
    const charX = width * 0.1
    const charY = height * 0.7
    const charWidth = width * 0.2
    const charHeight = height * 0.05

    const characteristics = [
      "Volatile Memory",
      "Random Access",
      "Fast Read/Write",
      "Direct CPU Access",
      "Measured in GB",
    ]

    for (let i = 0; i < characteristics.length; i++) {
      const y = charY + charHeight * i

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(charX, y, charWidth, charHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(charX, y, charWidth, charHeight)

      ctx.fillStyle = "#ffffff"
      ctx.font = "10px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(characteristics[i], charX + charWidth / 2, y + charHeight / 2)
    }
  }

  // Draw Von Neumann Architecture
  const drawVonNeumann = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw CPU
    drawComponent(
      ctx,
      width * 0.2,
      height * 0.2,
      width * 0.25,
      height * 0.25,
      "CPU",
      currentStep % 4 === 0 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 0,
    )

    // Draw Memory
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.2,
      width * 0.25,
      height * 0.25,
      "Memory\n(Data & Instructions)",
      currentStep % 4 === 1 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 1,
    )

    // Draw Input
    drawComponent(
      ctx,
      width * 0.2,
      height * 0.6,
      width * 0.25,
      height * 0.2,
      "Input",
      currentStep % 4 === 2 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 2,
    )

    // Draw Output
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.6,
      width * 0.25,
      height * 0.2,
      "Output",
      currentStep % 4 === 3 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 3,
    )

    // Draw Bus
    ctx.fillStyle = "#2d3748"
    ctx.fillRect(width * 0.1, height * 0.5, width * 0.8, height * 0.05)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.1, height * 0.5, width * 0.8, height * 0.05)

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Common Bus (Data & Instructions)", width * 0.5, height * 0.525)

    // Draw connections
    drawConnection(ctx, width * 0.325, height * 0.45, width * 0.325, height * 0.5, currentStep % 4 === 0)
    drawConnection(ctx, width * 0.675, height * 0.45, width * 0.675, height * 0.5, currentStep % 4 === 1)
    drawConnection(ctx, width * 0.325, height * 0.55, width * 0.325, height * 0.6, currentStep % 4 === 2)
    drawConnection(ctx, width * 0.675, height * 0.55, width * 0.675, height * 0.6, currentStep % 4 === 3)

    // Draw Von Neumann bottleneck
    if (currentStep > 3) {
      ctx.fillStyle = "rgba(239, 68, 68, 0.7)"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.fillText("Von Neumann Bottleneck", width * 0.5, height * 0.45)

      // Draw bottleneck indicator
      ctx.beginPath()
      ctx.moveTo(width * 0.45, height * 0.5)
      ctx.lineTo(width * 0.55, height * 0.5)
      ctx.lineTo(width * 0.55, height * 0.55)
      ctx.lineTo(width * 0.45, height * 0.55)
      ctx.closePath()
      ctx.fillStyle = "rgba(239, 68, 68, 0.5)"
      ctx.fill()
      ctx.strokeStyle = "#ef4444"
      ctx.lineWidth = 2
      ctx.stroke()
    }
  }

  // Draw Harvard Architecture
  const drawHarvard = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw CPU
    drawComponent(
      ctx,
      width * 0.375,
      height * 0.1,
      width * 0.25,
      height * 0.2,
      "CPU",
      currentStep % 4 === 0 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 0,
    )

    // Draw Instruction Memory
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.4,
      width * 0.25,
      height * 0.2,
      "Instruction Memory",
      currentStep % 4 === 1 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 1,
    )

    // Draw Data Memory
    drawComponent(
      ctx,
      width * 0.65,
      height * 0.4,
      width * 0.25,
      height * 0.2,
      "Data Memory",
      currentStep % 4 === 2 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 2,
    )

    // Draw I/O
    drawComponent(
      ctx,
      width * 0.375,
      height * 0.7,
      width * 0.25,
      height * 0.2,
      "Input/Output",
      currentStep % 4 === 3 ? "#9f7aea" : "#2d3748",
      currentStep % 4 === 3,
    )

    // Draw Instruction Bus
    ctx.fillStyle = "#2d3748"
    ctx.fillRect(width * 0.225, height * 0.3, width * 0.025, height * 0.1)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(width * 0.225, height * 0.3, width * 0.025, height * 0.1)

    ctx.save()
    ctx.translate(width * 0.2375, height * 0.35)
    ctx.rotate(-Math.PI / 2)
    ctx.fillStyle = "#ffffff"
    ctx.font = "10px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Instruction Bus", 0, 0)
    ctx.restore()

    // Draw Data Bus
    ctx.fillStyle = "#2d3748"
    ctx.fillRect(width * 0.75, height * 0.3, width * 0.025, height * 0.1)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(width * 0.75, height * 0.3, width * 0.025, height * 0.1)

    ctx.save()
    ctx.translate(width * 0.7625, height * 0.35)
    ctx.rotate(-Math.PI / 2)
    ctx.fillStyle = "#ffffff"
    ctx.font = "10px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("Data Bus", 0, 0)
    ctx.restore()

    // Draw I/O Bus
    ctx.fillStyle = "#2d3748"
    ctx.fillRect(width * 0.5, height * 0.6, width * 0.025, height * 0.1)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(width * 0.5, height * 0.6, width * 0.025, height * 0.1)

    ctx.save()
    ctx.translate(width * 0.5125, height * 0.65)
    ctx.rotate(-Math.PI / 2)
    ctx.fillStyle = "#ffffff"
    ctx.font = "10px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("I/O Bus", 0, 0)
    ctx.restore()

    // Draw connections
    drawConnection(
      ctx,
      width * 0.225,
      height * 0.3,
      width * 0.375,
      height * 0.2,
      currentStep % 4 === 0 || currentStep % 4 === 1,
    )
    drawConnection(
      ctx,
      width * 0.625,
      height * 0.2,
      width * 0.75,
      height * 0.3,
      currentStep % 4 === 0 || currentStep % 4 === 2,
    )
    drawConnection(
      ctx,
      width * 0.5,
      height * 0.3,
      width * 0.5,
      height * 0.6,
      currentStep % 4 === 0 || currentStep % 4 === 3,
    )

    // Draw Harvard advantages
    if (currentStep > 3) {
      const advantageX = width * 0.05
      const advantageY = height * 0.05
      const advantageWidth = width * 0.25
      const advantageHeight = height * 0.05

      const advantages = ["Parallel Access", "No Bus Contention", "Separate Optimizations", "Higher Performance"]

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(advantageX, advantageY, advantageWidth, advantageHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(advantageX, advantageY, advantageWidth, advantageHeight)

      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("Harvard Advantages", advantageX + advantageWidth / 2, advantageY + advantageHeight / 2)

      for (let i = 0; i < advantages.length; i++) {
        const y = advantageY + advantageHeight * (i + 1)

        ctx.fillStyle = "#2d3748"
        ctx.fillRect(advantageX, y, advantageWidth, advantageHeight)
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.strokeRect(advantageX, y, advantageWidth, advantageHeight)

        ctx.fillStyle = "#ffffff"
        ctx.fillText(advantages[i], advantageX + advantageWidth / 2, y + advantageHeight / 2)
      }
    }
  }

  // Draw Bus Architecture
  const drawBusArchitecture = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw System Bus
    ctx.fillStyle = "#2d3748"
    ctx.fillRect(width * 0.1, height * 0.45, width * 0.8, height * 0.1)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.strokeRect(width * 0.1, height * 0.45, width * 0.8, height * 0.1)

    ctx.fillStyle = "#ffffff"
    ctx.font = "14px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("System Bus", width * 0.5, height * 0.5)

    // Draw CPU
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.2,
      width * 0.2,
      height * 0.15,
      "CPU",
      currentStep % 5 === 0 ? "#9f7aea" : "#2d3748",
      currentStep % 5 === 0,
    )

    // Draw Memory
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.2,
      width * 0.2,
      height * 0.15,
      "Memory",
      currentStep % 5 === 1 ? "#9f7aea" : "#2d3748",
      currentStep % 5 === 1,
    )

    // Draw I/O Controller
    drawComponent(
      ctx,
      width * 0.7,
      height * 0.2,
      width * 0.2,
      height * 0.15,
      "I/O Controller",
      currentStep % 5 === 2 ? "#9f7aea" : "#2d3748",
      currentStep % 5 === 2,
    )

    // Draw Disk
    drawComponent(
      ctx,
      width * 0.25,
      height * 0.65,
      width * 0.2,
      height * 0.15,
      "Disk Storage",
      currentStep % 5 === 3 ? "#9f7aea" : "#2d3748",
      currentStep % 5 === 3,
    )

    // Draw Network Interface
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.65,
      width * 0.2,
      height * 0.15,
      "Network Interface",
      currentStep % 5 === 4 ? "#9f7aea" : "#2d3748",
      currentStep % 5 === 4,
    )

    // Draw connections to bus
    drawConnection(ctx, width * 0.2, height * 0.35, width * 0.2, height * 0.45, currentStep % 5 === 0)
    drawConnection(ctx, width * 0.5, height * 0.35, width * 0.5, height * 0.45, currentStep % 5 === 1)
    drawConnection(ctx, width * 0.8, height * 0.35, width * 0.8, height * 0.45, currentStep % 5 === 2)
    drawConnection(ctx, width * 0.35, height * 0.55, width * 0.35, height * 0.65, currentStep % 5 === 3)
    drawConnection(ctx, width * 0.65, height * 0.55, width * 0.65, height * 0.65, currentStep % 5 === 4)

    // Draw bus types
    const busX = width * 0.1
    const busWidth = width * 0.8
    const busHeight = height * 0.03

    // Address bus
    ctx.fillStyle = currentStep > 5 ? "#4fd1c5" : "#2d3748"
    ctx.fillRect(busX, height * 0.45, busWidth, busHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(busX, height * 0.45, busWidth, busHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "10px Arial"
    ctx.fillText("Address Bus", width * 0.5, height * 0.465)

    // Data bus
    ctx.fillStyle = currentStep > 6 ? "#9f7aea" : "#2d3748"
    ctx.fillRect(busX, height * 0.48, busWidth, busHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(busX, height * 0.48, busWidth, busHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "10px Arial"
    ctx.fillText("Data Bus", width * 0.5, height * 0.495)

    // Control bus
    ctx.fillStyle = currentStep > 7 ? "#f59e0b" : "#2d3748"
    ctx.fillRect(busX, height * 0.51, busWidth, busHeight)
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1
    ctx.strokeRect(busX, height * 0.51, busWidth, busHeight)

    ctx.fillStyle = "#ffffff"
    ctx.font = "10px Arial"
    ctx.fillText("Control Bus", width * 0.5, height * 0.525)

    // Draw bus characteristics
    if (currentStep > 5) {
      const charX = width * 0.05
      const charY = height * 0.8
      const charWidth = width * 0.9
      const charHeight = height * 0.05

      ctx.fillStyle = "#2d3748"
      ctx.fillRect(charX, charY, charWidth, charHeight)
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.strokeRect(charX, charY, charWidth, charHeight)

      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      if (currentStep % 3 === 0) {
        ctx.fillText(
          "Address Bus: Carries memory addresses for read/write operations",
          charX + charWidth / 2,
          charY + charHeight / 2,
        )
      } else if (currentStep % 3 === 1) {
        ctx.fillText("Data Bus: Carries actual data between components", charX + charWidth / 2, charY + charHeight / 2)
      } else {
        ctx.fillText(
          "Control Bus: Carries control signals like read/write, interrupt, etc.",
          charX + charWidth / 2,
          charY + charHeight / 2,
        )
      }
    }
  }

  // Helper function to draw a component
  const drawComponent = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    label: string,
    color: string,
    isActive: boolean,
  ) => {
    ctx.beginPath()
    ctx.rect(x, y, width, height)
    ctx.fillStyle = color
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Add glow effect if active
    if (isActive) {
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 15
      ctx.stroke()
      ctx.shadowBlur = 0
    }

    // Draw label
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(label, x + width / 2, y + height / 2)
  }

  // Helper function to draw a connection
  const drawConnection = (
    ctx: CanvasRenderingContext2D,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    isActive: boolean,
  ) => {
    ctx.beginPath()
    ctx.moveTo(x1, y1)
    ctx.lineTo(x2, y2)

    if (isActive) {
      ctx.strokeStyle = "#9f7aea"
      ctx.lineWidth = 3
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 10
    } else {
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.shadowBlur = 0
    }

    ctx.stroke()
    ctx.shadowBlur = 0
  }

  // Helper function to draw a pyramid level
  const drawPyramidLevel = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    label: string,
    size: string,
    speed: string,
    color: string,
    isActive: boolean,
  ) => {
    ctx.beginPath()
    ctx.rect(x, y, width, height)
    ctx.fillStyle = color
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Add glow effect if active
    if (isActive) {
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 15
      ctx.stroke()
      ctx.shadowBlur = 0
    }

    // Draw label
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(label, x + width / 2, y + height * 0.3)

    // Draw size and speed
    ctx.font = "10px Arial"
    ctx.fillText(size, x + width / 2, y + height * 0.6)
    ctx.fillText(speed, x + width / 2, y + height * 0.8)
  }

  // Helper function to draw an arrow
  const drawArrow = (
    ctx: CanvasRenderingContext2D,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    isActive: boolean,
  ) => {
    const headLength = 10
    const angle = Math.atan2(y2 - y1, x2 - x1)

    ctx.beginPath()
    ctx.moveTo(x1, y1)
    ctx.lineTo(x2, y2)

    // Draw arrowhead
    ctx.lineTo(x2 - headLength * Math.cos(angle - Math.PI / 6), y2 - headLength * Math.sin(angle - Math.PI / 6))
    ctx.moveTo(x2, y2)
    ctx.lineTo(x2 - headLength * Math.cos(angle + Math.PI / 6), y2 - headLength * Math.sin(angle + Math.PI / 6))

    if (isActive) {
      ctx.strokeStyle = "#9f7aea"
      ctx.lineWidth = 2
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 10
    } else {
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.shadowBlur = 0
    }

    ctx.stroke()
    ctx.shadowBlur = 0
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setStep(0)
    setIsPlaying(false)

    // Set initial message based on component
    if (component === "cpu") {
      setMessage("CPU is idle")
    } else if (component === "memory") {
      setMessage("Memory hierarchy visualization")
    } else if (component === "cache") {
      setMessage("Cache memory visualization")
    }
  }

  // Add concept-specific visualization logic
  // Update the useEffect that sets component based on selected concept

  // Replace the existing useEffect with this more comprehensive one:
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setStep(0)
      setIsPlaying(false)

      // Set component and message based on selected concept
      if (selectedConcept.toLowerCase().includes("cpu")) {
        setComponent("cpu")
        setMessage("CPU Architecture: The design and organization of the central processing unit.")
      } else if (selectedConcept.toLowerCase().includes("instruction pipeline")) {
        setComponent("pipeline")
        setMessage(
          "Instruction Pipeline: A technique used to increase instruction throughput by overlapping the execution of multiple instructions.",
        )
      } else if (selectedConcept.toLowerCase().includes("branch prediction")) {
        setComponent("branch")
        setMessage(
          "Branch Prediction: A technique used by CPUs to guess the outcome of conditional branches to improve performance.",
        )
      } else if (selectedConcept.toLowerCase().includes("risc")) {
        setComponent("risc")
        setMessage(
          "RISC: Reduced Instruction Set Computer - A CPU design with simplified instructions that execute in a single cycle.",
        )
      } else if (selectedConcept.toLowerCase().includes("cisc")) {
        setComponent("cisc")
        setMessage(
          "CISC: Complex Instruction Set Computer - A CPU design with complex instructions that may take multiple cycles to execute.",
        )
      } else if (selectedConcept.toLowerCase().includes("memory hierarchy")) {
        setComponent("memory")
        setMessage(
          "Memory Hierarchy: The organization of memory into different levels based on access speed and capacity.",
        )
      } else if (selectedConcept.toLowerCase().includes("virtual memory")) {
        setComponent("virtual")
        setMessage(
          "Virtual Memory: A memory management technique that provides an idealized abstraction of the storage resources available to a program.",
        )
      } else if (selectedConcept.toLowerCase().includes("ram")) {
        setComponent("ram")
        setMessage(
          "RAM (Random Access Memory): The main memory of a computer, used to store data that is actively being used.",
        )
      } else if (selectedConcept.toLowerCase().includes("cache")) {
        setComponent("cache")
        setMessage(
          "Cache Memory: A small, fast memory that stores copies of frequently accessed data from main memory.",
        )
      } else if (selectedConcept.toLowerCase().includes("l1")) {
        setComponent("l1")
        setMessage("L1 Cache: The smallest and fastest cache memory, located closest to the CPU core.")
      } else if (selectedConcept.toLowerCase().includes("l2")) {
        setComponent("l2")
        setMessage(
          "L2 Cache: A secondary cache that is larger but slower than L1, shared between cores in some architectures.",
        )
      } else if (selectedConcept.toLowerCase().includes("l3")) {
        setComponent("l3")
        setMessage("L3 Cache: A third-level cache that is larger but slower than L2, typically shared among all cores.")
      } else if (selectedConcept.toLowerCase().includes("von neumann")) {
        setComponent("von")
        setMessage(
          "Von Neumann Architecture: A computer design where the same memory is used for both program instructions and data.",
        )
      } else if (selectedConcept.toLowerCase().includes("harvard")) {
        setComponent("harvard")
        setMessage(
          "Harvard Architecture: A computer design where separate memories are used for program instructions and data.",
        )
      } else if (selectedConcept.toLowerCase().includes("bus")) {
        setComponent("bus")
        setMessage(
          "Bus Architecture: The communication system that transfers data between components inside a computer.",
        )
      } else {
        // Default to CPU if no specific concept is matched
        setComponent("cpu")
        setMessage("Computer Architecture: The design and organization of computer systems.")
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Computer Architecture Visualizer`
    }
  }, [selectedConcept])

  // Placeholder functions for new components

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Computer Architecture Visualizer
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Explore how computers work at the hardware level
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Architecture Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Component Selection</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Select Component</h3>
                    <Tabs
                      defaultValue="cpu"
                      value={component}
                      onValueChange={(value) => {
                        setComponent(value)
                        resetAnimation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="cpu">CPU</TabsTrigger>
                        <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
                        <TabsTrigger value="branch">Branch Prediction</TabsTrigger>
                        <TabsTrigger value="risc">RISC</TabsTrigger>
                        <TabsTrigger value="cisc">CISC</TabsTrigger>
                        <TabsTrigger value="memory">Memory</TabsTrigger>
                        <TabsTrigger value="virtual">Virtual Memory</TabsTrigger>
                        <TabsTrigger value="ram">RAM</TabsTrigger>
                        <TabsTrigger value="cache">Cache</TabsTrigger>
                        <TabsTrigger value="l1">L1 Cache</TabsTrigger>
                        <TabsTrigger value="l2">L2 Cache</TabsTrigger>
                        <TabsTrigger value="l3">L3 Cache</TabsTrigger>
                        <TabsTrigger value="von">Von Neumann</TabsTrigger>
                        <TabsTrigger value="harvard">Harvard</TabsTrigger>
                        <TabsTrigger value="bus">Bus</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Component Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {component === "cpu" ? (
                        <>
                          <p>The CPU (Central Processing Unit) is the brain of the computer. It consists of:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Control Unit: Directs the operation of the processor</li>
                            <li>ALU (Arithmetic Logic Unit): Performs mathematical operations</li>
                            <li>Registers: Small, fast storage locations</li>
                            <li>Cache: High-speed memory for frequently accessed data</li>
                          </ul>
                          <p className="mt-2">The CPU follows a fetch-decode-execute cycle:</p>
                          <ol className="list-decimal pl-5 space-y-1 mt-1">
                            <li>Fetch instruction from memory</li>
                            <li>Decode the instruction</li>
                            <li>Execute the instruction</li>
                            <li>Access memory if needed</li>
                            <li>Write back results</li>
                          </ol>
                        </>
                      ) : component === "memory" ? (
                        <>
                          <p>
                            The memory hierarchy is organized in levels, with faster but smaller memory closer to the
                            CPU:
                          </p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Registers: Fastest, smallest memory inside the CPU</li>
                            <li>Cache (L1, L2, L3): High-speed memory for frequently accessed data</li>
                            <li>RAM: Main memory that stores active programs and data</li>
                            <li>Storage (SSD, HDD): Permanent storage for files and programs</li>
                          </ul>
                          <p className="mt-2">
                            The principle of locality states that programs tend to access the same data repeatedly,
                            making caching effective.
                          </p>
                        </>
                      ) : component === "cache" ? (
                        <>
                          <p>Cache memory bridges the speed gap between the CPU and main memory:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Cache Controller: Manages data transfer between cache and main memory</li>
                            <li>Cache Lines: Fixed-size blocks of data transferred between cache and memory</li>
                            <li>Cache Hit: When requested data is found in the cache</li>
                            <li>Cache Miss: When data must be fetched from main memory</li>
                          </ul>
                          <p className="mt-2">
                            Modern CPUs typically have multiple levels of cache (L1, L2, L3) with different sizes and
                            speeds to optimize performance.
                          </p>
                        </>
                      ) : component === "pipeline" ? (
                        <>
                          <p>Instruction Pipelining increases throughput by overlapping instruction execution.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Fetch: Retrieve the next instruction from memory.</li>
                            <li>Decode: Determine the operation and operands.</li>
                            <li>Execute: Perform the operation.</li>
                            <li>Write Back: Store the result.</li>
                          </ul>
                        </>
                      ) : component === "branch" ? (
                        <>
                          <p>Branch prediction attempts to guess the outcome of conditional branches.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Reduces stalls caused by waiting for branch resolution.</li>
                            <li>Uses algorithms like static or dynamic prediction.</li>
                          </ul>
                        </>
                      ) : component === "risc" ? (
                        <>
                          <p>RISC architectures use a simplified instruction set.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Fixed-length instructions.</li>
                            <li>Load-store architecture.</li>
                          </ul>
                        </>
                      ) : component === "cisc" ? (
                        <>
                          <p>CISC architectures use a complex instruction set.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Variable-length instructions.</li>
                            <li>More complex addressing modes.</li>
                          </ul>
                        </>
                      ) : component === "virtual" ? (
                        <>
                          <p>Virtual memory provides an abstraction of memory resources.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Allows programs to use more memory than physically available.</li>
                            <li>Uses techniques like paging and swapping.</li>
                          </ul>
                        </>
                      ) : component === "ram" ? (
                        <>
                          <p>RAM is the main memory of a computer.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Volatile memory that stores active programs and data.</li>
                            <li>Provides fast access to data.</li>
                          </ul>
                        </>
                      ) : component === "l1" ? (
                        <>
                          <p>L1 cache is the fastest and smallest cache memory.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Located closest to the CPU core.</li>
                            <li>Stores frequently accessed data for quick retrieval.</li>
                          </ul>
                        </>
                      ) : component === "l2" ? (
                        <>
                          <p>L2 cache is a secondary cache memory.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Larger but slower than L1 cache.</li>
                            <li>May be shared between cores.</li>
                          </ul>
                        </>
                      ) : component === "l3" ? (
                        <>
                          <p>L3 cache is a third-level cache memory.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Larger but slower than L2 cache.</li>
                            <li>Typically shared among all cores.</li>
                          </ul>
                        </>
                      ) : component === "von" ? (
                        <>
                          <p>
                            The Von Neumann architecture uses a single address space for both instructions and data.
                          </p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Simple and flexible design.</li>
                          </ul>
                        </>
                      ) : component === "harvard" ? (
                        <>
                          <p>The Harvard architecture uses separate address spaces for instructions and data.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Allows simultaneous access to instructions and data.</li>
                          </ul>
                        </>
                      ) : component === "bus" ? (
                        <>
                          <p>A bus is a communication system that transfers data between components.</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Connects CPU, memory, and peripherals.</li>
                          </ul>
                        </>
                      ) : (
                        <></>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="architecture" title="Computer Architecture" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
