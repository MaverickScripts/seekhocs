"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

export default function ArchitecturePage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(50)
  const [component, setComponent] = useState("cpu")
  const [step, setStep] = useState(0)
  const [message, setMessage] = useState("CPU is idle")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // CPU cycle animation
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      timer = setTimeout(
        () => {
          setStep((prevStep) => {
            const nextStep = (prevStep + 1) % 5

            // Update message based on step
            switch (nextStep) {
              case 0:
                setMessage("CPU is fetching instruction from memory")
                break
              case 1:
                setMessage("CPU is decoding the instruction")
                break
              case 2:
                setMessage("CPU is executing the instruction")
                break
              case 3:
                setMessage("CPU is accessing memory")
                break
              case 4:
                setMessage("CPU is writing back results")
                break
            }

            return nextStep
          })
        },
        1000 - speed * 9,
      )
    }

    return () => clearTimeout(timer)
  }, [isPlaying, step, speed])

  // Draw the CPU architecture
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (component === "cpu") {
      drawCPU(ctx, step)
    } else if (component === "memory") {
      drawMemoryHierarchy(ctx, step)
    } else if (component === "cache") {
      drawCacheMemory(ctx, step)
    }
  }, [component, step, canvasSize])

  // Draw CPU architecture
  const drawCPU = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw CPU outline
    ctx.beginPath()
    ctx.rect(width * 0.1, height * 0.1, width * 0.8, height * 0.8)
    ctx.fillStyle = "#1a202c"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw CPU components

    // Control Unit
    const controlUnitActive = currentStep === 1
    drawComponent(
      ctx,
      width * 0.2,
      height * 0.2,
      width * 0.25,
      height * 0.25,
      "Control Unit",
      controlUnitActive ? "#9f7aea" : "#2d3748",
      controlUnitActive,
    )

    // ALU
    const aluActive = currentStep === 2
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.2,
      width * 0.25,
      height * 0.25,
      "ALU",
      aluActive ? "#9f7aea" : "#2d3748",
      aluActive,
    )

    // Registers
    const registersActive = currentStep === 4
    drawComponent(
      ctx,
      width * 0.2,
      height * 0.55,
      width * 0.25,
      height * 0.25,
      "Registers",
      registersActive ? "#9f7aea" : "#2d3748",
      registersActive,
    )

    // Cache
    const cacheActive = currentStep === 3
    drawComponent(
      ctx,
      width * 0.55,
      height * 0.55,
      width * 0.25,
      height * 0.25,
      "Cache",
      cacheActive ? "#9f7aea" : "#2d3748",
      cacheActive,
    )

    // Draw connections
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 1

    // Control Unit to ALU
    drawConnection(
      ctx,
      width * 0.45,
      height * 0.325,
      width * 0.55,
      height * 0.325,
      currentStep === 1 || currentStep === 2,
    )

    // Control Unit to Registers
    drawConnection(
      ctx,
      width * 0.325,
      height * 0.45,
      width * 0.325,
      height * 0.55,
      currentStep === 1 || currentStep === 4,
    )

    // ALU to Registers
    drawConnection(
      ctx,
      width * 0.55,
      height * 0.325,
      width * 0.45,
      height * 0.55,
      currentStep === 2 || currentStep === 4,
    )

    // Cache to ALU
    drawConnection(
      ctx,
      width * 0.675,
      height * 0.45,
      width * 0.675,
      height * 0.55,
      currentStep === 2 || currentStep === 3,
    )

    // Draw data bus
    ctx.beginPath()
    ctx.rect(width * 0.1, height * 0.9, width * 0.8, height * 0.05)
    ctx.fillStyle = currentStep === 0 ? "#9f7aea" : "#2d3748"
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("System Bus", width * 0.5, height * 0.925)

    // Draw connection from bus to CPU
    drawConnection(ctx, width * 0.5, height * 0.9, width * 0.5, height * 0.8, currentStep === 0)
  }

  // Draw Memory Hierarchy
  const drawMemoryHierarchy = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw pyramid of memory hierarchy

    // Registers (top)
    const registersActive = currentStep === 0
    drawPyramidLevel(
      ctx,
      width * 0.4,
      height * 0.1,
      width * 0.2,
      height * 0.1,
      "Registers",
      "< 1 KB",
      "< 1 ns",
      registersActive ? "#9f7aea" : "#2d3748",
      registersActive,
    )

    // L1 Cache
    const l1Active = currentStep === 1
    drawPyramidLevel(
      ctx,
      width * 0.35,
      height * 0.2,
      width * 0.3,
      height * 0.1,
      "L1 Cache",
      "64 KB",
      "1 ns",
      l1Active ? "#9f7aea" : "#2d3748",
      l1Active,
    )

    // L2 Cache
    const l2Active = currentStep === 2
    drawPyramidLevel(
      ctx,
      width * 0.3,
      height * 0.3,
      width * 0.4,
      height * 0.1,
      "L2 Cache",
      "256 KB",
      "4 ns",
      l2Active ? "#9f7aea" : "#2d3748",
      l2Active,
    )

    // L3 Cache
    const l3Active = currentStep === 3
    drawPyramidLevel(
      ctx,
      width * 0.25,
      height * 0.4,
      width * 0.5,
      height * 0.1,
      "L3 Cache",
      "8 MB",
      "10 ns",
      l3Active ? "#9f7aea" : "#2d3748",
      l3Active,
    )

    // RAM
    const ramActive = currentStep === 4
    drawPyramidLevel(
      ctx,
      width * 0.2,
      height * 0.5,
      width * 0.6,
      height * 0.1,
      "RAM",
      "16 GB",
      "100 ns",
      ramActive ? "#9f7aea" : "#2d3748",
      ramActive,
    )

    // SSD
    const ssdActive = false
    drawPyramidLevel(
      ctx,
      width * 0.15,
      height * 0.6,
      width * 0.7,
      height * 0.1,
      "SSD",
      "1 TB",
      "10 μs",
      ssdActive ? "#9f7aea" : "#2d3748",
      ssdActive,
    )

    // HDD
    const hddActive = false
    drawPyramidLevel(
      ctx,
      width * 0.1,
      height * 0.7,
      width * 0.8,
      height * 0.1,
      "HDD",
      "4 TB",
      "10 ms",
      hddActive ? "#9f7aea" : "#2d3748",
      hddActive,
    )

    // Draw arrows between levels
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2

    // Draw arrows between levels
    for (let i = 0; i < 6; i++) {
      const isActive = i === currentStep || i === currentStep - 1

      // Left arrow (up)
      drawArrow(
        ctx,
        width * (0.4 - i * 0.05),
        height * (0.2 + i * 0.1),
        width * (0.45 - i * 0.05),
        height * (0.15 + i * 0.1),
        isActive,
      )

      // Right arrow (down)
      drawArrow(
        ctx,
        width * (0.6 + i * 0.05),
        height * (0.15 + i * 0.1),
        width * (0.55 + i * 0.05),
        height * (0.2 + i * 0.1),
        isActive,
      )
    }
  }

  // Draw Cache Memory
  const drawCacheMemory = (ctx: CanvasRenderingContext2D, currentStep: number) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Draw cache components

    // CPU
    const cpuActive = currentStep === 0
    drawComponent(
      ctx,
      width * 0.1,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "CPU",
      cpuActive ? "#9f7aea" : "#2d3748",
      cpuActive,
    )

    // Cache Controller
    const controllerActive = currentStep === 1
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "Cache Controller",
      controllerActive ? "#9f7aea" : "#2d3748",
      controllerActive,
    )

    // Cache Memory
    const cacheActive = currentStep === 2
    drawComponent(
      ctx,
      width * 0.7,
      height * 0.2,
      width * 0.2,
      height * 0.2,
      "Cache Memory",
      cacheActive ? "#9f7aea" : "#2d3748",
      cacheActive,
    )

    // Main Memory
    const memoryActive = currentStep === 3 || currentStep === 4
    drawComponent(
      ctx,
      width * 0.4,
      height * 0.6,
      width * 0.2,
      height * 0.2,
      "Main Memory",
      memoryActive ? "#9f7aea" : "#2d3748",
      memoryActive,
    )

    // Draw connections

    // CPU to Cache Controller
    drawConnection(ctx, width * 0.3, height * 0.3, width * 0.4, height * 0.3, currentStep === 0 || currentStep === 1)

    // Cache Controller to Cache Memory
    drawConnection(ctx, width * 0.6, height * 0.3, width * 0.7, height * 0.3, currentStep === 1 || currentStep === 2)

    // Cache Controller to Main Memory
    drawConnection(ctx, width * 0.5, height * 0.4, width * 0.5, height * 0.6, currentStep === 3 || currentStep === 4)

    // Draw cache lines
    if (cacheActive || memoryActive) {
      const cacheX = width * 0.7
      const cacheY = height * 0.45
      const cacheWidth = width * 0.2
      const cacheHeight = height * 0.3

      ctx.beginPath()
      ctx.rect(cacheX, cacheY, cacheWidth, cacheHeight)
      ctx.fillStyle = "#1a202c"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw cache lines
      const lineHeight = cacheHeight / 8

      for (let i = 0; i < 8; i++) {
        const isActive = i === currentStep % 8

        ctx.beginPath()
        ctx.rect(cacheX, cacheY + i * lineHeight, cacheWidth, lineHeight)
        ctx.fillStyle = isActive ? "#9f7aea" : "#2d3748"
        ctx.fill()
        ctx.strokeStyle = "#4fd1c5"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw line content
        ctx.fillStyle = "#ffffff"
        ctx.font = "10px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(`Cache Line ${i}`, cacheX + cacheWidth / 2, cacheY + i * lineHeight + lineHeight / 2)
      }
    }
  }

  // Helper function to draw a component
  const drawComponent = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    label: string,
    color: string,
    isActive: boolean,
  ) => {
    ctx.beginPath()
    ctx.rect(x, y, width, height)
    ctx.fillStyle = color
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Add glow effect if active
    if (isActive) {
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 15
      ctx.stroke()
      ctx.shadowBlur = 0
    }

    // Draw label
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(label, x + width / 2, y + height / 2)
  }

  // Helper function to draw a connection
  const drawConnection = (
    ctx: CanvasRenderingContext2D,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    isActive: boolean,
  ) => {
    ctx.beginPath()
    ctx.moveTo(x1, y1)
    ctx.lineTo(x2, y2)

    if (isActive) {
      ctx.strokeStyle = "#9f7aea"
      ctx.lineWidth = 3
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 10
    } else {
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.shadowBlur = 0
    }

    ctx.stroke()
    ctx.shadowBlur = 0
  }

  // Helper function to draw a pyramid level
  const drawPyramidLevel = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    label: string,
    size: string,
    speed: string,
    color: string,
    isActive: boolean,
  ) => {
    ctx.beginPath()
    ctx.rect(x, y, width, height)
    ctx.fillStyle = color
    ctx.fill()
    ctx.strokeStyle = "#4fd1c5"
    ctx.lineWidth = 2
    ctx.stroke()

    // Add glow effect if active
    if (isActive) {
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 15
      ctx.stroke()
      ctx.shadowBlur = 0
    }

    // Draw label
    ctx.fillStyle = "#ffffff"
    ctx.font = "12px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(label, x + width / 2, y + height * 0.3)

    // Draw size and speed
    ctx.font = "10px Arial"
    ctx.fillText(size, x + width / 2, y + height * 0.6)
    ctx.fillText(speed, x + width / 2, y + height * 0.8)
  }

  // Helper function to draw an arrow
  const drawArrow = (
    ctx: CanvasRenderingContext2D,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    isActive: boolean,
  ) => {
    const headLength = 10
    const angle = Math.atan2(y2 - y1, x2 - x1)

    ctx.beginPath()
    ctx.moveTo(x1, y1)
    ctx.lineTo(x2, y2)

    // Draw arrowhead
    ctx.lineTo(x2 - headLength * Math.cos(angle - Math.PI / 6), y2 - headLength * Math.sin(angle - Math.PI / 6))
    ctx.moveTo(x2, y2)
    ctx.lineTo(x2 - headLength * Math.cos(angle + Math.PI / 6), y2 - headLength * Math.sin(angle + Math.PI / 6))

    if (isActive) {
      ctx.strokeStyle = "#9f7aea"
      ctx.lineWidth = 2
      ctx.shadowColor = "#9f7aea"
      ctx.shadowBlur = 10
    } else {
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.shadowBlur = 0
    }

    ctx.stroke()
    ctx.shadowBlur = 0
  }

  // Start animation
  const startAnimation = () => {
    setIsPlaying(true)
  }

  // Pause animation
  const pauseAnimation = () => {
    setIsPlaying(false)
  }

  // Reset animation
  const resetAnimation = () => {
    setStep(0)
    setIsPlaying(false)

    // Set initial message based on component
    if (component === "cpu") {
      setMessage("CPU is idle")
    } else if (component === "memory") {
      setMessage("Memory hierarchy visualization")
    } else if (component === "cache") {
      setMessage("Cache memory visualization")
    }
  }

  // Add concept-specific visualization logic
  // Update the useEffect that sets component based on selected concept

  // Replace the existing useEffect with this more comprehensive one:
  useEffect(() => {
    if (selectedConcept) {
      // Reset animation state
      setStep(0)
      setIsPlaying(false)

      // Set component based on selected concept
      if (
        selectedConcept.toLowerCase().includes("cpu") ||
        selectedConcept.toLowerCase().includes("instruction") ||
        selectedConcept.toLowerCase().includes("pipeline") ||
        selectedConcept.toLowerCase().includes("branch prediction") ||
        selectedConcept.toLowerCase().includes("risc") ||
        selectedConcept.toLowerCase().includes("cisc")
      ) {
        setComponent("cpu")

        if (selectedConcept.toLowerCase().includes("instruction pipeline")) {
          setMessage(
            "Instruction Pipeline: A technique used to increase instruction throughput by overlapping the execution of multiple instructions.",
          )
        } else if (selectedConcept.toLowerCase().includes("branch prediction")) {
          setMessage(
            "Branch Prediction: A technique used by CPUs to guess the outcome of conditional branches to improve performance.",
          )
        } else if (selectedConcept.toLowerCase().includes("risc")) {
          setMessage(
            "RISC: Reduced Instruction Set Computer - A CPU design with simplified instructions that execute in a single cycle.",
          )
        } else if (selectedConcept.toLowerCase().includes("cisc")) {
          setMessage(
            "CISC: Complex Instruction Set Computer - A CPU design with complex instructions that may take multiple cycles to execute.",
          )
        } else {
          setMessage("CPU Architecture: The design and organization of the central processing unit.")
        }
      } else if (
        selectedConcept.toLowerCase().includes("memory") ||
        selectedConcept.toLowerCase().includes("ram") ||
        selectedConcept.toLowerCase().includes("virtual memory")
      ) {
        setComponent("memory")

        if (selectedConcept.toLowerCase().includes("virtual memory")) {
          setMessage(
            "Virtual Memory: A memory management technique that provides an idealized abstraction of the storage resources available to a program.",
          )
        } else if (selectedConcept.toLowerCase().includes("ram")) {
          setMessage(
            "RAM (Random Access Memory): The main memory of a computer, used to store data that is actively being used.",
          )
        } else {
          setMessage(
            "Memory Hierarchy: The organization of memory into different levels based on access speed and capacity.",
          )
        }
      } else if (
        selectedConcept.toLowerCase().includes("cache") ||
        selectedConcept.toLowerCase().includes("l1") ||
        selectedConcept.toLowerCase().includes("l2") ||
        selectedConcept.toLowerCase().includes("l3")
      ) {
        setComponent("cache")

        if (selectedConcept.toLowerCase().includes("l1")) {
          setMessage("L1 Cache: The smallest and fastest cache memory, located closest to the CPU core.")
        } else if (selectedConcept.toLowerCase().includes("l2")) {
          setMessage(
            "L2 Cache: A secondary cache that is larger but slower than L1, shared between cores in some architectures.",
          )
        } else if (selectedConcept.toLowerCase().includes("l3")) {
          setMessage(
            "L3 Cache: A third-level cache that is larger but slower than L2, typically shared among all cores.",
          )
        } else {
          setMessage(
            "Cache Memory: A small, fast memory that stores copies of frequently accessed data from main memory.",
          )
        }
      } else if (selectedConcept.toLowerCase().includes("von neumann")) {
        setComponent("cpu")
        setMessage(
          "Von Neumann Architecture: A computer design where the same memory is used for both program instructions and data.",
        )
      } else if (selectedConcept.toLowerCase().includes("harvard")) {
        setComponent("cpu")
        setMessage(
          "Harvard Architecture: A computer design where separate memories are used for program instructions and data.",
        )
      } else if (selectedConcept.toLowerCase().includes("bus")) {
        setComponent("cpu")
        setMessage(
          "Bus Architecture: The communication system that transfers data between components inside a computer.",
        )
      }
    }
  }, [selectedConcept])

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Computer Architecture Visualizer`
    }
  }, [selectedConcept])

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Computer Architecture Visualizer
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Explore how computers work at the hardware level
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-white">Architecture Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetAnimation}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                    {isPlaying ? (
                      <Button
                        size="sm"
                        onClick={pauseAnimation}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startAnimation} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>

                <div className="border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                  <canvas ref={canvasRef} width={canvasSize.width} height={canvasSize.height} className="w-full" />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-2 bg-gray-800/50 rounded-md text-center text-cyan-400"
                >
                  {message}
                </motion.div>

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Component Selection</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Select Component</h3>
                    <Tabs
                      defaultValue="cpu"
                      value={component}
                      onValueChange={(value) => {
                        setComponent(value)
                        resetAnimation()
                      }}
                      className="w-full"
                    >
                      <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
                        <TabsTrigger value="cpu">CPU</TabsTrigger>
                        <TabsTrigger value="memory">Memory</TabsTrigger>
                        <TabsTrigger value="cache">Cache</TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Component Information</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      {component === "cpu" ? (
                        <>
                          <p>The CPU (Central Processing Unit) is the brain of the computer. It consists of:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Control Unit: Directs the operation of the processor</li>
                            <li>ALU (Arithmetic Logic Unit): Performs mathematical operations</li>
                            <li>Registers: Small, fast storage locations</li>
                            <li>Cache: High-speed memory for frequently accessed data</li>
                          </ul>
                          <p className="mt-2">The CPU follows a fetch-decode-execute cycle:</p>
                          <ol className="list-decimal pl-5 space-y-1 mt-1">
                            <li>Fetch instruction from memory</li>
                            <li>Decode the instruction</li>
                            <li>Execute the instruction</li>
                            <li>Access memory if needed</li>
                            <li>Write back results</li>
                          </ol>
                        </>
                      ) : component === "memory" ? (
                        <>
                          <p>
                            The memory hierarchy is organized in levels, with faster but smaller memory closer to the
                            CPU:
                          </p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Registers: Fastest, smallest memory inside the CPU</li>
                            <li>Cache (L1, L2, L3): High-speed memory for frequently accessed data</li>
                            <li>RAM: Main memory that stores active programs and data</li>
                            <li>Storage (SSD, HDD): Permanent storage for files and programs</li>
                          </ul>
                          <p className="mt-2">
                            The principle of locality states that programs tend to access the same data repeatedly,
                            making caching effective.
                          </p>
                        </>
                      ) : (
                        <>
                          <p>Cache memory bridges the speed gap between the CPU and main memory:</p>
                          <ul className="list-disc pl-5 space-y-1 mt-2">
                            <li>Cache Controller: Manages data transfer between cache and main memory</li>
                            <li>Cache Lines: Fixed-size blocks of data transferred between cache and memory</li>
                            <li>Cache Hit: When requested data is found in the cache</li>
                            <li>Cache Miss: When data must be fetched from main memory</li>
                          </ul>
                          <p className="mt-2">
                            Modern CPUs typically have multiple levels of cache (L1, L2, L3) with different sizes and
                            speeds to optimize performance.
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="architecture" title="Computer Architecture" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

