"use client"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Pause, RotateCcw } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent } from "@/components/ui/card"
import ParticleBackground from "@/components/particle-background"
import ConceptList from "@/components/concept-list"
import Footer from "@/components/footer"

export default function AlgorithmsPage() {
  const searchParams = useSearchParams()
  const selectedConcept = searchParams.get("concept")

  const [algorithm, setAlgorithm] = useState("bubble")
  const [speed, setSpeed] = useState(50)
  const [isPlaying, setIsPlaying] = useState(false)
  const [array, setArray] = useState<number[]>([45, 20, 65, 30, 75, 15, 55, 40, 85, 25])
  const [currentStep, setCurrentStep] = useState(0)
  const [sortingSteps, setSortingSteps] = useState<number[][]>([])
  const [comparingIndices, setComparingIndices] = useState<number[]>([])
  const [swappingIndices, setSwappingIndices] = useState<number[]>([])
  const [sortedIndices, setSortedIndices] = useState<number[]>([])
  const [message, setMessage] = useState<string>("")
  const [conceptTitle, setConceptTitle] = useState<string>("Algorithm Visualizer")
  const [conceptDescription, setConceptDescription] = useState<string>(
    "Watch sorting algorithms in action with step-by-step visualization",
  )
  const [conceptFormula, setConceptFormula] = useState<string>("")
  const [conceptComplexity, setConceptComplexity] = useState<{ time: string; space: string }>({
    time: "O(n²)",
    space: "O(1)",
  })

  // For search visualization
  const [searchTarget, setSearchTarget] = useState<number>(0)
  const [searchIndex, setSearchIndex] = useState<number>(-1)
  const [searchFound, setSearchFound] = useState<boolean>(false)

  // For graph algorithms
  const [graphNodes, setGraphNodes] = useState<{ id: number; x: number; y: number; visited: boolean }[]>([])
  const [graphEdges, setGraphEdges] = useState<{ from: number; to: number }[]>([])
  const [currentNode, setCurrentNode] = useState<number>(-1)
  const [visitedNodes, setVisitedNodes] = useState<number[]>([])
  const [queue, setQueue] = useState<number[]>([])
  const [stack, setStack] = useState<number[]>([])

  // Canvas reference for custom visualizations
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 400 })
  const [visualizationType, setVisualizationType] = useState<"sorting" | "searching" | "graph" | "dp">("sorting")

  // Set algorithm based on selected concept
  useEffect(() => {
    if (selectedConcept) {
      // Reset state
      setCurrentStep(0)
      setIsPlaying(false)
      setSortingSteps([])
      setComparingIndices([])
      setSwappingIndices([])
      setSortedIndices([])
      setSearchIndex(-1)
      setSearchFound(false)
      setVisitedNodes([])
      setQueue([])
      setStack([])

      // Set algorithm based on selected concept
      if (selectedConcept.toLowerCase().includes("bubble")) {
        setVisualizationType("sorting")
        setAlgorithm("bubble")
        setConceptTitle("Bubble Sort")
        setConceptDescription(
          "A simple sorting algorithm that repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order.",
        )
        setMessage(
          "Bubble Sort: Repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order.",
        )
        setConceptFormula(
          "For each i from 0 to n-1, for each j from 0 to n-i-1, if array[j] > array[j+1], swap array[j] and array[j+1]",
        )
        setConceptComplexity({ time: "O(n²)", space: "O(1)" })
      } else if (selectedConcept.toLowerCase().includes("quick")) {
        setVisualizationType("sorting")
        setAlgorithm("quick")
        setConceptTitle("Quick Sort")
        setConceptDescription(
          "A divide-and-conquer algorithm that picks an element as a pivot and partitions the array around the pivot.",
        )
        setMessage(
          "Quick Sort: Selects a 'pivot' element and partitions the array around the pivot, recursively sorting the sub-arrays.",
        )
        setConceptFormula(
          "quickSort(arr, low, high): if low < high, pivotIndex = partition(arr, low, high), quickSort(arr, low, pivotIndex-1), quickSort(arr, pivotIndex+1, high)",
        )
        setConceptComplexity({ time: "O(n log n)", space: "O(log n)" })
      } else if (selectedConcept.toLowerCase().includes("merge")) {
        setVisualizationType("sorting")
        setAlgorithm("merge")
        setConceptTitle("Merge Sort")
        setConceptDescription(
          "A divide-and-conquer algorithm that divides the input array into two halves, recursively sorts them, and then merges the sorted halves.",
        )
        setMessage("Merge Sort: Divides the array into halves, sorts each half, then merges them back together.")
        setConceptFormula(
          "mergeSort(arr): if length(arr) > 1, mid = length(arr)/2, left = mergeSort(arr[0...mid-1]), right = mergeSort(arr[mid...n]), merge(left, right)",
        )
        setConceptComplexity({ time: "O(n log n)", space: "O(n)" })
      } else if (selectedConcept.toLowerCase().includes("insertion")) {
        setVisualizationType("sorting")
        setAlgorithm("insertion")
        setConceptTitle("Insertion Sort")
        setConceptDescription(
          "Builds the sorted array one item at a time by comparing each with the items before it and inserting it into its correct position.",
        )
        setMessage(
          "Insertion Sort: Builds the sorted array one item at a time by comparing each with the items before it.",
        )
        setConceptFormula(
          "For each i from 1 to n-1, key = array[i], j = i-1, while j >= 0 and array[j] > key: array[j+1] = array[j], j--, array[j+1] = key",
        )
        setConceptComplexity({ time: "O(n²)", space: "O(1)" })
      } else if (selectedConcept.toLowerCase().includes("selection")) {
        setVisualizationType("sorting")
        setAlgorithm("selection")
        setConceptTitle("Selection Sort")
        setConceptDescription(
          "Repeatedly finds the minimum element from the unsorted part and puts it at the beginning of the unsorted part.",
        )
        setMessage(
          "Selection Sort: Repeatedly finds the minimum element from the unsorted part and puts it at the beginning.",
        )
        setConceptFormula(
          "For each i from 0 to n-1, find min index in array[i...n-1], swap array[i] and array[min_index]",
        )
        setConceptComplexity({ time: "O(n²)", space: "O(1)" })
      } else if (selectedConcept.toLowerCase().includes("heap")) {
        setVisualizationType("sorting")
        setAlgorithm("heap")
        setConceptTitle("Heap Sort")
        setConceptDescription(
          "A comparison-based sorting algorithm that uses a binary heap data structure to build a max-heap and then repeatedly extracts the maximum element.",
        )
        setMessage(
          "Heap Sort: Uses a binary heap data structure to sort elements by building a max-heap and extracting the maximum element.",
        )
        setConceptFormula(
          "heapSort(arr): buildMaxHeap(arr), for i from n-1 to 1: swap arr[0] and arr[i], heapify(arr, 0, i)",
        )
        setConceptComplexity({ time: "O(n log n)", space: "O(1)" })
      } else if (selectedConcept.toLowerCase().includes("radix")) {
        setVisualizationType("sorting")
        setAlgorithm("radix")
        setConceptTitle("Radix Sort")
        setConceptDescription(
          "A non-comparative sorting algorithm that sorts data with integer keys by grouping keys by individual digits which share the same significant position and value.",
        )
        setMessage(
          "Radix Sort: Sorts integers by processing individual digits, starting from the least significant digit to the most significant digit.",
        )
        setConceptFormula(
          "For each digit position, sort the elements based on that digit using a stable sort (like counting sort)",
        )
        setConceptComplexity({ time: "O(nk)", space: "O(n+k)" })
      } else if (selectedConcept.toLowerCase().includes("counting")) {
        setVisualizationType("sorting")
        setAlgorithm("counting")
        setConceptTitle("Counting Sort")
        setConceptDescription(
          "An integer sorting algorithm that operates by counting the number of objects that have each distinct key value, and using arithmetic to determine the positions of each key value in the output sequence.",
        )
        setMessage("Counting Sort: Sorts by counting the number of occurrences of each unique element in the array.")
        setConceptFormula(
          "Create a count array, count occurrences of each element, calculate cumulative sum, place elements in output array based on count array",
        )
        setConceptComplexity({ time: "O(n+k)", space: "O(n+k)" })
      } else if (selectedConcept.toLowerCase().includes("binary search")) {
        setVisualizationType("searching")
        setAlgorithm("binary")
        setConceptTitle("Binary Search")
        setConceptDescription(
          "A search algorithm that finds the position of a target value within a sorted array by repeatedly dividing the search interval in half.",
        )
        setMessage(
          "Binary Search: Finds the position of a target value within a sorted array by repeatedly dividing the search interval in half.",
        )
        setConceptFormula(
          "binarySearch(arr, target, low, high): if low > high, return -1, mid = (low + high)/2, if arr[mid] == target, return mid, if arr[mid] > target, return binarySearch(arr, target, low, mid-1), else return binarySearch(arr, target, mid+1, high)",
        )
        setConceptComplexity({ time: "O(log n)", space: "O(1)" })
        // Initialize for binary search visualization
        setArray([...array].sort((a, b) => a - b))
        setSearchTarget(array[Math.floor(Math.random() * array.length)])
      } else if (selectedConcept.toLowerCase().includes("linear search")) {
        setVisualizationType("searching")
        setAlgorithm("linear")
        setConceptTitle("Linear Search")
        setConceptDescription(
          "A simple search algorithm that checks each element of the list until a match is found or the whole list has been searched.",
        )
        setMessage(
          "Linear Search: Sequentially checks each element of the list until a match is found or the whole list has been searched.",
        )
        setConceptFormula(
          "linearSearch(arr, target): for each i from 0 to n-1, if arr[i] == target, return i, return -1",
        )
        setConceptComplexity({ time: "O(n)", space: "O(1)" })
        // Initialize for linear search visualization
        setSearchTarget(array[Math.floor(Math.random() * array.length)])
      } else if (selectedConcept.toLowerCase().includes("breadth-first")) {
        setVisualizationType("graph")
        setAlgorithm("bfs")
        setConceptTitle("Breadth-First Search")
        setConceptDescription(
          "A graph traversal algorithm that explores all the vertices of a graph at the present depth prior to moving on to vertices at the next depth level.",
        )
        setMessage(
          "Breadth-First Search: Explores all vertices of a graph at the present depth before moving to vertices at the next depth level.",
        )
        setConceptFormula(
          "BFS(graph, start): Create a queue, mark start as visited, enqueue start, while queue is not empty: vertex = dequeue(), process vertex, for each adjacent vertex: if not visited, mark as visited, enqueue it",
        )
        setConceptComplexity({ time: "O(V+E)", space: "O(V)" })
        // Initialize graph for BFS
        initializeGraph()
        setQueue([0]) // Start BFS from node 0
      } else if (selectedConcept.toLowerCase().includes("depth-first")) {
        setVisualizationType("graph")
        setAlgorithm("dfs")
        setConceptTitle("Depth-First Search")
        setConceptDescription(
          "A graph traversal algorithm that explores as far as possible along each branch before backtracking.",
        )
        setMessage("Depth-First Search: Explores as far as possible along each branch before backtracking.")
        setConceptFormula(
          "DFS(graph, start): Mark start as visited, process start, for each adjacent vertex: if not visited, DFS(graph, adjacent)",
        )
        setConceptComplexity({ time: "O(V+E)", space: "O(V)" })
        // Initialize graph for DFS
        initializeGraph()
        setStack([0]) // Start DFS from node 0
      } else if (selectedConcept.toLowerCase().includes("dijkstra")) {
        setVisualizationType("graph")
        setAlgorithm("dijkstra")
        setConceptTitle("Dijkstra's Algorithm")
        setConceptDescription(
          "An algorithm for finding the shortest paths between nodes in a graph, which may represent, for example, road networks.",
        )
        setMessage(
          "Dijkstra's Algorithm: Finds the shortest path from a start node to all other nodes in a weighted graph.",
        )
        setConceptFormula(
          "Initialize distances to infinity except start node (0), while there are unvisited nodes: select node with minimum distance, for each neighbor: if distance through current node is shorter, update distance",
        )
        setConceptComplexity({ time: "O(V²) or O(E log V) with priority queue", space: "O(V)" })
        // Initialize weighted graph for Dijkstra
        initializeGraph(true) // true for weighted graph
      } else if (selectedConcept.toLowerCase().includes("a*")) {
        setVisualizationType("graph")
        setAlgorithm("astar")
        setConceptTitle("A* Search Algorithm")
        setConceptDescription(
          "A best-first search algorithm that finds the least-cost path from a given initial node to a goal node.",
        )
        setMessage(
          "A* Search Algorithm: Finds the least-cost path from an initial node to a goal node using a heuristic function.",
        )
        setConceptFormula(
          "f(n) = g(n) + h(n), where g(n) is the cost from start to node n, and h(n) is the heuristic estimate from n to goal",
        )
        setConceptComplexity({ time: "O(b^d) in worst case", space: "O(b^d)" })
        // Initialize graph for A*
        initializeGraph(true) // true for weighted graph
      } else if (selectedConcept.toLowerCase().includes("greedy")) {
        setVisualizationType("graph")
        setAlgorithm("greedy")
        setConceptTitle("Greedy Algorithms")
        setConceptDescription(
          "Algorithms that make the locally optimal choice at each stage with the hope of finding a global optimum.",
        )
        setMessage(
          "Greedy Algorithms: Make the locally optimal choice at each stage with the hope of finding a global optimum.",
        )
        setConceptFormula(
          "At each step, select the best choice available at that moment without considering future consequences",
        )
        setConceptComplexity({ time: "Varies by problem", space: "Varies by problem" })
        // Initialize for greedy algorithm visualization (e.g., minimum spanning tree)
        initializeGraph(true) // true for weighted graph
      } else if (selectedConcept.toLowerCase().includes("dynamic")) {
        setVisualizationType("dp")
        setAlgorithm("dp")
        setConceptTitle("Dynamic Programming")
        setConceptDescription(
          "A method for solving complex problems by breaking them down into simpler subproblems and storing the results to avoid redundant calculations.",
        )
        setMessage(
          "Dynamic Programming: Breaks down complex problems into simpler subproblems and stores results to avoid redundant calculations.",
        )
        setConceptFormula(
          "1. Define subproblems, 2. Find recurrence relation, 3. Solve base cases, 4. Implement solution (bottom-up or top-down)",
        )
        setConceptComplexity({ time: "Varies by problem", space: "Varies by problem" })
        // Initialize for DP visualization (e.g., fibonacci or knapsack)
      } else {
        // Default case
        setVisualizationType("sorting")
        setAlgorithm("bubble")
        setConceptTitle("Algorithm Visualizer")
        setConceptDescription("Watch sorting algorithms in action with step-by-step visualization")
        setMessage("Select an algorithm to visualize its operation step by step.")
        setConceptFormula("")
        setConceptComplexity({ time: "O(n²)", space: "O(1)" })
      }

      // Generate a new array to visualize with
      generateRandomArray()
    }
  }, [selectedConcept])

  // Initialize graph for visualization
  const initializeGraph = (weighted = false) => {
    // Create nodes
    const nodes = Array.from({ length: 8 }, (_, i) => ({
      id: i,
      x: 100 + Math.cos((i * Math.PI) / 4) * 150,
      y: 200 + Math.sin((i * Math.PI) / 4) * 150,
      visited: false,
    }))

    // Create edges (circular graph with some cross connections)
    const edges = [
      { from: 0, to: 1 },
      { from: 1, to: 2 },
      { from: 2, to: 3 },
      { from: 3, to: 4 },
      { from: 4, to: 5 },
      { from: 5, to: 6 },
      { from: 6, to: 7 },
      { from: 7, to: 0 },
      { from: 0, to: 4 },
      { from: 1, to: 5 },
      { from: 2, to: 6 },
      { from: 3, to: 7 },
    ]

    setGraphNodes(nodes)
    setGraphEdges(edges)
    setVisitedNodes([])
    setCurrentNode(-1)
  }

  // Add a useEffect to display the selected concept in the UI
  useEffect(() => {
    if (selectedConcept) {
      // Update the page title to include the selected concept
      document.title = `${selectedConcept} - Algorithm Visualizer`
    }
  }, [selectedConcept])

  // Set canvas size
  useEffect(() => {
    const updateCanvasSize = () => {
      const width = Math.min(800, window.innerWidth - 40)
      setCanvasSize({ width, height: 400 })
    }

    updateCanvasSize()
    window.addEventListener("resize", updateCanvasSize)

    return () => window.removeEventListener("resize", updateCanvasSize)
  }, [])

  // Draw custom visualizations
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || visualizationType === "sorting") return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (visualizationType === "searching") {
      drawSearchVisualization(ctx)
    } else if (visualizationType === "graph") {
      drawGraphVisualization(ctx)
    } else if (visualizationType === "dp") {
      drawDPVisualization(ctx)
    }
  }, [
    visualizationType,
    searchIndex,
    searchFound,
    currentNode,
    visitedNodes,
    queue,
    stack,
    graphNodes,
    graphEdges,
    canvasSize,
  ])

  // Draw search visualization
  const drawSearchVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height
    const barWidth = Math.min(40, width / array.length - 10)
    const startX = (width - (barWidth + 10) * array.length) / 2

    // Draw array elements
    array.forEach((value, index) => {
      const x = startX + index * (barWidth + 10)
      const y = height / 2
      const barHeight = 40

      // Draw rectangle
      ctx.beginPath()
      ctx.rect(x, y - barHeight / 2, barWidth, barHeight)

      // Color based on search state
      if (index === searchIndex) {
        ctx.fillStyle = searchFound ? "#4ade80" : "#f87171"
      } else if (algorithm === "binary" && searchIndex !== -1) {
        // For binary search, highlight the current search range
        const low = Math.floor(searchIndex / 2)
        const high = searchIndex + Math.floor((array.length - searchIndex) / 2)
        if (index >= low && index <= high) {
          ctx.fillStyle = "#a78bfa"
        } else {
          ctx.fillStyle = "#1f2937"
        }
      } else {
        ctx.fillStyle = "#1f2937"
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw value
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(value.toString(), x + barWidth / 2, y)
    })

    // Draw target value
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(`Searching for: ${searchTarget}`, width / 2, 50)

    // Draw search status
    if (searchIndex !== -1) {
      ctx.fillStyle = searchFound ? "#4ade80" : "#f87171"
      ctx.font = "16px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "top"
      ctx.fillText(
        searchFound ? `Found ${searchTarget} at index ${searchIndex}!` : `Checking index ${searchIndex}...`,
        width / 2,
        height - 50,
      )
    }
  }

  // Draw graph visualization
  const drawGraphVisualization = (ctx: CanvasRenderingContext2D) => {
    // Draw edges
    graphEdges.forEach((edge) => {
      const fromNode = graphNodes.find((n) => n.id === edge.from)
      const toNode = graphNodes.find((n) => n.id === edge.to)

      if (fromNode && toNode) {
        ctx.beginPath()
        ctx.moveTo(fromNode.x, fromNode.y)
        ctx.lineTo(toNode.x, toNode.y)

        // Color based on if the edge is part of the current path
        const isInPath =
          visitedNodes.includes(edge.from) &&
          visitedNodes.includes(edge.to) &&
          Math.abs(visitedNodes.indexOf(edge.from) - visitedNodes.indexOf(edge.to)) === 1

        ctx.strokeStyle = isInPath ? "#4ade80" : "#4fd1c5"
        ctx.lineWidth = isInPath ? 3 : 1
        ctx.stroke()

        // For weighted graphs, draw the weight
        if (algorithm === "dijkstra" || algorithm === "astar" || algorithm === "greedy") {
          const weight = Math.floor(Math.random() * 10) + 1 // Just for visualization
          const midX = (fromNode.x + toNode.x) / 2
          const midY = (fromNode.y + toNode.y) / 2

          ctx.fillStyle = "#ffffff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(weight.toString(), midX, midY)
        }
      }
    })

    // Draw nodes
    graphNodes.forEach((node) => {
      ctx.beginPath()
      ctx.arc(node.x, node.y, 20, 0, Math.PI * 2)

      // Color based on node state
      if (node.id === currentNode) {
        ctx.fillStyle = "#f87171" // Current node
      } else if (visitedNodes.includes(node.id)) {
        ctx.fillStyle = "#4ade80" // Visited node
      } else if (queue.includes(node.id) || stack.includes(node.id)) {
        ctx.fillStyle = "#a78bfa" // In queue/stack
      } else {
        ctx.fillStyle = "#1f2937" // Unvisited node
      }

      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw node ID
      ctx.fillStyle = "#ffffff"
      ctx.font = "14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.id.toString(), node.x, node.y)
    })

    // Draw algorithm status
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"

    if (algorithm === "bfs") {
      ctx.fillText(`BFS Queue: [${queue.join(", ")}]`, canvasSize.width / 2, 20)
    } else if (algorithm === "dfs") {
      ctx.fillText(`DFS Stack: [${stack.join(", ")}]`, canvasSize.width / 2, 20)
    } else if (algorithm === "dijkstra") {
      ctx.fillText("Dijkstra's Algorithm", canvasSize.width / 2, 20)
    } else if (algorithm === "astar") {
      ctx.fillText("A* Search Algorithm", canvasSize.width / 2, 20)
    } else if (algorithm === "greedy") {
      ctx.fillText("Greedy Algorithm", canvasSize.width / 2, 20)
    }

    ctx.fillText(`Visited Nodes: [${visitedNodes.join(", ")}]`, canvasSize.width / 2, 50)
  }

  // Draw dynamic programming visualization
  const drawDPVisualization = (ctx: CanvasRenderingContext2D) => {
    const width = canvasSize.width
    const height = canvasSize.height

    // Example: Fibonacci sequence visualization
    const n = 10
    const cellSize = Math.min(60, width / (n + 1))
    const startX = (width - cellSize * n) / 2
    const startY = height / 2 - cellSize / 2

    // Draw table
    for (let i = 0; i <= n; i++) {
      const x = startX + i * cellSize

      // Draw cell
      ctx.beginPath()
      ctx.rect(x, startY, cellSize, cellSize)
      ctx.fillStyle = i <= currentStep ? "#4ade80" : "#1f2937"
      ctx.fill()
      ctx.strokeStyle = "#4fd1c5"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw index
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText(i.toString(), x + cellSize / 2, startY - 5)

      // Draw value
      if (i <= currentStep) {
        const fib = calculateFibonacci(i)
        ctx.fillStyle = "#ffffff"
        ctx.font = "14px Arial"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(fib.toString(), x + cellSize / 2, startY + cellSize / 2)
      }
    }

    // Draw formula and explanation
    ctx.fillStyle = "#ffffff"
    ctx.font = "16px Arial"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Fibonacci Sequence: F(n) = F(n-1) + F(n-2)", width / 2, 50)

    if (currentStep > 1) {
      const fib1 = calculateFibonacci(currentStep - 1)
      const fib2 = calculateFibonacci(currentStep - 2)
      const fib = fib1 + fib2

      ctx.fillText(
        `F(${currentStep}) = F(${currentStep - 1}) + F(${currentStep - 2}) = ${fib1} + ${fib2} = ${fib}`,
        width / 2,
        height - 50,
      )
    }
  }

  // Helper function for DP visualization
  const calculateFibonacci = (n: number): number => {
    if (n <= 1) return n

    const fib = [0, 1]
    for (let i = 2; i <= n; i++) {
      fib[i] = fib[i - 1] + fib[i - 2]
    }

    return fib[n]
  }

  // Generate a new random array
  const generateRandomArray = () => {
    const newArray = Array.from({ length: 10 }, () => Math.floor(Math.random() * 90) + 10)

    // For search algorithms, ensure the array is sorted
    if (visualizationType === "searching" && algorithm === "binary") {
      newArray.sort((a, b) => a - b)
    }

    setArray(newArray)
    setCurrentStep(0)
    setSortingSteps([])
    setComparingIndices([])
    setSwappingIndices([])
    setSortedIndices([])
    setIsPlaying(false)

    // For search algorithms, set a random target
    if (visualizationType === "searching") {
      setSearchTarget(newArray[Math.floor(Math.random() * newArray.length)])
      setSearchIndex(-1)
      setSearchFound(false)
    }

    // For graph algorithms, reset the graph
    if (visualizationType === "graph") {
      initializeGraph(algorithm === "dijkstra" || algorithm === "astar" || algorithm === "greedy")
    }
  }

  // Start visualization
  const startSorting = () => {
    if (visualizationType === "sorting" && sortingSteps.length === 0) {
      // Generate sorting steps based on selected algorithm
      const steps = generateSortingSteps(array, algorithm)
      setSortingSteps(steps.arrays)
      setIsPlaying(true)
    } else if (visualizationType === "searching" && searchIndex === -1) {
      // Start search visualization
      setSearchIndex(0)
      setIsPlaying(true)
    } else if (visualizationType === "graph" && currentNode === -1) {
      // Start graph algorithm visualization
      if (algorithm === "bfs") {
        setQueue([0])
      } else if (algorithm === "dfs") {
        setStack([0])
      }
      setIsPlaying(true)
    } else if (visualizationType === "dp" && currentStep === 0) {
      // Start DP visualization
      setIsPlaying(true)
    } else {
      setIsPlaying(true)
    }
  }

  // Pause visualization
  const pauseSorting = () => {
    setIsPlaying(false)
  }

  // Reset visualization
  const resetSorting = () => {
    setCurrentStep(0)
    setComparingIndices([])
    setSwappingIndices([])
    setSortedIndices([])
    setIsPlaying(false)

    if (visualizationType === "searching") {
      setSearchIndex(-1)
      setSearchFound(false)
    } else if (visualizationType === "graph") {
      setCurrentNode(-1)
      setVisitedNodes([])
      setQueue([])
      setStack([])

      // Reset graph nodes
      setGraphNodes(graphNodes.map((node) => ({ ...node, visited: false })))

      if (algorithm === "bfs") {
        setQueue([0])
      } else if (algorithm === "dfs") {
        setStack([0])
      }
    }
  }

  // Generate sorting steps for visualization
  const generateSortingSteps = (arr: number[], algoType: string) => {
    const steps: { arrays: number[][]; comparisons: number[][]; swaps: number[][] } = {
      arrays: [arr.slice()],
      comparisons: [],
      swaps: [],
    }

    const arrCopy = arr.slice()

    if (algoType === "bubble") {
      // Bubble sort implementation with step tracking
      for (let i = 0; i < arrCopy.length; i++) {
        for (let j = 0; j < arrCopy.length - i - 1; j++) {
          steps.comparisons.push([j, j + 1])

          if (arrCopy[j] > arrCopy[j + 1]) {
            // Swap
            steps.swaps.push([j, j + 1])
            const temp = arrCopy[j]
            arrCopy[j] = arrCopy[j + 1]
            arrCopy[j + 1] = temp
            steps.arrays.push(arrCopy.slice())
          } else {
            steps.arrays.push(arrCopy.slice())
          }
        }
      }
    } else if (algoType === "quick") {
      // Simplified quick sort visualization
      const quickSortSteps = (arr: number[], low: number, high: number) => {
        if (low < high) {
          const pivotIndex = partition(arr, low, high)
          quickSortSteps(arr, low, pivotIndex - 1)
          quickSortSteps(arr, pivotIndex + 1, high)
        }
      }

      const partition = (arr: number[], low: number, high: number) => {
        const pivot = arr[high]
        let i = low - 1

        for (let j = low; j < high; j++) {
          steps.comparisons.push([j, high])

          if (arr[j] <= pivot) {
            i++
            steps.swaps.push([i, j])
            const temp = arr[i]
            arr[i] = arr[j]
            arr[j] = temp
            steps.arrays.push(arr.slice())
          } else {
            steps.arrays.push(arr.slice())
          }
        }

        steps.swaps.push([i + 1, high])
        const temp = arr[i + 1]
        arr[i + 1] = arr[high]
        arr[high] = temp
        steps.arrays.push(arr.slice())

        return i + 1
      }

      quickSortSteps(arrCopy, 0, arrCopy.length - 1)
    } else if (algoType === "insertion") {
      // Insertion sort implementation
      for (let i = 1; i < arrCopy.length; i++) {
        const key = arrCopy[i]
        let j = i - 1

        while (j >= 0 && arrCopy[j] > key) {
          steps.comparisons.push([j, j + 1])
          arrCopy[j + 1] = arrCopy[j]
          steps.swaps.push([j, j + 1])
          j--
          steps.arrays.push(arrCopy.slice())
        }

        arrCopy[j + 1] = key
        steps.arrays.push(arrCopy.slice())
      }
    } else if (algoType === "selection") {
      // Selection sort implementation
      for (let i = 0; i < arrCopy.length - 1; i++) {
        let minIndex = i

        for (let j = i + 1; j < arrCopy.length; j++) {
          steps.comparisons.push([minIndex, j])

          if (arrCopy[j] < arrCopy[minIndex]) {
            minIndex = j
          }

          steps.arrays.push(arrCopy.slice())
        }

        if (minIndex !== i) {
          steps.swaps.push([i, minIndex])
          const temp = arrCopy[i]
          arrCopy[i] = arrCopy[minIndex]
          arrCopy[minIndex] = temp
          steps.arrays.push(arrCopy.slice())
        }
      }
    }

    return steps
  }

  // Effect to animate sorting steps
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (isPlaying) {
      if (visualizationType === "sorting" && sortingSteps.length > 0 && currentStep < sortingSteps.length - 1) {
        timer = setTimeout(
          () => {
            setCurrentStep((prev) => {
              const nextStep = prev + 1

              // Update comparing and swapping indices based on current step
              if (nextStep < sortingSteps.length) {
                // This is simplified - in a real implementation, you would track these during step generation
                if (nextStep % 3 === 1) {
                  setComparingIndices([nextStep % array.length, (nextStep + 1) % array.length])
                  setSwappingIndices([])
                } else if (nextStep % 3 === 2) {
                  setComparingIndices([])
                  setSwappingIndices([nextStep % array.length, (nextStep + 1) % array.length])
                } else {
                  setComparingIndices([])
                  setSwappingIndices([])
                }

                // Mark sorted elements
                if (nextStep === sortingSteps.length - 1) {
                  setSortedIndices(Array.from({ length: array.length }, (_, i) => i))
                } else if (algorithm === "bubble" && nextStep > array.length * 2) {
                  const sortedCount = Math.floor(nextStep / (array.length * 2))
                  setSortedIndices(Array.from({ length: sortedCount }, (_, i) => array.length - 1 - i))
                }
              }

              return nextStep
            })
          },
          1000 - speed * 9,
        )
      } else if (visualizationType === "searching" && searchIndex !== -1) {
        timer = setTimeout(
          () => {
            if (algorithm === "linear") {
              // Linear search step
              if (array[searchIndex] === searchTarget) {
                setSearchFound(true)
                setIsPlaying(false)
              } else if (searchIndex < array.length - 1) {
                setSearchIndex(searchIndex + 1)
              } else {
                setIsPlaying(false)
              }
            } else if (algorithm === "binary") {
              // Binary search step
              const low = 0
              const high = array.length - 1
              const mid = Math.floor((low + high) / 2)

              if (array[mid] === searchTarget) {
                setSearchIndex(mid)
                setSearchFound(true)
                setIsPlaying(false)
              } else if (array[mid] < searchTarget) {
                // Search in right half
                setSearchIndex(mid + 1)
              } else {
                // Search in left half
                setSearchIndex(mid - 1)
              }
            }
          },
          1000 - speed * 9,
        )
      } else if (visualizationType === "graph") {
        timer = setTimeout(
          () => {
            if (algorithm === "bfs" && queue.length > 0) {
              // BFS step
              const node = queue.shift()!
              setCurrentNode(node)

              if (!visitedNodes.includes(node)) {
                setVisitedNodes([...visitedNodes, node])

                // Add unvisited neighbors to queue
                const neighbors = graphEdges
                  .filter((edge) => edge.from === node)
                  .map((edge) => edge.to)
                  .filter((neighbor) => !visitedNodes.includes(neighbor) && !queue.includes(neighbor))

                setQueue([...queue, ...neighbors])
              }

              if (queue.length === 0) {
                setIsPlaying(false)
              }
            } else if (algorithm === "dfs" && stack.length > 0) {
              // DFS step
              const node = stack.pop()!
              setCurrentNode(node)

              if (!visitedNodes.includes(node)) {
                setVisitedNodes([...visitedNodes, node])

                // Add unvisited neighbors to stack
                const neighbors = graphEdges
                  .filter((edge) => edge.from === node)
                  .map((edge) => edge.to)
                  .filter((neighbor) => !visitedNodes.includes(neighbor))
                  .reverse() // Reverse to maintain DFS order

                setStack([...stack, ...neighbors])
              }

              if (stack.length === 0) {
                setIsPlaying(false)
              }
            } else if (algorithm === "dijkstra" || algorithm === "astar" || algorithm === "greedy") {
              // Simplified Dijkstra/A*/Greedy step
              if (visitedNodes.length < graphNodes.length) {
                // Select next node (in a real implementation, this would use distances/priorities)
                const unvisitedNodes = graphNodes
                  .filter((node) => !visitedNodes.includes(node.id))
                  .map((node) => node.id)

                if (unvisitedNodes.length > 0) {
                  const nextNode = unvisitedNodes[0]
                  setCurrentNode(nextNode)
                  setVisitedNodes([...visitedNodes, nextNode])
                } else {
                  setIsPlaying(false)
                }
              } else {
                setIsPlaying(false)
              }
            }
          },
          1000 - speed * 9,
        )
      } else if (visualizationType === "dp") {
        timer = setTimeout(
          () => {
            if (currentStep < 10) {
              // Limit to n=10 for Fibonacci
              setCurrentStep(currentStep + 1)
            } else {
              setIsPlaying(false)
            }
          },
          1000 - speed * 9,
        )
      }
    }

    return () => clearTimeout(timer)
  }, [
    isPlaying,
    sortingSteps,
    currentStep,
    array,
    algorithm,
    speed,
    visualizationType,
    searchIndex,
    searchFound,
    searchTarget,
    currentNode,
    visitedNodes,
    queue,
    stack,
    graphNodes,
    graphEdges,
  ])

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <ParticleBackground />

      <div className="container relative z-10 mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.h1
            className="text-4xl font-bold mt-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {conceptTitle}
          </motion.h1>

          <motion.p
            className="text-gray-300 mt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {conceptDescription}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-8">
                  <h2 className="text-xl font-semibold text-white">Visualization</h2>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={generateRandomArray}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      New Data
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={resetSorting}
                      className="border-gray-700 text-gray-300 hover:text-white"
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                    {isPlaying ? (
                      <Button size="sm" onClick={pauseSorting} className="bg-purple-600 hover:bg-purple-700 text-white">
                        <Pause className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button size="sm" onClick={startSorting} className="bg-cyan-600 hover:bg-cyan-700 text-white">
                        <Play className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {visualizationType === "sorting" ? (
                  <div className="h-64 flex items-end justify-around p-4 border border-gray-800 rounded-lg bg-gray-950/50">
                    {(sortingSteps.length > 0 ? sortingSteps[currentStep] : array).map((value, index) => (
                      <motion.div
                        key={index}
                        className={`w-8 rounded-t-md flex items-center justify-center
                          ${comparingIndices.includes(index) ? "bg-yellow-500" : ""}
                          ${swappingIndices.includes(index) ? "bg-red-500" : ""}
                          ${sortedIndices.includes(index) ? "bg-green-500" : "bg-gradient-to-t from-cyan-500 to-purple-600"}
                        `}
                        style={{ height: `${value * 2}px` }}
                        initial={{ height: 0 }}
                        animate={{ height: `${value * 2}px` }}
                        transition={{ duration: 0.5 }}
                      >
                        <span className="text-xs font-mono text-white">{value}</span>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="h-64 border border-gray-800 rounded-lg bg-gray-950/50 overflow-hidden">
                    <canvas
                      ref={canvasRef}
                      width={canvasSize.width}
                      height={canvasSize.height}
                      className="w-full h-full"
                    />
                  </div>
                )}

                <div className="mt-6 flex items-center space-x-4">
                  <span className="text-sm text-gray-400">Speed:</span>
                  <Slider
                    value={[speed]}
                    min={1}
                    max={100}
                    step={1}
                    onValueChange={(value) => setSpeed(value[0])}
                    className="flex-1"
                  />
                </div>

                <div className="mt-8">
                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    {visualizationType === "sorting" && (
                      <>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-gradient-to-t from-cyan-500 to-purple-600 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Unsorted</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-yellow-500 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Comparing</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-green-500 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Sorted</span>
                        </div>
                      </>
                    )}
                    {visualizationType === "searching" && (
                      <>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-gradient-to-t from-cyan-500 to-purple-600 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Element</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-red-500 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Checking</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-green-500 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Found</span>
                        </div>
                      </>
                    )}
                    {visualizationType === "graph" && (
                      <>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-gray-700 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Unvisited</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-purple-500 rounded-sm mb-2"></div>
                          <span className="text-gray-400">In Queue/Stack</span>
                        </div>
                        <div className="flex flex-col items-center">
                          <div className="w-4 h-4 bg-green-500 rounded-sm mb-2"></div>
                          <span className="text-gray-400">Visited</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="space-y-8"
          >
            <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-6">Algorithm Details</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-400 mb-4">Algorithm Info</h3>
                    <div className="space-y-2 text-sm text-gray-300">
                      <p>{message || "Select an algorithm to visualize its operation step by step."}</p>
                      {conceptFormula && (
                        <div className="mt-4 p-3 bg-gray-800/50 rounded-md font-mono text-xs text-cyan-300 overflow-x-auto">
                          {conceptFormula}
                        </div>
                      )}
                      <div className="mt-4">
                        <p className="text-cyan-400 font-mono">Time Complexity: {conceptComplexity.time}</p>
                        <p className="text-cyan-400 font-mono">Space Complexity: {conceptComplexity.space}</p>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <h3 className="text-sm font-medium text-gray-400 mb-3">Current Status</h3>
                    <div className="space-y-1 text-sm">
                      {visualizationType === "sorting" && (
                        <p>
                          Step: <span className="text-cyan-400">{currentStep}</span> of{" "}
                          <span className="text-cyan-400">{sortingSteps.length - 1 || 0}</span>
                        </p>
                      )}
                      {visualizationType === "searching" && (
                        <p>
                          Checking index: <span className="text-cyan-400">{searchIndex}</span>
                          {searchFound && <span className="text-green-400 ml-2">(Found!)</span>}
                        </p>
                      )}
                      {visualizationType === "graph" && (
                        <p>
                          Visited nodes: <span className="text-cyan-400">{visitedNodes.length}</span> of{" "}
                          <span className="text-cyan-400">{graphNodes.length}</span>
                        </p>
                      )}
                      {visualizationType === "dp" && (
                        <p>
                          Step: <span className="text-cyan-400">{currentStep}</span> of{" "}
                          <span className="text-cyan-400">10</span>
                        </p>
                      )}
                      <p>
                        Status:{" "}
                        <span className="text-cyan-400">
                          {isPlaying
                            ? "Running"
                            : currentStep === 0
                              ? "Ready"
                              : visualizationType === "searching" && searchFound
                                ? "Found"
                                : "Paused"}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ConceptList category="algorithms" title="Algorithm" />
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}

