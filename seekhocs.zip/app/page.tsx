"use client"

import { useState, useEffect, useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import Link from "next/link"
import { Search, ChevronRight, ArrowUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ParticleBackground from "@/components/particle-background"
import ThreeBackground from "@/components/three-background"
import ConceptCard from "@/components/concept-card"
import TypewriterEffect from "@/components/typewriter-effect"
import Footer from "@/components/footer"
import { availableConcepts, getCategoryForConcept } from "@/lib/concepts"

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [showScrollTop, setShowScrollTop] = useState(false)
  const topRef = useRef<HTMLDivElement>(null)

  const { scrollY } = useScroll()
  const opacity = useTransform(scrollY, [0, 200], [0, 1])

  const concepts = [
    {
      title: "Algorithms",
      description: "Visualize sorting, searching, and graph algorithms in real-time",
      icon: "Binary",
      href: "/concepts/algorithms",
    },
    {
      title: "Data Structures",
      description: "Explore trees, graphs, arrays and more with interactive models",
      icon: "LayoutGrid",
      href: "/concepts/data-structures",
    },
    {
      title: "Computer Architecture",
      description: "Understand CPUs, memory hierarchies and hardware components",
      icon: "Cpu",
      href: "/concepts/architecture",
    },
    {
      title: "Neural Networks",
      description: "See how neural networks learn and process information",
      icon: "Network",
      href: "/concepts/neural-networks",
    },
    {
      title: "Operating Systems",
      description: "Visualize processes, memory management and scheduling",
      icon: "Layers",
      href: "/concepts/operating-systems",
    },
    {
      title: "Cryptography",
      description: "Explore encryption algorithms and security concepts",
      icon: "Lock",
      href: "/concepts/cryptography",
    },
    {
      title: "Automata Theory",
      description: "Visualize Turing machines, DFAs, NFAs, and regular expressions",
      icon: "Binary",
      href: "/concepts/automata-theory",
    },
    {
      title: "Compilers",
      description: "Explore lexical analysis, parsing, and code generation",
      icon: "Code",
      href: "/concepts/compilers",
    },
    {
      title: "Networking",
      description: "Simulate TCP/IP, routing algorithms, and HTTP/DNS protocols",
      icon: "Network",
      href: "/concepts/networking",
    },
    {
      title: "Database Systems",
      description: "Visualize SQL queries, NoSQL models, and indexing techniques",
      icon: "Database",
      href: "/concepts/database-systems",
    },
  ]

  const typewriterWords = ["Sorting Algorithms", "Neural Networks", "Memory Hierarchies", "Concurrency Models"]

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setSuggestions([])
      return
    }

    // Filter available concepts based on search query
    const filtered = availableConcepts.filter((concept) => concept.toLowerCase().includes(searchQuery.toLowerCase()))

    setSuggestions(filtered.slice(0, 8)) // Limit to 8 suggestions for better UI
  }, [searchQuery])

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToTop = () => {
    topRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleStartLearning = () => {
    scrollToTop()
  }

  // Function to get the correct URL for a concept
  const getConceptUrl = (concept: string) => {
    const category = getCategoryForConcept(concept)
    return `/concepts/${category}?concept=${encodeURIComponent(concept)}`
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <div ref={topRef}></div>
      <ParticleBackground />
      <ThreeBackground />

      <div className="container relative z-10 mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="mb-6"
          >
            <h1 className="text-5xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600 mb-4">
              SeekhoCS
            </h1>
            <p className="text-xl md:text-2xl text-gray-300">
              Dive into the Future of Code - Visualize, Understand, Master
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="h-16 flex items-center justify-center mb-8"
          >
            <TypewriterEffect words={typewriterWords} />
          </motion.div>

          <div className="max-w-2xl mx-auto relative">
            <div className="flex items-center border border-gray-700 rounded-lg bg-gray-900/50 backdrop-blur-sm overflow-hidden focus-within:ring-2 focus-within:ring-purple-500 transition-all">
              <Search className="ml-3 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search for any CS concept..."
                className="flex-1 border-0 bg-transparent text-white placeholder:text-gray-400 focus-visible:ring-0 focus-visible:ring-offset-0"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {suggestions.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute z-20 mt-1 w-full bg-gray-900/90 backdrop-blur-md border border-gray-700 rounded-lg shadow-lg overflow-hidden"
              >
                <ul className="py-2">
                  {suggestions.map((suggestion, index) => {
                    return (
                      <li key={index}>
                        <Link
                          href={getConceptUrl(suggestion)}
                          className="flex items-center px-4 py-2 hover:bg-gray-800 transition-colors"
                        >
                          <span>{suggestion}</span>
                          <ChevronRight className="ml-auto h-4 w-4 text-gray-400" />
                        </Link>
                      </li>
                    )
                  })}
                </ul>
              </motion.div>
            )}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          <h2 className="text-2xl font-bold mb-8 text-center">Explore Core Concepts</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {concepts.map((concept, index) => (
              <ConceptCard
                key={index}
                title={concept.title}
                description={concept.description}
                icon={concept.icon}
                href={concept.href}
                delay={index * 0.1}
              />
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="mt-16 text-center"
        >
          <Button
            onClick={handleStartLearning}
            className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white px-8 py-6 text-lg rounded-full"
          >
            Start Learning
          </Button>
        </motion.div>
      </div>

      <Footer />

      {showScrollTop && (
        <motion.button
          style={{ opacity }}
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-3 rounded-full bg-purple-600 text-white shadow-lg z-50 hover:bg-purple-700 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <ArrowUp className="h-6 w-6" />
        </motion.button>
      )}
    </main>
  )
}

