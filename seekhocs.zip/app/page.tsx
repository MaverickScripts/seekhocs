"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { Search, ChevronRight, ArrowUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ParticleBackground from "@/components/particle-background"
import ThreeBackground from "@/components/three-background"
import ConceptCard from "@/components/concept-card"
import TypewriterEffect from "@/components/typewriter-effect"
import Footer from "@/components/footer"
import { availableConcepts, getCategoryForConcept } from "@/lib/concepts"

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [debouncedQuery, setDebouncedQuery] = useState("")
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [showScrollTop, setShowScrollTop] = useState(false)
  const topRef = useRef<HTMLDivElement>(null)

  const { scrollY } = useScroll()
  const opacity = useTransform(scrollY, [0, 200], [0, 1])

  // Parallax effect for sections
  const headerY = useTransform(scrollY, [0, 500], [0, 100])
  const conceptsY = useTransform(scrollY, [0, 500], [0, -50])

  // Memoize concepts to prevent re-renders
  const concepts = useMemo(
    () => [
      {
        title: "Algorithms",
        description: "Visualize sorting, searching, and graph algorithms in real-time",
        icon: "Binary",
        href: "/concepts/algorithms",
      },
      {
        title: "Data Structures",
        description: "Explore trees, graphs, arrays and more with interactive models",
        icon: "LayoutGrid",
        href: "/concepts/data-structures",
      },
      {
        title: "Computer Architecture",
        description: "Understand CPUs, memory hierarchies and hardware components",
        icon: "Cpu",
        href: "/concepts/architecture",
      },
      {
        title: "Neural Networks",
        description: "See how neural networks learn and process information",
        icon: "Network",
        href: "/concepts/neural-networks",
      },
      {
        title: "Operating Systems",
        description: "Visualize processes, memory management and scheduling",
        icon: "Layers",
        href: "/concepts/operating-systems",
      },
      {
        title: "Cryptography",
        description: "Explore encryption algorithms and security concepts",
        icon: "Lock",
        href: "/concepts/cryptography",
      },
      {
        title: "Automata Theory",
        description: "Visualize Turing machines, DFAs, NFAs, and regular expressions",
        icon: "Binary",
        href: "/concepts/automata-theory",
      },
      {
        title: "Compilers",
        description: "Explore lexical analysis, parsing, and code generation",
        icon: "Code",
        href: "/concepts/compilers",
      },
      {
        title: "Networking",
        description: "Simulate TCP/IP, routing algorithms, and HTTP/DNS protocols",
        icon: "Network",
        href: "/concepts/networking",
      },
      {
        title: "Database Systems",
        description: "Visualize SQL queries, NoSQL models, and indexing techniques",
        icon: "Database",
        href: "/concepts/database-systems",
      },
    ],
    [],
  )

  const typewriterWords = useMemo(
    () => ["Sorting Algorithms", "Neural Networks", "Memory Hierarchies", "Concurrency Models"],
    [],
  )

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery)
    }, 300)

    return () => clearTimeout(timer)
  }, [searchQuery])

  useEffect(() => {
    const handler = setTimeout(() => {
      if (debouncedQuery.trim() === "") {
        setSuggestions([])
        return
      }

      // Filter available concepts based on search query
      const filtered = availableConcepts.filter((concept) =>
        concept.toLowerCase().includes(debouncedQuery.toLowerCase()),
      )
      setSuggestions(filtered.slice(0, 8)) // Limit to 8 suggestions for better UI
    }, 300)

    return () => clearTimeout(handler)
  }, [debouncedQuery])

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToTop = () => {
    topRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  // Function to get the correct URL for a concept
  const getConceptUrl = (concept: string) => {
    const category = getCategoryForConcept(concept)
    return `/concepts/${category}?concept=${encodeURIComponent(concept)}`
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <div ref={topRef}></div>
      <ParticleBackground />
      <ThreeBackground />

      {/* Animated gradient background */}
      <div className="fixed inset-0 -z-5 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-black to-indigo-900/30 animate-gradient-shift"></div>
      </div>

      <div className="container relative z-10 mx-auto px-4 py-32">
        <motion.div
          style={{ y: headerY }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="mb-6"
          >
            <motion.h1
              className="text-5xl md:text-7xl font-bold mb-4 relative inline-block"
              animate={{
                textShadow: [
                  "0px 0px 0px rgba(59, 130, 246, 0)",
                  "0px 0px 10px rgba(59, 130, 246, 0.5)",
                  "0px 0px 0px rgba(59, 130, 246, 0)",
                ],
              }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            >
              Learn to{" "}
              <motion.span
                className="text-blue-400 relative inline-block"
                animate={{
                  rotateY: [0, 360],
                  filter: [
                    "drop-shadow(0 0 0px #3b82f6)",
                    "drop-shadow(0 0 5px #3b82f6)",
                    "drop-shadow(0 0 0px #3b82f6)",
                  ],
                }}
                transition={{
                  rotateY: { duration: 3, repeat: Number.POSITIVE_INFINITY, repeatDelay: 5 },
                  filter: { duration: 2, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" },
                }}
              >
                code
              </motion.span>{" "}
              visually
              {/* Glitch effect overlay */}
              <motion.span
                className="absolute top-0 left-0 w-full h-full text-blue-400 opacity-0 mix-blend-screen"
                animate={{
                  opacity: [0, 0.1, 0],
                  x: [0, -3, 3, -2, 0],
                  y: [0, 2, -1, 0],
                }}
                transition={{
                  duration: 0.5,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatDelay: 5,
                }}
              >
                Learn to code visually
              </motion.span>
            </motion.h1>

            <motion.p
              className="text-xl md:text-2xl text-gray-400"
              animate={{
                opacity: [0.8, 1, 0.8],
              }}
              transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
            >
              Interactive visualizations for computer science concepts
            </motion.p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="h-16 flex items-center justify-center mb-8"
          >
            <TypewriterEffect words={typewriterWords} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="max-w-2xl mx-auto relative"
          >
            <motion.div
              className="flex items-center border border-gray-800 rounded-lg bg-gray-900/50 backdrop-blur-sm overflow-hidden focus-within:ring-2 focus-within:ring-blue-500 transition-all"
              whileHover={{
                boxShadow: "0 0 15px rgba(59, 130, 246, 0.3)",
                scale: 1.02,
              }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <Search className="ml-3 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search for any CS concept..."
                className="flex-1 border-0 bg-transparent text-white placeholder:text-gray-400 focus-visible:ring-0 focus-visible:ring-offset-0"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </motion.div>

            <AnimatePresence>
              {suggestions.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute z-20 mt-1 w-full bg-gray-900/90 backdrop-blur-md border border-gray-800 rounded-lg shadow-lg overflow-hidden"
                >
                  <ul className="py-2">
                    {suggestions.map((suggestion, index) => {
                      return (
                        <motion.li
                          key={index}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                          whileHover={{
                            backgroundColor: "rgba(59, 130, 246, 0.1)",
                            x: 5,
                          }}
                        >
                          <Link
                            href={getConceptUrl(suggestion)}
                            className="flex items-center px-4 py-2 hover:bg-gray-800 transition-colors"
                          >
                            <span>{suggestion}</span>
                            <ChevronRight className="ml-auto h-4 w-4 text-gray-400" />
                          </Link>
                        </motion.li>
                      )
                    })}
                  </ul>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>

        <motion.div
          style={{ y: conceptsY }}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
        >
          <motion.h2
            className="text-2xl font-bold mb-8 text-center relative"
            whileInView={{
              textShadow: [
                "0 0 0px rgba(59, 130, 246, 0)",
                "0 0 8px rgba(59, 130, 246, 0.5)",
                "0 0 0px rgba(59, 130, 246, 0)",
              ],
            }}
            transition={{ duration: 2, repeat: 1 }}
          >
            Explore Core Concepts
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {concepts.map((concept, index) => (
              <ConceptCard
                key={index}
                title={concept.title}
                description={concept.description}
                icon={concept.icon}
                href={concept.href}
                delay={index * 0.1}
              />
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="mt-16 text-center"
        >
          <motion.div
            whileHover={{
              scale: 1.05,
              boxShadow: "0 0 20px rgba(59, 130, 246, 0.5)",
            }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              onClick={scrollToTop}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-full relative overflow-hidden group"
            >
              <span className="relative z-10">Start Learning</span>
              <motion.span
                className="absolute inset-0 bg-blue-500 z-0"
                initial={{ x: "-100%" }}
                whileHover={{ x: "100%" }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
              />
            </Button>
          </motion.div>
        </motion.div>
      </div>

      <Footer />

      {showScrollTop && (
        <motion.button
          style={{ opacity }}
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 p-3 rounded-full bg-blue-600 text-white shadow-lg z-50 hover:bg-blue-700 transition-colors"
          whileHover={{ scale: 1.1, rotate: 360 }}
          whileTap={{ scale: 0.9 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ rotate: { duration: 0.5 } }}
        >
          <ArrowUp className="h-6 w-6" />
        </motion.button>
      )}
    </main>
  )
}
