"use client"

import { motion } from "framer-motion"
import { ArrowRight, Code, Eye, Zap } from "lucide-react"

export default function HowItWorks() {
  const features = [
    {
      icon: <Eye className="h-8 w-8 text-blue-400" />,
      title: "Visual Learning",
      description:
        "See complex concepts come to life through interactive visualizations that make abstract ideas concrete and understandable.",
    },
    {
      icon: <Code className="h-8 w-8 text-blue-400" />,
      title: "Code Integration",
      description:
        "Connect theory with practice by seeing how code implementations relate to visual representations of algorithms and data structures.",
    },
    {
      icon: <Zap className="h-8 w-8 text-blue-400" />,
      title: "Interactive Exploration",
      description:
        "Control the pace of your learning by stepping through processes, adjusting parameters, and seeing immediate results.",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">How It Works</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Seekhocs transforms complex computer science concepts into intuitive visual experiences
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-black border border-gray-800 rounded-lg p-6 hover:border-blue-500 transition-all"
          >
            <div className="mb-4">{feature.icon}</div>
            <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-gray-400">{feature.description}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="text-center"
      >
        <h2 className="text-2xl font-bold mb-8">Learning Journey</h2>

        <div className="flex flex-col md:flex-row justify-between items-start max-w-4xl mx-auto">
          <div className="flex-1 p-4">
            <div className="bg-blue-500/10 rounded-full w-12 h-12 flex items-center justify-center mb-4 mx-auto">
              <span className="text-blue-400 font-bold">1</span>
            </div>
            <h3 className="text-lg font-semibold mb-2">Choose a Concept</h3>
            <p className="text-gray-400">
              Browse our library of computer science topics and select what you want to learn
            </p>
          </div>

          <div className="hidden md:block pt-8">
            <ArrowRight className="h-6 w-6 text-blue-400" />
          </div>

          <div className="flex-1 p-4">
            <div className="bg-blue-500/10 rounded-full w-12 h-12 flex items-center justify-center mb-4 mx-auto">
              <span className="text-blue-400 font-bold">2</span>
            </div>
            <h3 className="text-lg font-semibold mb-2">Explore Visually</h3>
            <p className="text-gray-400">
              Interact with dynamic visualizations that break down complex ideas step by step
            </p>
          </div>

          <div className="hidden md:block pt-8">
            <ArrowRight className="h-6 w-6 text-blue-400" />
          </div>

          <div className="flex-1 p-4">
            <div className="bg-blue-500/10 rounded-full w-12 h-12 flex items-center justify-center mb-4 mx-auto">
              <span className="text-blue-400 font-bold">3</span>
            </div>
            <h3 className="text-lg font-semibold mb-2">Master the Concept</h3>
            <p className="text-gray-400">Reinforce your understanding with code examples and practical applications</p>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
