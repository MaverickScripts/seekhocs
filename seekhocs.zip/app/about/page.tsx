"use client"

import { motion } from "framer-motion"
import { Github, Linkedin, Mail } from "lucide-react"
import Link from "next/link"

export default function About() {
  return (
    <div className="container mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">About Seekhocs</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Making computer science education more accessible through visual learning
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold mb-4">My Mission</h2>
          <p className="text-gray-400 mb-4">
            Seekhocs was created with a simple but powerful mission: to make computer science concepts more intuitive
            and accessible through interactive visualizations.
          </p>
          <p className="text-gray-400 mb-4">
            I believe that visual learning can bridge the gap between abstract theory and practical understanding,
            helping students, professionals, and enthusiasts alike to grasp complex ideas more effectively.
          </p>
          <p className="text-gray-400">
            By transforming algorithms, data structures, and other CS concepts into dynamic, interactive experiences, I
            aim to empower learners to build stronger mental models and deeper understanding.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-black border border-gray-800 rounded-lg p-8"
        >
          <h2 className="text-2xl font-bold mb-4">About the Creator</h2>
          <p className="text-gray-400 mb-6">
            Seekhocs was developed by Shreyas Chowdhury, a software engineer passionate about making computer science
            more approachable through visual and interactive learning experiences.
          </p>

          <div className="flex space-x-4">
            <Link
              href="https://github.com/MaverickScripts"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 text-gray-400 hover:text-blue-400 transition-colors"
            >
              <Github className="h-5 w-5" />
              <span>GitHub</span>
            </Link>
            <Link
              href="https://www.linkedin.com/in/shreyaschowdhury/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 text-gray-400 hover:text-blue-400 transition-colors"
            >
              <Linkedin className="h-5 w-5" />
              <span>LinkedIn</span>
            </Link>
            <Link
              href="mailto:contact@seekhocs.com"
              className="flex items-center space-x-2 text-gray-400 hover:text-blue-400 transition-colors"
            >
              <Mail className="h-5 w-5" />
              <span>Email</span>
            </Link>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
        className="text-center"
      >
        <h2 className="text-2xl font-bold mb-4">Get Involved</h2>
        <p className="text-gray-400 max-w-2xl mx-auto mb-8">
          Seekhocs is an evolving project, and I welcome contributions, feedback, and suggestions. If you're passionate
          about computer science education and visual learning, I'd love to hear from you.
        </p>
        <Link
          href="mailto:contact@seekhocs.com"
          className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors"
        >
          <Mail className="h-5 w-5" />
          <span>Get in Touch</span>
        </Link>
      </motion.div>
    </div>
  )
}
