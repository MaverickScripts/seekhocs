// This file contains knowledge for the chatbot to respond to user queries
// about computer science concepts

export const conceptKnowledge: Record<string, string[]> = {
  // Algorithms
  "Bubble Sort": [
    "Bubble Sort is a simple comparison-based sorting algorithm. It repeatedly steps through the list, compares adjacent elements, and swaps them if they're in the wrong order. The pass through the list is repeated until no swaps are needed. It has O(n²) time complexity, making it inefficient for large lists.",
    "Bubble Sort works by repeatedly traversing the list and comparing adjacent items. If they're in the wrong order, it swaps them. This process continues until no more swaps are needed. While simple to understand and implement, it's inefficient with O(n²) complexity in both worst and average cases.",
  ],
  "Quick Sort": [
    "Quick Sort is an efficient, divide-and-conquer sorting algorithm that works by selecting a 'pivot' element and partitioning the array around it. Elements smaller than the pivot go to the left, larger to the right. The sub-arrays are then recursively sorted. It has an average time complexity of O(n log n).",
    "Quick Sort is one of the most efficient sorting algorithms with average time complexity of O(n log n). It works by selecting a pivot, partitioning the array around it, and recursively sorting the sub-arrays. While it can degrade to O(n²) in worst cases, optimizations like randomized pivot selection make this rare in practice.",
  ],
  "Merge Sort": [
    "Merge Sort is a divide-and-conquer algorithm that divides the input array into two halves, recursively sorts them, and then merges the sorted halves. It guarantees O(n log n) time complexity in all cases but requires O(n) extra space for the merging process.",
    "Merge Sort consistently performs at O(n log n) time complexity regardless of the input data, making it reliable for sorting large datasets. It divides the array into smaller subarrays until they contain single elements, then merges them back together in sorted order.",
  ],

  // Data Structures
  Arrays: [
    "Arrays are one of the most fundamental data structures, storing elements in contiguous memory locations. They provide O(1) random access but have fixed size in many languages. Operations like insertion and deletion in the middle are O(n) as they require shifting elements.",
    "Arrays store elements of the same type in adjacent memory locations, allowing constant-time access to any element using its index. They're efficient for random access but inefficient for insertions and deletions in the middle, which require shifting elements.",
  ],
  "Linked Lists": [
    "Linked Lists store elements in nodes that contain data and a reference to the next node. They allow efficient O(1) insertions and deletions anywhere in the list if you have a reference to the position. However, random access is O(n) as you must traverse from the beginning.",
    "Unlike arrays, Linked Lists don't require contiguous memory allocation. Each element (node) contains data and a pointer to the next node. This structure allows for efficient insertions and deletions but makes random access slower as you must traverse the list from the beginning.",
  ],
  "Binary Trees": [
    "A Binary Tree is a hierarchical data structure where each node has at most two children, referred to as left and right child. They're used in various applications like expression parsing, Huffman coding, and as a foundation for more complex tree structures like BSTs.",
    "Binary Trees organize data hierarchically with each node having at most two children. They enable efficient searching, insertion, and deletion operations when balanced properly. They're fundamental to many algorithms and more specialized tree structures like Binary Search Trees and Heaps.",
  ],

  // Computer Architecture
  "CPU Architecture": [
    "CPU architecture refers to the design and organization of a computer's central processing unit. It includes components like the ALU (Arithmetic Logic Unit), control unit, registers, and cache. Modern CPUs often employ pipelining, superscalar execution, and out-of-order execution to improve performance.",
    "Modern CPU architectures include complex features like multiple cores, SIMD instructions, branch prediction, and speculative execution. The design balances factors like performance, power consumption, and heat generation. Understanding CPU architecture helps in optimizing code for specific processors.",
  ],
  "Memory Hierarchy": [
    "Memory hierarchy in computer architecture refers to the layered structure of memory, from fast but small registers and caches to slower but larger main memory and secondary storage. This hierarchy exploits locality of reference to improve average memory access time.",
    "The memory hierarchy includes registers (fastest), multiple levels of cache (L1, L2, L3), main memory (RAM), and secondary storage (SSDs, HDDs). Each level trades off speed for capacity, with caching algorithms trying to keep frequently accessed data in faster memory levels.",
  ],

  // Neural Networks
  Perceptrons: [
    "A perceptron is the simplest form of a neural network, consisting of a single neuron. It takes multiple binary inputs, applies weights, and produces a binary output based on whether the weighted sum exceeds a threshold. It can only learn linearly separable patterns.",
    "Perceptrons, introduced by Frank Rosenblatt in 1957, are the building blocks of neural networks. A single perceptron can classify linearly separable data by applying weights to inputs and activating if their sum exceeds a threshold. Multiple perceptrons can be combined to form more complex networks.",
  ],
  "Convolutional Neural Networks": [
    "Convolutional Neural Networks (CNNs) are specialized neural networks designed primarily for image processing. They use convolutional layers to automatically learn spatial hierarchies of features through filters that scan the input data. CNNs have revolutionized computer vision tasks.",
    "CNNs use convolutional layers that apply filters across the input, pooling layers that reduce dimensionality, and fully connected layers for final classification. This architecture is particularly effective for image recognition as it preserves spatial relationships between pixels.",
  ],

  // Operating Systems
  "Process Management": [
    "Process management is a fundamental function of operating systems, involving the creation, scheduling, and termination of processes. It includes activities like context switching, inter-process communication, and synchronization to ensure efficient and fair use of system resources.",
    "Operating systems manage processes through schedulers that determine which process runs when, and for how long. They handle process states (running, ready, blocked), context switching, and provide mechanisms for inter-process communication and synchronization to prevent race conditions.",
  ],
  "Virtual Memory": [
    "Virtual memory is a memory management technique that provides an idealized abstraction of the storage resources available to a program. It maps memory addresses used by a program, called virtual addresses, to physical addresses in computer memory.",
    "Virtual memory allows programs to use more memory than physically available by using disk space as an extension. It provides memory isolation between processes, simplifies memory allocation, and enables features like memory-mapped files and shared memory.",
  ],

  // Cryptography
  "RSA Algorithm": [
    "RSA (Rivest–Shamir–Adleman) is a public-key cryptosystem widely used for secure data transmission. It's based on the practical difficulty of factoring the product of two large prime numbers. RSA involves key generation, encryption, and decryption processes using modular exponentiation.",
    "RSA security relies on the mathematical difficulty of factoring large numbers. It generates public and private keys using two large prime numbers. The public key is used for encryption, while the private key is kept secret and used for decryption. RSA is widely used in secure communications and digital signatures.",
  ],
  "Hash Functions": [
    "Cryptographic hash functions transform data of arbitrary size into a fixed-size output (hash) in a way that's designed to be one-way and collision-resistant. They're essential for data integrity verification, password storage, digital signatures, and blockchain technology.",
    "Good cryptographic hash functions like SHA-256 have properties including: one-way (can't derive input from output), deterministic (same input always gives same output), avalanche effect (small input changes cause large output changes), and collision resistance (difficult to find two inputs with same hash).",
  ],

  // Automata Theory
  "Turing Machines": [
    "A Turing Machine is a mathematical model of computation that defines an abstract machine which manipulates symbols on a strip of tape according to a table of rules. Despite its simplicity, it can simulate the logic of any computer algorithm and is used to study the limits of computation.",
    "Turing Machines consist of a tape divided into cells, a head that can read/write symbols and move left or right, a state register storing the state, and a table of instructions. They're fundamental to theoretical computer science and the concept of computational universality.",
  ],
  "Deterministic Finite Automata": [
    "Deterministic Finite Automata (DFA) is a finite state machine that accepts or rejects strings of symbols. In a DFA, for each state and input symbol, there is exactly one transition to a next state. DFAs recognize exactly the set of regular languages.",
    "A DFA consists of states, an alphabet, transition functions, an initial state, and accepting states. It processes input symbols one by one, moving between states according to the transition function. If it ends in an accepting state, the input string is accepted; otherwise, it's rejected.",
  ],

  // Compilers
  "Lexical Analysis": [
    "Lexical analysis is the first phase of a compiler, where the source code is converted into a sequence of tokens. A token is a string with an assigned meaning, such as keywords, identifiers, operators, and literals. This phase is typically implemented using regular expressions and finite automata.",
    "The lexical analyzer (lexer) scans the source code character by character, identifying tokens like keywords, identifiers, and literals. It removes whitespace and comments, handles lexical errors, and passes tokens to the parser. Lexers are often generated automatically using tools like Lex/Flex.",
  ],
  Parsing: [
    "Parsing is the process of analyzing a string of symbols according to the rules of a formal grammar. In compilers, it's the second phase where tokens from lexical analysis are organized into a parse tree or abstract syntax tree (AST) that represents the syntactic structure of the program.",
    "Parsers use context-free grammars to check if the sequence of tokens conforms to the language syntax. Common parsing techniques include recursive descent, LL, LR, LALR, and parser generators like Yacc/Bison. The output is typically an abstract syntax tree used for semantic analysis and code generation.",
  ],

  // Networking
  "TCP/IP Protocol": [
    "TCP/IP (Transmission Control Protocol/Internet Protocol) is the fundamental communication protocol of the Internet. It's a four-layer model including Link, Internet, Transport, and Application layers. TCP provides reliable, ordered delivery of data, while IP handles addressing and routing.",
    "TCP/IP enables devices to communicate across networks regardless of their underlying architecture. IP handles routing packets to their destination using IP addresses, while TCP ensures reliable delivery by establishing connections, sequencing packets, acknowledging receipt, and retransmitting lost packets.",
  ],
  "HTTP Protocol": [
    "HTTP (Hypertext Transfer Protocol) is an application layer protocol for distributed, collaborative, hypermedia information systems. It's the foundation of data communication for the World Wide Web, where hypertext documents include links to other resources.",
    "HTTP is a stateless request-response protocol where clients (browsers) send requests to servers, which respond with status codes and requested resources. Modern versions include HTTP/2 with multiplexing and header compression, and HTTP/3 which uses QUIC for improved performance over unreliable connections.",
  ],

  // Database Systems
  "SQL Query Execution": [
    "SQL query execution involves multiple phases: parsing the query into a syntax tree, transforming it into a logical query plan, optimizing the plan based on statistics and cost models, and finally executing the physical query plan to retrieve or modify data efficiently.",
    "When a database executes an SQL query, it goes through parsing, validation, optimization, and execution. The query optimizer evaluates different execution plans (join orders, access methods) to minimize I/O and CPU usage. Understanding this process helps in writing efficient queries and indexing strategies.",
  ],
  Indexing: [
    "Database indexing is a data structure technique to efficiently retrieve records from a database. Indexes are created using one or more columns, providing the database with a quick lookup mechanism to locate records without scanning the entire table.",
    "Indexes speed up queries but slow down writes as they must be updated. Common index types include B-trees (balanced for range queries), hash indexes (fast exact lookups), and specialized indexes like spatial or full-text. Proper indexing is crucial for database performance as tables grow.",
  ],

  // Programming Languages
  "Variables and Data Types": [
    "Variables are named storage locations for data, while data types define the kind of data a variable can hold. Programming languages implement various type systems, from static typing (types checked at compile time) to dynamic typing (types checked at runtime).",
    "Different programming languages handle variables and data types differently. Statically-typed languages like C++ and Java require explicit type declarations, while dynamically-typed languages like Python and JavaScript determine types at runtime. Understanding type systems is fundamental to writing correct and efficient code.",
  ],
  "Object-Oriented Programming": [
    "Object-Oriented Programming (OOP) is a programming paradigm based on the concept of 'objects' containing data and code. It features concepts like classes, inheritance, encapsulation, and polymorphism to create modular, reusable code structures.",
    "OOP organizes code around objects rather than functions and logic. Key principles include encapsulation (hiding internal state), inheritance (building hierarchies of classes), polymorphism (same interface for different underlying forms), and abstraction (simplifying complex reality by modeling classes).",
  ],
  "Functional Programming": [
    "Functional Programming is a programming paradigm that treats computation as the evaluation of mathematical functions and avoids changing state and mutable data. It emphasizes expressions over statements, immutability, and functions as first-class citizens.",
    "Functional programming focuses on what to solve rather than how to solve it. It uses pure functions (same output for same input, no side effects), higher-order functions, and immutable data. Languages like Haskell are purely functional, while others like JavaScript and Python support functional programming concepts.",
  ],
}

export const categoryKnowledge: Record<string, string> = {
  algorithms:
    "Algorithms are step-by-step procedures for solving problems or accomplishing tasks. They're the foundation of computer science and programming. We cover sorting algorithms (like Quick Sort, Merge Sort), searching algorithms (Binary Search, BFS, DFS), and algorithmic paradigms like dynamic programming and greedy algorithms.",

  "data-structures":
    "Data structures are specialized formats for organizing, processing, retrieving, and storing data. Efficient data structures are key to designing efficient algorithms. We cover arrays, linked lists, stacks, queues, trees, graphs, hash tables, and more advanced structures.",

  architecture:
    "Computer architecture deals with the design and organization of computer systems. This includes CPU design, memory hierarchies, instruction sets, pipelining, and how hardware components interact. Understanding architecture helps optimize code and design efficient systems.",

  "neural-networks":
    "Neural networks are computing systems inspired by biological neural networks. They're the foundation of deep learning, a subset of machine learning. We cover various network architectures, training algorithms, and applications in areas like computer vision and natural language processing.",

  "operating-systems":
    "Operating systems are the interface between computer hardware and users. They manage hardware resources, provide services for programs, and ensure security and stability. Topics include process management, memory management, file systems, and scheduling algorithms.",

  cryptography:
    "Cryptography is the practice of secure communication in the presence of adversaries. It involves creating and analyzing protocols that prevent third parties from reading private messages. We cover encryption algorithms, hash functions, digital signatures, and cryptographic protocols.",

  "automata-theory":
    "Automata theory studies abstract machines and the computational problems they can solve. It's fundamental to the theory of computation and formal language theory. We cover finite automata, regular expressions, context-free grammars, Turing machines, and computational complexity.",

  compilers:
    "Compiler design involves translating source code written in a high-level language to a lower-level language. This process includes lexical analysis, parsing, semantic analysis, optimization, and code generation. Understanding compilers helps in creating new languages and tools.",

  networking:
    "Computer networking involves the study of how computers communicate with each other. Topics include network protocols (TCP/IP, HTTP), routing algorithms, network topologies, and security. Networking is essential for distributed systems and the internet.",

  "database-systems":
    "Database systems store, retrieve, and manage data efficiently. We cover relational databases, SQL, NoSQL systems, indexing techniques, transaction processing, and query optimization. Understanding databases is crucial for building data-driven applications.",

  "programming-languages":
    "Programming languages are formal languages with a set of rules for writing computer programs. We cover language design principles, syntax and semantics, type systems, memory management, and paradigms like object-oriented, functional, and procedural programming.",
}

// General questions and responses
export const generalKnowledge: Record<string, string[]> = {
  greeting: [
    "Hello! I'm BytBot, your CS learning assistant. How can I help you today?",
    "Hi there! I'm here to help with computer science concepts. What would you like to learn about?",
    "Greetings! I'm BytBot, ready to assist with your CS questions. What topic are you interested in?",
  ],

  help: [
    "I can answer questions about computer science concepts covered on this site, including algorithms, data structures, computer architecture, neural networks, operating systems, cryptography, automata theory, compilers, networking, database systems, and programming languages. What would you like to learn about?",
    "I'm here to help with any CS concept on this site. You can ask about specific topics like 'How does Quick Sort work?' or broader areas like 'Tell me about neural networks.' What are you curious about?",
    "I can explain CS concepts, compare different approaches, and help clarify complex topics in computer science. Just ask about any subject covered on this site, and I'll do my best to assist!",
  ],

  thanks: [
    "You're welcome! If you have any more questions about CS concepts, feel free to ask.",
    "Happy to help! Let me know if you want to explore any other computer science topics.",
    "Glad I could assist! Don't hesitate to ask if you need clarification or want to learn about other CS concepts.",
  ],

  default: [
    "I'm specialized in computer science topics covered on this site. I can help with algorithms, data structures, computer architecture, neural networks, operating systems, cryptography, automata theory, compilers, networking, database systems, and programming languages. Could you ask something related to these areas?",
    "I focus on computer science concepts that are covered on this platform. If you have questions about any CS topic like algorithms, data structures, or programming languages, I'd be happy to help!",
    "I'm designed to answer questions about computer science topics on this site. If you're looking for information outside these areas, I might not be able to provide accurate answers. What CS concept would you like to explore?",
  ],
}
