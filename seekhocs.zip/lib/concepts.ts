// Define all available concepts organized by category
export const conceptsByCategory = {
  algorithms: [
    "Bubble Sort",
    "Quick Sort",
    "Merge Sort",
    "Insertion Sort",
    "Selection Sort",
    "Heap Sort",
    "Radix Sort",
    "Counting Sort",
    "Binary Search",
    "Linear Search",
    "Breadth-First Search",
    "Depth-First Search",
    "Dijkstra's Algorithm",
    "A* Search Algorithm",
    "Greedy Algorithms",
    "Dynamic Programming",
  ],
  "data-structures": [
    "Arrays",
    "Linked Lists",
    "Stacks",
    "Queues",
    "Hash Tables",
    "Binary Trees",
    "Binary Search Trees",
    "AVL Trees",
    "Red-Black Trees",
    "Heaps",
    "Graphs",
    "Tries",
    "B-Trees",
    "Segment Trees",
    "Disjoint Set",
  ],
  architecture: [
    "CPU Architecture",
    "Memory Hierarchy",
    "Cache Memory",
    "Instruction Pipeline",
    "Branch Prediction",
    "RISC vs CISC",
    "Von Neumann Architecture",
    "Harvard Architecture",
    "Multicore Processors",
    "SIMD Instructions",
    "Memory Management Unit",
    "Virtual Memory",
    "I/O Systems",
    "Bus Architecture",
    "Interrupts and DMA",
  ],
  "neural-networks": [
    "Perceptrons",
    "Multilayer Networks",
    "Backpropagation",
    "Activation Functions",
    "Convolutional Neural Networks",
    "Recurrent Neural Networks",
    "LSTM Networks",
    "GRU Networks",
    "Autoencoders",
    "Generative Adversarial Networks",
    "Transfer Learning",
    "Reinforcement Learning",
    "Self-Organizing Maps",
    "Radial Basis Functions",
    "Hopfield Networks",
  ],
  "operating-systems": [
    "Process Management",
    "Thread Management",
    "CPU Scheduling",
    "Memory Management",
    "Virtual Memory",
    "File Systems",
    "I/O Management",
    "Deadlocks",
    "Synchronization",
    "Concurrency Control",
    "Interprocess Communication",
    "Protection and Security",
    "Virtualization",
    "Distributed Systems",
    "Real-Time Operating Systems",
  ],
  cryptography: [
    "Caesar Cipher",
    "Vigenère Cipher",
    "RSA Algorithm",
    "AES Encryption",
    "DES Encryption",
    "Diffie-Hellman Key Exchange",
    "Elliptic Curve Cryptography",
    "Hash Functions",
    "Digital Signatures",
    "Public Key Infrastructure",
    "Symmetric vs Asymmetric Encryption",
    "Block Ciphers",
    "Stream Ciphers",
    "Message Authentication Codes",
    "Zero-Knowledge Proofs",
  ],
  "automata-theory": [
    "Turing Machines",
    "Deterministic Finite Automata",
    "Non-deterministic Finite Automata",
    "Regular Expressions",
    "Context-Free Grammars",
    "Pushdown Automata",
    "Chomsky Hierarchy",
    "Pumping Lemma",
    "State Minimization",
    "Decidability",
    "Halting Problem",
    "Complexity Classes",
    "P vs NP Problem",
    "Automata Transformations",
    "Regular Languages",
  ],
  compilers: [
    "Lexical Analysis",
    "Parsing",
    "Syntax Analysis",
    "Semantic Analysis",
    "Code Generation",
    "Code Optimization",
    "Symbol Tables",
    "Type Checking",
    "Intermediate Representation",
    "Register Allocation",
    "Control Flow Analysis",
    "Data Flow Analysis",
    "Error Recovery",
    "Just-In-Time Compilation",
    "Compiler Optimizations",
  ],
  networking: [
    "TCP/IP Protocol",
    "OSI Model",
    "HTTP Protocol",
    "DNS System",
    "Routing Algorithms",
    "Network Topologies",
    "Subnetting",
    "IP Addressing",
    "MAC Addressing",
    "ARP Protocol",
    "DHCP Protocol",
    "NAT",
    "Firewalls",
    "Load Balancing",
    "Wireless Networks",
  ],
  "database-systems": [
    "SQL Query Execution",
    "NoSQL Data Models",
    "Indexing",
    "Caching",
    "Transaction Processing",
    "ACID Properties",
    "Normalization",
    "Database Design",
    "Query Optimization",
    "Concurrency Control",
    "Recovery Systems",
    "Distributed Databases",
    "Data Warehousing",
    "OLAP vs OLTP",
    "Database Security",
  ],
}

// Flatten the concepts for search functionality
export const availableConcepts = Object.values(conceptsByCategory).flat()

// Function to get concepts by category
export const getConceptsByCategory = (category: string) => {
  return conceptsByCategory[category as keyof typeof conceptsByCategory] || []
}

// Function to get the category for a concept
export const getCategoryForConcept = (concept: string): string => {
  // First try exact match
  for (const [category, concepts] of Object.entries(conceptsByCategory)) {
    if (concepts.includes(concept)) {
      return category
    }
  }

  // If exact match not found, try to find a partial match
  const lowerConcept = concept.toLowerCase()
  for (const [category, concepts] of Object.entries(conceptsByCategory)) {
    for (const c of concepts) {
      if (c.toLowerCase().includes(lowerConcept) || lowerConcept.includes(c.toLowerCase())) {
        return category
      }
    }
  }

  // Default to algorithms if no match found
  return "algorithms"
}

