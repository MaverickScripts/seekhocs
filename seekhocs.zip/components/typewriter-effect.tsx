"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface TypewriterEffectProps {
  words: string[]
  typingSpeed?: number
  deletingSpeed?: number
  delayBetweenWords?: number
}

const TypewriterEffect = ({
  words,
  typingSpeed = 100,
  deletingSpeed = 50,
  delayBetweenWords = 1500,
}: TypewriterEffectProps) => {
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [currentText, setCurrentText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)
  const [isBlinking, setIsBlinking] = useState(true)

  useEffect(() => {
    const timeout = setTimeout(
      () => {
        // Handle cursor blinking
        setIsBlinking((prev) => !prev)

        // Current word being typed/deleted
        const currentWord = words[currentWordIndex]

        // If deleting
        if (isDeleting) {
          setCurrentText(currentWord.substring(0, currentText.length - 1))

          // If deleted completely, start typing the next word
          if (currentText.length === 0) {
            setIsDeleting(false)
            setCurrentWordIndex((prevIndex) => (prevIndex + 1) % words.length)
          }
        }
        // If typing
        else {
          setCurrentText(currentWord.substring(0, currentText.length + 1))

          // If typed completely, wait and then start deleting
          if (currentText.length === currentWord.length) {
            setTimeout(() => {
              setIsDeleting(true)
            }, delayBetweenWords)
          }
        }
      },
      isDeleting ? deletingSpeed : typingSpeed,
    )

    return () => clearTimeout(timeout)
  }, [currentText, isDeleting, currentWordIndex, words, typingSpeed, deletingSpeed, delayBetweenWords])

  return (
    <div className="inline-flex items-center">
      <motion.span
        className="text-2xl md:text-3xl font-mono text-cyan-400"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {currentText}
        <span
          className={`ml-1 inline-block w-2 h-6 bg-cyan-400 ${isBlinking ? "opacity-100" : "opacity-0"} transition-opacity duration-300`}
        ></span>
      </motion.span>
    </div>
  )
}

export default TypewriterEffect

