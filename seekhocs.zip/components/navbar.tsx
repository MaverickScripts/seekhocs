"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-black/80 backdrop-blur-md py-3" : "bg-transparent py-5"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link href="/" className="flex items-center">
          <motion.span className="text-2xl font-bold text-blue-400" whileHover={{ color: "#60a5fa" }}>
            Seekhocs
          </motion.span>
          <motion.div
            className="h-1 w-12 bg-blue-500 mt-1 ml-1"
            whileHover={{ width: 60 }}
            transition={{ duration: 0.3 }}
          />
        </Link>
      </div>
    </motion.nav>
  )
}
