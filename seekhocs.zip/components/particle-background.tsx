"use client"

import { useEffect, useRef, useState } from "react"
import { motion } from "framer-motion"

interface Particle {
  x: number
  y: number
  size: number
  speedX: number
  speedY: number
  opacity: number
}

const ParticleBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [particles, setParticles] = useState<Particle[]>([])
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    // Reduce number of particles from 100 to 30 for better performance
    const particleCount = 30
    const newParticles: Particle[] = []

    for (let i = 0; i < particleCount; i++) {
      newParticles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        size: Math.random() * 3 + 1,
        speedX: (Math.random() - 0.5) * 0.5, // Reduced speed
        speedY: (Math.random() - 0.5) * 0.5, // Reduced speed
        opacity: Math.random() * 0.5 + 0.1,
      })
    }

    setParticles(newParticles)
  }, [])

  useEffect(() => {
    const handleVisibilityChange = () => {
      setIsVisible(!document.hidden)
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [])

  useEffect(() => {
    if (!isVisible) return // Skip animation when not visible

    let animationFrameId: number
    let lastTime = 0
    const fps = 30 // Limit to 30 FPS
    const fpsInterval = 1000 / fps

    const animate = (timestamp: number) => {
      animationFrameId = requestAnimationFrame(animate)

      // Calculate elapsed time
      const elapsed = timestamp - lastTime

      // Only update if enough time has passed
      if (elapsed > fpsInterval) {
        lastTime = timestamp - (elapsed % fpsInterval)

        // Update particles
        setParticles((prevParticles) =>
          prevParticles.map((particle) => {
            let newX = particle.x + particle.speedX
            let newY = particle.y + particle.speedY

            // Boundary check
            if (newX < 0 || newX > window.innerWidth) {
              particle.speedX *= -1
              newX = particle.x + particle.speedX
            }

            if (newY < 0 || newY > window.innerHeight) {
              particle.speedY *= -1
              newY = particle.y + particle.speedY
            }

            return {
              ...particle,
              x: newX,
              y: newY,
            }
          }),
        )
      }
    }

    animationFrameId = requestAnimationFrame(animate)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [isVisible])

  return (
    <motion.canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full h-full -z-10"
      initial={{ opacity: 0 }}
      animate={{ opacity: isVisible ? 1 : 0 }}
      transition={{ duration: 1.5 }}
    />
  )
}

export default ParticleBackground
