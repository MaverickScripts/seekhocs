"use client"

import { useRef, useEffect, useState, useMemo } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Stars, Text } from "@react-three/drei"
import * as THREE from "three"

function FloatingParticles({ count = 50, color = "#5eead4" }) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const light = useRef<THREE.PointLight>(null)
  const [initialized, setInitialized] = useState(false)

  // Create a memo for particle positions to avoid recalculations
  const positions = useMemo(() => {
    const positions = []
    for (let i = 0; i < count; i++) {
      positions.push({
        position: new THREE.Vector3((Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20),
        scale: Math.random() * 0.2 + 0.05,
        speed: Math.random() * 0.02 + 0.01,
        offset: Math.random() * Math.PI * 2,
      })
    }
    return positions
  }, [count])

  useEffect(() => {
    if (!mesh.current || initialized) return

    // Position instances randomly
    const dummy = new THREE.Object3D()

    for (let i = 0; i < count; i++) {
      const { position, scale } = positions[i]
      dummy.position.copy(position)
      dummy.scale.setScalar(scale)
      dummy.updateMatrix()

      mesh.current.setMatrixAt(i, dummy.matrix)
    }

    mesh.current.instanceMatrix.needsUpdate = true
    setInitialized(true)
  }, [count, initialized, positions])

  useFrame(({ clock }) => {
    if (!mesh.current || !light.current) return

    // Animate light - slower movement
    const time = clock.getElapsedTime() * 0.2
    light.current.position.x = Math.sin(time * 0.3) * 8
    light.current.position.y = Math.cos(time * 0.2) * 8
    light.current.position.z = Math.sin(time * 0.1) * 8

    // Animate light color for a subtle effect
    const hue = (time * 0.05) % 1
    light.current.color.setHSL(hue, 0.8, 0.5)

    // Animate particles - less frequent updates
    if (Math.floor(time * 10) % 2 === 0) {
      const dummy = new THREE.Object3D()
      const matrix = new THREE.Matrix4()

      for (let i = 0; i < count; i++) {
        mesh.current.getMatrixAt(i, matrix)
        dummy.position.setFromMatrixPosition(matrix)

        // Add more dynamic movement
        const { speed, offset } = positions[i]
        dummy.position.y += Math.sin(time + offset) * speed
        dummy.position.x += Math.cos(time * 0.8 + offset) * speed
        dummy.position.z += Math.sin(time * 0.5 + offset) * speed * 0.5

        // Add subtle scale pulsing
        const scalePulse = Math.sin(time * 2 + i) * 0.05 + 1
        const baseScale = positions[i].scale
        dummy.scale.set(baseScale * scalePulse, baseScale * scalePulse, baseScale * scalePulse)

        dummy.updateMatrix()
        mesh.current.setMatrixAt(i, dummy.matrix)
      }

      mesh.current.instanceMatrix.needsUpdate = true
    }
  })

  return (
    <>
      <pointLight ref={light} distance={20} intensity={1.5} color={color} />
      <instancedMesh ref={mesh} args={[undefined, undefined, count]}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.3} transparent opacity={0.5} />
      </instancedMesh>
    </>
  )
}

// Add floating emoji elements for Gen Z appeal
function FloatingEmojis({ count = 10 }) {
  const emojis = useMemo(() => ["🚀", "💻", "⚡", "🔥", "✨", "🤖", "🧠", "💡", "🔍", "🌐"], [])
  const group = useRef<THREE.Group>(null)

  useFrame(({ clock }) => {
    if (!group.current) return

    const time = clock.getElapsedTime()
    group.current.children.forEach((child, i) => {
      const offset = (i * Math.PI) / 5
      child.position.y = Math.sin(time * 0.5 + offset) * 2
      child.rotation.z = Math.sin(time * 0.3 + offset) * 0.2
      child.scale.setScalar(Math.sin(time + offset) * 0.1 + 0.9)
    })
  })

  return (
    <group ref={group}>
      {Array.from({ length: count }).map((_, i) => (
        <Text
          key={i}
          position={[(Math.random() - 0.5) * 30, (Math.random() - 0.5) * 30, (Math.random() - 0.5) * 30]}
          fontSize={2}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          {emojis[i % emojis.length]}
        </Text>
      ))}
    </group>
  )
}

function FloatingGrid() {
  const gridRef = useRef<THREE.Group>(null)

  useFrame(({ clock }) => {
    if (!gridRef.current) return

    const time = clock.getElapsedTime() * 0.05
    gridRef.current.rotation.x = Math.sin(time * 0.1) * 0.05
    gridRef.current.rotation.z = Math.cos(time * 0.1) * 0.05

    // Add a subtle wave effect to the grid
    gridRef.current.children.forEach((child, i) => {
      if (child instanceof THREE.GridHelper) {
        child.position.y = Math.sin(time * 0.5 + i) * 0.2
      }
    })
  })

  return (
    <group ref={gridRef}>
      <gridHelper args={[30, 15, "#304050", "#304050"]} position={[0, -10, 0]} rotation={[Math.PI / 2, 0, 0]} />
      <gridHelper args={[30, 15, "#304050", "#304050"]} position={[0, 10, 0]} rotation={[Math.PI / 2, 0, 0]} />
      <gridHelper args={[30, 15, "#304050", "#304050"]} position={[0, 0, -10]} />
    </group>
  )
}

export default function ThreeBackground() {
  const [isVisible, setIsVisible] = useState(true)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          setIsVisible(entry.isIntersecting)
        })
      },
      { threshold: 0.1 },
    )

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current)
      }
    }
  }, [])

  if (!isVisible) {
    return <div ref={containerRef} className="fixed top-0 left-0 w-full h-screen -z-10 opacity-0" />
  }

  return (
    <div ref={containerRef} className="fixed top-0 left-0 w-full h-screen -z-10 opacity-20">
      <Canvas camera={{ position: [0, 0, 15], fov: 60 }} dpr={[1, 1.5]}>
        <color attach="background" args={["#000000"]} />
        <ambientLight intensity={0.1} />
        <FloatingParticles count={75} color="#3b82f6" />
        <FloatingParticles count={50} color="#1e40af" />
        <FloatingGrid />
        <FloatingEmojis count={8} />
        <Stars radius={100} depth={50} count={500} factor={4} fade speed={0.5} />
        <OrbitControls enableZoom={false} enablePan={false} enableRotate={false} autoRotate autoRotateSpeed={0.2} />
      </Canvas>
    </div>
  )
}
