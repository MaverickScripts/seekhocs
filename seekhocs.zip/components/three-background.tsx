"use client"

import { useRef, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Stars } from "@react-three/drei"
import * as THREE from "three"

function FloatingParticles({ count = 100, color = "#5eead4" }) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const light = useRef<THREE.PointLight>(null)

  useEffect(() => {
    if (!mesh.current) return

    // Position instances randomly
    const dummy = new THREE.Object3D()
    const matrix = new THREE.Matrix4()

    for (let i = 0; i < count; i++) {
      dummy.position.set((Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20)

      dummy.scale.setScalar(Math.random() * 0.2 + 0.05)
      dummy.updateMatrix()

      mesh.current.setMatrixAt(i, dummy.matrix)
    }

    mesh.current.instanceMatrix.needsUpdate = true
  }, [count])

  useFrame(({ clock }) => {
    if (!mesh.current || !light.current) return

    // Animate light
    const time = clock.getElapsedTime()
    light.current.position.x = Math.sin(time * 0.3) * 8
    light.current.position.y = Math.cos(time * 0.2) * 8
    light.current.position.z = Math.sin(time * 0.1) * 8

    // Animate particles
    const dummy = new THREE.Object3D()
    const matrix = new THREE.Matrix4()

    for (let i = 0; i < count; i++) {
      mesh.current.getMatrixAt(i, matrix)
      dummy.position.setFromMatrixPosition(matrix)

      // Add subtle movement
      dummy.position.y += Math.sin(time + i) * 0.005
      dummy.position.x += Math.cos(time + i * 0.1) * 0.005

      dummy.updateMatrix()
      mesh.current.setMatrixAt(i, dummy.matrix)
    }

    mesh.current.instanceMatrix.needsUpdate = true
  })

  return (
    <>
      <pointLight ref={light} distance={20} intensity={2} color={color} />
      <instancedMesh ref={mesh} args={[undefined, undefined, count]}>
        <sphereGeometry args={[1, 16, 16]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.5} transparent opacity={0.7} />
      </instancedMesh>
    </>
  )
}

function FloatingGrid() {
  const gridRef = useRef<THREE.Group>(null)

  useFrame(({ clock }) => {
    if (!gridRef.current) return

    const time = clock.getElapsedTime()
    gridRef.current.rotation.x = Math.sin(time * 0.1) * 0.1
    gridRef.current.rotation.z = Math.cos(time * 0.1) * 0.1
  })

  return (
    <group ref={gridRef}>
      <gridHelper args={[30, 30, "#304050", "#304050"]} position={[0, -10, 0]} rotation={[Math.PI / 2, 0, 0]} />
      <gridHelper args={[30, 30, "#304050", "#304050"]} position={[0, 10, 0]} rotation={[Math.PI / 2, 0, 0]} />
    </group>
  )
}

function FloatingCube() {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    if (!meshRef.current) return

    const time = clock.getElapsedTime()
    meshRef.current.rotation.x = time * 0.2
    meshRef.current.rotation.y = time * 0.3
    meshRef.current.position.y = Math.sin(time * 0.5) * 2
  })

  return (
    <mesh ref={meshRef} position={[5, 0, -5]}>
      <boxGeometry args={[2, 2, 2]} />
      <meshStandardMaterial color="#9f7aea" emissive="#9f7aea" emissiveIntensity={0.2} wireframe />
    </mesh>
  )
}

function FloatingSphere() {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    if (!meshRef.current) return

    const time = clock.getElapsedTime()
    meshRef.current.rotation.y = time * 0.1
    meshRef.current.position.x = Math.sin(time * 0.3) * 3
  })

  return (
    <mesh ref={meshRef} position={[-5, 0, -5]}>
      <sphereGeometry args={[1.5, 32, 32]} />
      <meshStandardMaterial color="#4fd1c5" emissive="#4fd1c5" emissiveIntensity={0.2} wireframe />
    </mesh>
  )
}

export default function ThreeBackground() {
  return (
    <div className="fixed top-0 left-0 w-full h-screen -z-10 opacity-60">
      <Canvas camera={{ position: [0, 0, 15], fov: 60 }}>
        <color attach="background" args={["#050510"]} />
        <ambientLight intensity={0.2} />
        <FloatingParticles count={150} color="#5eead4" />
        <FloatingParticles count={100} color="#9f7aea" />
        <FloatingGrid />
        <FloatingCube />
        <FloatingSphere />
        <Stars radius={100} depth={50} count={1000} factor={4} fade speed={1} />
        <OrbitControls enableZoom={false} enablePan={false} enableRotate={false} autoRotate autoRotateSpeed={0.5} />
      </Canvas>
    </div>
  )
}

