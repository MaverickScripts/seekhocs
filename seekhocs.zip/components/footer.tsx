"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Github, Linkedin } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <motion.footer
      className="w-full border-t border-gray-800 py-6 mt-16"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5, duration: 0.8 }}
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <motion.div
            className="text-gray-400 text-sm"
            whileHover={{ color: "#5eead4" }}
            transition={{ duration: 0.3 }}
          >
            Built by Shreyas Chowdhury
          </motion.div>

          <div className="flex items-center space-x-4 my-3 md:my-0">
            <Link
              href="https://github.com/MaverickScripts"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <Github className="h-5 w-5" />
            </Link>
            <Link
              href="https://www.linkedin.com/in/shreyaschowdhury/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <Linkedin className="h-5 w-5" />
            </Link>
          </div>

          <div className="text-gray-500 text-xs mt-2 md:mt-0">© {currentYear} SeekhoCS. All rights reserved.</div>
        </div>
      </div>
    </motion.footer>
  )
}

