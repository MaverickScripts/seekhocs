"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MessageSquare, X, Send, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { availableConcepts, conceptsByCategory } from "@/lib/concepts"
import { conceptKnowledge, categoryKnowledge, generalKnowledge } from "@/lib/chatbot-knowledge"

// Define message types
type MessageType = "user" | "bot"

interface Message {
  id: string
  type: MessageType
  text: string
  timestamp: Date
}

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "bot",
      text: "Hi there! I'm BytBot, your CS learning assistant. Ask me anything about the computer science concepts covered on this site!",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus()
      }, 300)
    }
  }, [isOpen])

  const toggleChat = () => {
    setIsOpen(!isOpen)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (inputValue.trim() === "") return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      text: inputValue,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate bot thinking and typing
    setTimeout(
      () => {
        const botResponse = generateResponse(inputValue)
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "bot",
          text: botResponse,
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, botMessage])
        setIsTyping(false)
      },
      1000 + Math.random() * 1000,
    ) // Random delay between 1-2 seconds
  }

  // Function to generate bot responses based on user input
  const generateResponse = (userInput: string): string => {
    const input = userInput.toLowerCase()

    // Check for general questions first
    if (input.includes("hello") || input.includes("hi") || input.includes("hey")) {
      return getRandomResponse(generalKnowledge.greeting)
    }

    if (input.includes("help") || input.includes("what can you do")) {
      return getRandomResponse(generalKnowledge.help)
    }

    if (input.includes("thank")) {
      return getRandomResponse(generalKnowledge.thanks)
    }

    // Check if the query is about a concept we cover
    const matchedConcept = availableConcepts.find((concept) => input.includes(concept.toLowerCase()))

    // Check if query is about a category
    const matchedCategory = Object.keys(conceptsByCategory).find(
      (category) => input.includes(category.toLowerCase()) || input.includes(category.replace("-", " ").toLowerCase()),
    )

    // If we found a specific concept
    if (matchedConcept) {
      return generateConceptResponse(matchedConcept)
    }

    // If we found a category
    if (matchedCategory) {
      const formattedCategory = matchedCategory.replace("-", " ")
      const conceptsInCategory = conceptsByCategory[matchedCategory as keyof typeof conceptsByCategory]

      if (categoryKnowledge[matchedCategory]) {
        return `${categoryKnowledge[matchedCategory]}\n\nSome specific topics we cover include: ${conceptsInCategory.slice(0, 5).join(", ")}, and more. What specific aspect would you like to learn about?`
      }

      return `I can help you with ${formattedCategory}! Here are some topics we cover: ${conceptsInCategory.slice(0, 5).join(", ")}, and more. What specific aspect would you like to learn about?`
    }

    // Default response for topics we don't cover
    return getRandomResponse(generalKnowledge.default)
  }

  // Get a random response from an array of possible responses
  const getRandomResponse = (responses: string[]): string => {
    return responses[Math.floor(Math.random() * responses.length)]
  }

  // Generate a response about a specific concept
  const generateConceptResponse = (concept: string): string => {
    // If we have specific responses for this concept
    if (conceptKnowledge[concept] && conceptKnowledge[concept].length > 0) {
      // Return a random response from the available ones
      return getRandomResponse(conceptKnowledge[concept])
    }

    // Generic response for concepts we recognize but don't have specific info about
    return `${concept} is an important concept in computer science. You can explore it in more detail in our dedicated section on the site. Would you like to know about any specific aspect of ${concept}?`
  }

  return (
    <>
      {/* Chat toggle button */}
      <motion.button
        onClick={toggleChat}
        className="fixed bottom-8 right-8 z-50 p-4 rounded-full bg-blue-600 text-white shadow-lg hover:bg-blue-700 transition-colors"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
      </motion.button>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-8 z-50 w-80 sm:w-96 h-96 bg-gray-900 border border-gray-800 rounded-lg shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Chat header */}
            <div className="p-4 bg-gray-800 border-b border-gray-700 flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center mr-3">
                  <MessageSquare size={16} />
                </div>
                <div>
                  <h3 className="font-bold text-white">BytBot</h3>
                  <p className="text-xs text-gray-400">CS Learning Assistant</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={toggleChat} className="text-gray-400 hover:text-white">
                <X size={18} />
              </Button>
            </div>

            {/* Chat messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.type === "user"
                        ? "bg-blue-600 text-white rounded-br-none"
                        : "bg-gray-800 text-gray-100 rounded-bl-none"
                    }`}
                  >
                    <p>{message.text}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="max-w-[80%] p-3 rounded-lg bg-gray-800 text-gray-100 rounded-bl-none">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-pulse"></div>
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-pulse delay-75"></div>
                      <div className="w-2 h-2 rounded-full bg-gray-500 animate-pulse delay-150"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat input */}
            <form onSubmit={handleSubmit} className="p-3 bg-gray-800 border-t border-gray-700">
              <div className="flex items-center">
                <Input
                  ref={inputRef}
                  type="text"
                  placeholder="Ask about CS concepts..."
                  value={inputValue}
                  onChange={handleInputChange}
                  className="flex-1 bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 focus-visible:ring-blue-500"
                />
                <Button
                  type="submit"
                  size="icon"
                  className="ml-2 bg-blue-600 hover:bg-blue-700"
                  disabled={isTyping || inputValue.trim() === ""}
                >
                  {isTyping ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                </Button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
