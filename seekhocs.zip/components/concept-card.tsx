"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Binary, LayoutGrid, Cpu, Network, Layers, Lock, ArrowRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface ConceptCardProps {
  title: string
  description: string
  icon: string
  href: string
  delay?: number
}

const ConceptCard = ({ title, description, icon, href, delay = 0 }: ConceptCardProps) => {
  const getIcon = () => {
    switch (icon) {
      case "Binary":
        return <Binary className="h-6 w-6" />
      case "LayoutGrid":
        return <LayoutGrid className="h-6 w-6" />
      case "Cpu":
        return <Cpu className="h-6 w-6" />
      case "Network":
        return <Network className="h-6 w-6" />
      case "Layers":
        return <Layers className="h-6 w-6" />
      case "Lock":
        return <Lock className="h-6 w-6" />
      default:
        return <Binary className="h-6 w-6" />
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 1 + delay }}
    >
      <Link href={href}>
        <Card className="h-full overflow-hidden border border-gray-800 bg-gray-900/50 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300 group">
          <CardContent className="p-6">
            <div className="flex flex-col h-full">
              <div className="flex items-center mb-4">
                <div className="mr-4 p-3 rounded-lg bg-gradient-to-br from-cyan-500/20 to-purple-600/20 text-cyan-400 group-hover:text-cyan-300 transition-colors">
                  {getIcon()}
                </div>
                <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">{title}</h3>
              </div>

              <p className="text-gray-400 mb-4 flex-grow">{description}</p>

              <div className="flex items-center text-cyan-400 group-hover:text-cyan-300 transition-colors">
                <span className="text-sm font-medium">Explore</span>
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  )
}

export default ConceptCard

