"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { Binary, LayoutGrid, Cpu, Network, Layers, Lock, Code, Database, type LucideIcon } from "lucide-react"

interface ConceptCardProps {
  title: string
  description: string
  icon: string
  href: string
  delay?: number
}

export default function ConceptCard({ title, description, icon, href, delay = 0 }: ConceptCardProps) {
  const icons: Record<string, LucideIcon> = {
    Binary,
    LayoutGrid,
    Cpu,
    Network,
    Layers,
    Lock,
    Code,
    Database,
  }

  const Icon = icons[icon] || Binary

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: delay + 0.2, duration: 0.5 }}
      whileHover={{
        y: -5,
        transition: { duration: 0.2 },
      }}
    >
      <Link href={href} className="block h-full">
        <motion.div
          className="h-full p-6 rounded-xl border border-gray-800 bg-gray-900/50 backdrop-blur-sm hover:bg-gray-800/70 transition-all relative overflow-hidden group"
          whileHover={{
            boxShadow: "0 0 15px rgba(59, 130, 246, 0.2)",
          }}
        >
          {/* Animated background gradient */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-blue-900/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
            initial={{ opacity: 0 }}
            whileHover={{ opacity: 1 }}
          />

          {/* Animated corner accent */}
          <motion.div
            className="absolute -top-10 -right-10 w-20 h-20 bg-blue-500/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
            initial={{ scale: 0 }}
            whileHover={{ scale: 1 }}
            transition={{ duration: 0.3 }}
          />

          <div className="flex items-start space-x-4">
            <motion.div
              className="p-2 rounded-lg bg-blue-900/20 text-blue-400"
              whileHover={{
                rotate: [0, -10, 10, -10, 0],
                scale: 1.1,
              }}
              transition={{ duration: 0.5 }}
            >
              <Icon className="h-6 w-6" />
            </motion.div>
            <div className="flex-1">
              <motion.h3
                className="text-lg font-semibold mb-2 text-white group-hover:text-blue-400 transition-colors"
                layout
              >
                {title}
              </motion.h3>
              <motion.p className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors" layout>
                {description}
              </motion.p>
            </div>
          </div>

          {/* Animated arrow indicator */}
          <motion.div
            className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
            initial={{ x: -10, opacity: 0 }}
            whileHover={{ x: 0, opacity: 1 }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-blue-400"
            >
              <path d="M5 12h14"></path>
              <path d="m12 5 7 7-7 7"></path>
            </svg>
          </motion.div>
        </motion.div>
      </Link>
    </motion.div>
  )
}
