"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { ChevronRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { getConceptsByCategory } from "@/lib/concepts"

interface ConceptListProps {
  category: string
  title: string
}

export default function ConceptList({ category, title }: ConceptListProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const concepts = getConceptsByCategory(category)

  const filteredConcepts = concepts.filter((concept) => concept.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <Card className="border border-gray-800 bg-gray-900/50 backdrop-blur-sm">
      <CardContent className="p-6">
        <div className="mb-6">
          <h2 className="text-xl font-semibold text-white mb-2">{title} Concepts</h2>
          <p className="text-gray-400 text-sm">Explore fundamental concepts in {title.toLowerCase()}</p>
        </div>

        <div className="mb-4">
          <Input
            type="text"
            placeholder="Filter concepts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-gray-800/50 border-gray-700 text-white"
          />
        </div>

        <div className="space-y-2">
          {filteredConcepts.length > 0 ? (
            filteredConcepts.map((concept, index) => (
              <motion.div
                key={concept}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link
                  href={`/concepts/${category}?concept=${encodeURIComponent(concept)}`}
                  className="flex items-center justify-between p-3 rounded-md hover:bg-gray-800/50 transition-colors"
                >
                  <span className="text-gray-200">{concept}</span>
                  <ChevronRight className="h-4 w-4 text-gray-400" />
                </Link>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-4 text-gray-400">No concepts found matching "{searchQuery}"</div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

